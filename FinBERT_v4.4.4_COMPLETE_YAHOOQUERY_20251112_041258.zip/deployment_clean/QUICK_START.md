# ⚡ Quick Start Guide - FinBERT v4.4.4

## 3-Step Installation (Windows)

### Step 1: Install Dependencies (2 minutes)
```batch
INSTALL_DEPENDENCIES.bat
```
**Choose Mode 1** (Quick Scanner) or **Mode 2** (Full System)

### Step 2: Run Pipeline (5-10 minutes)
```batch
RUN_OVERNIGHT_PIPELINE.bat
```

### Step 3: Review Results
- Check console output
- Open `overnight_results_*.json`
- Review `overnight_pipeline.log`

---

## 3-Step Installation (Linux/Mac)

### Step 1: Install Dependencies
```bash
# Quick Scanner (30 MB)
pip install yahooquery pandas numpy

# OR Full System (4 GB)
pip install -r requirements.txt
```

### Step 2: Run Pipeline
```bash
python run_overnight_pipeline.py
```

### Step 3: Review Results
- Check console output
- Open `overnight_results_*.json`
- Review `overnight_pipeline.log`

---

## What to Expect

### Console Output Sample
```
================================================================================
OVERNIGHT STOCK SCREENING PIPELINE - STARTING
================================================================================

Fetching market sentiment data...
✓ ASX data fetched from yahooquery: ^AXJO
✓ SP500 data from yahooquery
✓ Nasdaq data from yahooquery
✓ Dow data from yahooquery
✓ Sentiment score: 46.8/100

Scanning stocks...
Financials sector: 100% |████████████████████| 30/30
✓ CBA.AX: Score 85.5/100
✓ WBC.AX: Score 78.2/100
...

Generating predictions...
Batch prediction progress: 100% |████████████████████| 250/250
✓ Ensemble predictions complete

Results saved to: overnight_results_20251112_145230.json
Pipeline completed in 8 minutes 34 seconds
```

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'yahooquery'"
```bash
pip install yahooquery
```

### "ImportError: attempted relative import"
✅ Use `python run_overnight_pipeline.py` (not `python models/screening/overnight_pipeline.py`)

### Market sentiment defaulting to 50.0
✅ Already fixed in this version with yahooquery integration

---

## Next Steps

1. ✅ Review `README.md` for detailed documentation
2. ✅ Edit `models/config/screening_config.json` to customize stocks
3. ✅ Run test scripts: `python models/screening/spi_monitor.py`
4. ✅ Schedule overnight runs (Task Scheduler on Windows, cron on Linux)

---

**Ready to go!** 🚀
