"""
Hybrid Data Fetcher with Caching and Batch Operations
------------------------------------------------------
Optimized data fetching to minimize Yahoo Finance API calls and avoid 429 errors.

Features:
- Batch fetching with yf.download() for multiple tickers
- Local caching with TTL (30 minutes default)
- Rate limiting with exponential backoff
- Graceful fallback for failed tickers
- Integration with existing StockScanner

Usage:
    fetcher = HybridDataFetcher()
    data = fetcher.fetch_batch(['CBA.AX', 'WBC.AX', 'ANZ.AX'])
"""

import os
import time
import pickle
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from pathlib import Path
import yfinance as yf
import pandas as pd
import numpy as np

# Setup logging
logger = logging.getLogger(__name__)


class HybridDataFetcher:
    """
    Optimized data fetcher with caching and batch operations
    to minimize API calls and avoid rate limiting
    """
    
    def __init__(self, cache_dir: str = None, cache_ttl_minutes: int = 30):
        """
        Initialize Hybrid Data Fetcher
        
        Args:
            cache_dir: Directory for cache files (default: cache/)
            cache_ttl_minutes: Cache time-to-live in minutes
        """
        if cache_dir is None:
            cache_dir = Path(__file__).parent.parent.parent / "cache"
        
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.cache_ttl = timedelta(minutes=cache_ttl_minutes)
        self.rate_limit_delay = 2.0  # Seconds between batch requests
        
        logger.info(f"Hybrid Data Fetcher initialized")
        logger.info(f"  Cache dir: {self.cache_dir}")
        logger.info(f"  Cache TTL: {cache_ttl_minutes} minutes")
        logger.info(f"  Rate limit delay: {self.rate_limit_delay}s")
    
    def _cache_path(self, ticker: str, data_type: str = "info") -> Path:
        """Generate cache file path for a ticker"""
        safe_ticker = ticker.replace('.', '_').replace(':', '-')
        return self.cache_dir / f"{safe_ticker}_{data_type}.pkl"
    
    def _load_from_cache(self, ticker: str, data_type: str = "info") -> Optional[Dict]:
        """
        Load data from cache if available and not expired
        
        Returns:
            Cached data or None if cache miss/expired
        """
        cache_file = self._cache_path(ticker, data_type)
        
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, 'rb') as f:
                cached = pickle.load(f)
            
            # Check if cache is still valid
            if datetime.now() - cached['timestamp'] < self.cache_ttl:
                logger.debug(f"Cache hit for {ticker} ({data_type})")
                return cached['data']
            else:
                logger.debug(f"Cache expired for {ticker} ({data_type})")
                return None
                
        except Exception as e:
            logger.warning(f"Cache read error for {ticker}: {e}")
            return None
    
    def _save_to_cache(self, ticker: str, data: Dict, data_type: str = "info"):
        """Save data to cache with timestamp"""
        cache_file = self._cache_path(ticker, data_type)
        
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump({
                    'timestamp': datetime.now(),
                    'data': data
                }, f)
            logger.debug(f"Cached data for {ticker} ({data_type})")
        except Exception as e:
            logger.warning(f"Cache write error for {ticker}: {e}")
    
    def fetch_ticker_info(self, ticker: str) -> Optional[Dict]:
        """
        Fetch ticker info with caching
        
        Args:
            ticker: Stock ticker symbol
            
        Returns:
            Ticker info dictionary or None if failed
        """
        # Try cache first
        cached_data = self._load_from_cache(ticker, "info")
        if cached_data is not None:
            return cached_data
        
        # Fetch from Yahoo Finance
        max_retries = 3
        retry_backoff = 5
        
        for attempt in range(max_retries):
            try:
                if attempt > 0:
                    backoff_time = retry_backoff * (2 ** (attempt - 1))
                    logger.info(f"Retry {attempt}/{max_retries} for {ticker} after {backoff_time}s")
                    time.sleep(backoff_time)
                
                stock = yf.Ticker(ticker)
                info = stock.info
                
                # Cache successful fetch
                self._save_to_cache(ticker, info, "info")
                return info
                
            except KeyboardInterrupt:
                raise
            except Exception as e:
                error_str = str(e).lower()
                if '429' in error_str or 'too many requests' in error_str:
                    if attempt < max_retries - 1:
                        logger.warning(f"Rate limit for {ticker}, retrying...")
                        continue
                    else:
                        logger.warning(f"Rate limit persists for {ticker}, giving up")
                        return None
                else:
                    logger.debug(f"Error fetching {ticker}: {str(e)[:100]}")
                    return None
        
        return None
    
    def fetch_batch(self, tickers: List[str], period: str = "5d") -> Dict[str, pd.DataFrame]:
        """
        Fetch historical data for multiple tickers in a single batch request
        
        This is MUCH more efficient than individual requests!
        Single HTTP request for all tickers = avoids rate limiting
        
        Args:
            tickers: List of ticker symbols
            period: Data period (1d, 5d, 1mo, 3mo, 1y, etc.)
            
        Returns:
            Dictionary mapping ticker -> DataFrame with OHLCV data
        """
        if not tickers:
            return {}
        
        # Check cache for each ticker
        results = {}
        uncached_tickers = []
        
        for ticker in tickers:
            cached_data = self._load_from_cache(ticker, f"hist_{period}")
            if cached_data is not None:
                results[ticker] = cached_data
            else:
                uncached_tickers.append(ticker)
        
        if not uncached_tickers:
            logger.info(f"All {len(tickers)} tickers loaded from cache")
            return results
        
        # Fetch uncached tickers in batch
        logger.info(f"Batch fetching {len(uncached_tickers)} uncached tickers...")
        
        max_retries = 3
        retry_backoff = 5
        
        for attempt in range(max_retries):
            try:
                if attempt > 0:
                    backoff_time = retry_backoff * (2 ** (attempt - 1))
                    logger.info(f"Batch retry {attempt}/{max_retries} after {backoff_time}s")
                    time.sleep(backoff_time)
                
                # Add rate limiting delay
                time.sleep(self.rate_limit_delay)
                
                # BATCH DOWNLOAD - Single HTTP request for all tickers!
                data = yf.download(
                    tickers=uncached_tickers,
                    period=period,
                    group_by='ticker',
                    progress=False,
                    threads=False  # Disable threading to avoid multiple connections
                )
                
                # Handle single vs multiple tickers
                if len(uncached_tickers) == 1:
                    ticker = uncached_tickers[0]
                    if not data.empty:
                        results[ticker] = data
                        self._save_to_cache(ticker, data, f"hist_{period}")
                else:
                    # Multiple tickers - data is grouped
                    for ticker in uncached_tickers:
                        try:
                            ticker_data = data[ticker] if ticker in data else pd.DataFrame()
                            if not ticker_data.empty:
                                results[ticker] = ticker_data
                                self._save_to_cache(ticker, ticker_data, f"hist_{period}")
                            else:
                                logger.warning(f"No data for {ticker}")
                        except Exception as e:
                            logger.warning(f"Error extracting data for {ticker}: {e}")
                
                logger.info(f"Batch fetch successful: {len(results)}/{len(tickers)} tickers")
                return results
                
            except KeyboardInterrupt:
                raise
            except Exception as e:
                error_str = str(e).lower()
                if '429' in error_str or 'too many requests' in error_str:
                    if attempt < max_retries - 1:
                        logger.warning(f"Batch rate limit hit, retrying...")
                        continue
                    else:
                        logger.error(f"Batch rate limit persists, returning partial results")
                        return results
                else:
                    logger.error(f"Batch fetch error: {str(e)[:200]}")
                    return results
        
        return results
    
    def validate_stock_batch(self, tickers: List[str], criteria: Dict) -> List[str]:
        """
        Validate multiple stocks at once using batch fetching
        
        Args:
            tickers: List of ticker symbols to validate
            criteria: Dictionary with validation criteria (min_market_cap, etc.)
            
        Returns:
            List of tickers that passed validation
        """
        valid_tickers = []
        
        # Try to fetch info for all tickers
        logger.info(f"Validating {len(tickers)} tickers...")
        
        for ticker in tickers:
            try:
                info = self.fetch_ticker_info(ticker)
                
                if info is None:
                    continue
                
                # Validation checks
                market_cap = info.get('marketCap', 0)
                if market_cap < criteria.get('min_market_cap', 0):
                    continue
                
                avg_volume = info.get('averageVolume', 0)
                if avg_volume < criteria.get('min_avg_volume', 0):
                    continue
                
                current_price = info.get('currentPrice', 0)
                min_price = criteria.get('min_price', 0)
                max_price = criteria.get('max_price', float('inf'))
                if not (min_price <= current_price <= max_price):
                    continue
                
                beta = info.get('beta')
                if beta is not None:
                    beta_min = criteria.get('beta_min', -float('inf'))
                    beta_max = criteria.get('beta_max', float('inf'))
                    if not (beta_min <= beta <= beta_max):
                        continue
                
                valid_tickers.append(ticker)
                
            except Exception as e:
                logger.debug(f"Validation error for {ticker}: {e}")
                continue
        
        logger.info(f"Validation complete: {len(valid_tickers)}/{len(tickers)} passed")
        return valid_tickers
    
    def clear_cache(self, older_than_hours: int = 24):
        """
        Clear cache files older than specified hours
        
        Args:
            older_than_hours: Clear cache older than this many hours
        """
        cutoff_time = datetime.now() - timedelta(hours=older_than_hours)
        cleared = 0
        
        for cache_file in self.cache_dir.glob("*.pkl"):
            try:
                mtime = datetime.fromtimestamp(cache_file.stat().st_mtime)
                if mtime < cutoff_time:
                    cache_file.unlink()
                    cleared += 1
            except Exception as e:
                logger.warning(f"Error clearing cache file {cache_file}: {e}")
        
        logger.info(f"Cleared {cleared} old cache files")
    
    def get_cache_stats(self) -> Dict:
        """Get cache statistics"""
        cache_files = list(self.cache_dir.glob("*.pkl"))
        total_size = sum(f.stat().st_size for f in cache_files)
        
        return {
            'total_files': len(cache_files),
            'total_size_mb': total_size / (1024 * 1024),
            'cache_dir': str(self.cache_dir),
            'ttl_minutes': int(self.cache_ttl.total_seconds() / 60)
        }


# Convenience function for backward compatibility
def fetch_stock_data_cached(ticker: str, period: str = "5d") -> Optional[pd.DataFrame]:
    """
    Convenience function to fetch single ticker with caching
    
    Args:
        ticker: Stock ticker symbol
        period: Data period
        
    Returns:
        DataFrame with OHLCV data or None
    """
    fetcher = HybridDataFetcher()
    result = fetcher.fetch_batch([ticker], period=period)
    return result.get(ticker)


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    fetcher = HybridDataFetcher()
    
    # Test batch fetching
    tickers = ['CBA.AX', 'WBC.AX', 'ANZ.AX', 'NAB.AX']
    print(f"\nTesting batch fetch for {tickers}")
    
    data = fetcher.fetch_batch(tickers, period='5d')
    print(f"Fetched data for {len(data)} tickers")
    
    for ticker, df in data.items():
        print(f"\n{ticker}:")
        print(f"  Shape: {df.shape}")
        print(f"  Columns: {list(df.columns)}")
        if not df.empty:
            print(f"  Latest close: ${df['Close'].iloc[-1]:.2f}")
    
    # Show cache stats
    stats = fetcher.get_cache_stats()
    print(f"\nCache stats:")
    print(f"  Files: {stats['total_files']}")
    print(f"  Size: {stats['total_size_mb']:.2f} MB")
    print(f"  TTL: {stats['ttl_minutes']} minutes")
