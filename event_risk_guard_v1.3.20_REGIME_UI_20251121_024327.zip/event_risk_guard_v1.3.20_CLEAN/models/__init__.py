"""
Event Risk Guard - Models Package
"""

__version__ = "1.3.13"
