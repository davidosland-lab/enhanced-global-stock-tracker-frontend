# 🎨 Force Trade Dialog-Style Inputs
**Version**: v1.3.15.162  
**Date**: 2026-02-18  
**Feature**: Separate confidence and stop-loss inputs for Force Trade section

---

## 📋 **User Request**

> "Put in a dialogue box for entry of confidence level and stop loss."

---

## ✅ **Implementation**

### **Before (v1.3.15.161):**

**Force Trade Section:**
```
┌─────────────────────────────┐
│ Force Trade:                │
│ Symbol: [STAN.L]            │
│ [📈 Force BUY] [📉 Force SELL] │
└─────────────────────────────┘

(Used global sliders:)
Minimum Confidence Level: [====|====] 65%
Stop Loss (%): [2]
```

**Problems:**
1. ❌ Confusing: Global sliders affected automated trading AND Force Trade
2. ❌ No visual separation between controls
3. ❌ Stop-loss was positive (user entered `2` instead of `-2`)
4. ❌ No validation feedback

---

### **After (v1.3.15.162):**

**Force Trade Section (Dialog-Style Form):**
```
┌──────────────────────────────────────┐
│ ⚙️ Force Trade:                      │
│                                      │
│ Symbol:                              │
│ [e.g., AAPL, BP.L, BHP.AX________]  │
│                                      │
│ Confidence (%):                      │
│ [70___________]                      │
│ Set confidence level (50-95%)        │
│                                      │
│ Stop Loss (%):                       │
│ [-3___________]                      │
│ Set stop loss (-1% to -10%)          │
│                                      │
│  [📈 Force BUY]  [📉 Force SELL]     │
│                                      │
│ ✅ Status message here               │
└──────────────────────────────────────┘

(Global sliders remain for automated trading)
```

**Benefits:**
1. ✅ **Self-contained form** with all inputs in one place
2. ✅ **Visual separation** (gold border, distinct styling)
3. ✅ **Clear labels** and helper text
4. ✅ **Validation** with error messages
5. ✅ **Stop-loss enforced as negative** (-1 to -10)

---

## 🎨 **Design Specifications**

### **Layout:**
```
┌─────────────────────────────────────────┐
│ ⚙️ Force Trade:                  [Gold] │ ← Title with emoji
│ ─────────────────────────────────────── │
│ Symbol:                                 │ ← Label
│ ┌─────────────────────────────────────┐ │
│ │ e.g., AAPL, BP.L, BHP.AX          │ │ ← Text input with placeholder
│ └─────────────────────────────────────┘ │
│                                         │
│ Confidence (%):                         │
│ ┌─────────────────────────────────────┐ │
│ │ 70                                  │ │ ← Number input (50-95)
│ └─────────────────────────────────────┘ │
│ Set confidence level (50-95%)           │ ← Helper text
│                                         │
│ Stop Loss (%):                          │
│ ┌─────────────────────────────────────┐ │
│ │ -3                                  │ │ ← Number input (-10 to -1)
│ └─────────────────────────────────────┘ │
│ Set stop loss (-1% to -10%)             │ ← Helper text
│                                         │
│     [📈 Force BUY]  [📉 Force SELL]     │ ← Action buttons (centered)
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ ✅ Status: Order placed at 12:34:56│ │ ← Status box
│ └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

### **Color Scheme:**
- **Container**: Dark grey (`#1e1e1e`) with gold border (`#FFC107`)
- **Inputs**: Darker grey (`#2a2a2a`) with light border (`#555`)
- **Labels**: White (`#ffffff`)
- **Helper text**: Grey (`#888`)
- **Buttons**: Green for BUY (`#4CAF50`), Red for SELL (`#F44336`)
- **Status**: Gold text (`#FFC107`) in darker box

---

## 🔧 **Code Changes**

### **1. New Input Components**

**Symbol Input (Enhanced):**
```python
dcc.Input(
    id='force-trade-symbol',
    type='text',
    placeholder='e.g., AAPL, BP.L, BHP.AX',
    style={'width': '100%', 'padding': '8px', ...}
)
```

**Confidence Input (NEW):**
```python
dcc.Input(
    id='force-trade-confidence',
    type='number',
    placeholder='50-95',
    value=70,
    min=50,
    max=95,
    step=5,
    style={'width': '100%', 'padding': '8px', ...}
)
```

**Stop-Loss Input (NEW):**
```python
dcc.Input(
    id='force-trade-stop-loss',
    type='number',
    placeholder='-2 to -10',
    value=-3,
    min=-10,
    max=-1,
    step=0.5,
    style={'width': '100%', 'padding': '8px', ...}
)
```

---

### **2. Updated Callback**

**Before:**
```python
@app.callback(
    ...
    [State('force-trade-symbol', 'value'),
     State('confidence-slider', 'value'),      # Global slider
     State('stop-loss-input', 'value')]        # Global input
)
```

**After:**
```python
@app.callback(
    ...
    [State('force-trade-symbol', 'value'),
     State('force-trade-confidence', 'value'),  # Force Trade-specific
     State('force-trade-stop-loss', 'value')]   # Force Trade-specific
)
```

---

### **3. Input Validation**

**Added Validation Rules:**
```python
# Validate confidence (50-95%)
if not confidence or confidence < 50 or confidence > 95:
    return "⚠️ Confidence must be between 50% and 95%", symbol

# Validate stop-loss (-10% to -1%)
if not stop_loss or stop_loss > -1 or stop_loss < -10:
    return "⚠️ Stop loss must be between -1% and -10% (negative values)", symbol
```

**Error Messages Shown:**
- `⚠️ Please enter a symbol`
- `⚠️ Confidence must be between 50% and 95%`
- `⚠️ Stop loss must be between -1% and -10% (negative values)`
- `⚠️ Trading system not initialized. Start trading first.`
- `⚠️ Failed to execute BUY for SYMBOL`

---

## 📊 **Comparison: Global vs Force Trade Controls**

| **Control** | **Purpose** | **Location** | **Range** | **Applies To** |
|-------------|-------------|-------------|-----------|----------------|
| **Global Confidence Slider** | Set minimum confidence for automated trading | Top of Trading Controls | 50-95% | Automated trades only |
| **Global Stop-Loss Input** | Set default stop-loss for automated trades | Top of Trading Controls | 1-20% (positive) | Automated trades only |
| **Force Trade Confidence** | Set confidence for this Force Trade | Force Trade Dialog | 50-95% | This Force Buy/Sell only |
| **Force Trade Stop-Loss** | Set stop-loss for this Force Trade | Force Trade Dialog | -1% to -10% (negative) | This Force Buy/Sell only |

---

## 🧪 **Testing Scenarios**

### **Test 1: Valid Input**
```
Symbol: AAPL
Confidence: 75%
Stop Loss: -3%
Click: Force BUY

Expected:
✅ BUY order placed for AAPL at 12:34:56
Symbol field cleared
Console: ✓ FORCE BUY: 10 shares of AAPL @ $150.00
```

### **Test 2: Invalid Confidence (Too Low)**
```
Symbol: MSFT
Confidence: 40%
Stop Loss: -3%
Click: Force BUY

Expected:
⚠️ Confidence must be between 50% and 95%
Symbol field not cleared
```

### **Test 3: Invalid Stop-Loss (Positive)**
```
Symbol: GOOGL
Confidence: 70%
Stop Loss: 3%  (positive)
Click: Force BUY

Expected:
⚠️ Stop loss must be between -1% and -10% (negative values)
Symbol field not cleared
```

### **Test 4: Trading Not Started**
```
(Without clicking "Start Trading" first)
Symbol: TSLA
Confidence: 70%
Stop Loss: -3%
Click: Force BUY

Expected:
⚠️ Trading system not initialized. Start trading first.
Symbol field not cleared
```

### **Test 5: Empty Symbol**
```
Symbol: (empty)
Confidence: 70%
Stop Loss: -3%
Click: Force BUY

Expected:
⚠️ Please enter a symbol
```

---

## 🎯 **User Experience Improvements**

### **Before v1.3.15.162:**
1. ❌ User sees two sets of controls (global + force trade)
2. ❌ Unclear which controls Force Trade uses
3. ❌ Stop-loss confusion (positive vs negative)
4. ❌ No validation until execution fails
5. ❌ Error message generic: "Failed to execute BUY"

### **After v1.3.15.162:**
1. ✅ **Single dialog-style form** with all Force Trade inputs
2. ✅ **Clear separation** from global automated trading controls
3. ✅ **Stop-loss enforced negative** with helper text
4. ✅ **Instant validation** before execution
5. ✅ **Specific error messages** for each validation failure
6. ✅ **Visual feedback** (gold border, centered buttons, status box)

---

## 📝 **Documentation for Users**

### **How to Use Force Trade (v1.3.15.162):**

1. **Start Trading First**
   ```
   Click "▶️ Start Trading" with symbols and capital
   Wait 10 seconds for initialization
   ```

2. **Fill Force Trade Dialog**
   ```
   Symbol: Enter stock symbol (e.g., AAPL, BP.L, BHP.AX)
   Confidence: 50-95% (default: 70%)
   Stop Loss: -1% to -10% (default: -3%)
   ```

3. **Execute Trade**
   ```
   Click "📈 Force BUY" or "📉 Force SELL"
   Check status message below buttons
   ```

4. **Success Confirmation**
   ```
   ✅ BUY order placed for AAPL at 12:34:56
   Symbol field automatically cleared
   Check "Active Positions" table for new position
   ```

### **Common Mistakes:**

| **Mistake** | **Error** | **Solution** |
|-------------|-----------|-------------|
| Positive stop-loss | `⚠️ Stop loss must be... negative values` | Enter `-3` instead of `3` |
| Low confidence | `⚠️ Confidence must be between 50% and 95%` | Enter value ≥ 50% |
| Empty symbol | `⚠️ Please enter a symbol` | Enter valid stock symbol |
| Trading not started | `⚠️ Trading system not initialized` | Click "Start Trading" first |

---

## 🚀 **Installation**

**Package**: `unified_trading_system_v1.3.15.129_COMPLETE_v162.zip`  
**Size**: ~1.7 MB  
**Includes**: All fixes v1.3.15.151-162 (12 critical fixes)

**Install:**
```powershell
# Extract to:
C:\Users\david\REgime trading V4 restored\unified_trading_system_v1.3.15.129_COMPLETE\

# Overwrite all files
```

**Test:**
```powershell
python dashboard.py

# In browser:
1. Start Trading
2. Scroll to "Force Trade" section (gold border)
3. Fill: AAPL, 70%, -3%
4. Click "Force BUY"
5. Verify: ✅ BUY order placed...
```

---

## 📊 **Visual Changes**

### **Before (Scattered Controls):**
```
┌─────────────────────────┐
│ Minimum Confidence:     │ ← Global slider (confusing)
│ [========|======] 65%   │
│                         │
│ Stop Loss (%): [2]      │ ← Global input (confusing)
│                         │
│ Force Trade:            │
│ Symbol: [STAN.L]        │ ← Only symbol input
│ [📈 BUY] [📉 SELL]      │
└─────────────────────────┘
```

### **After (Dialog-Style Form):**
```
┌────────────────────────────────┐
│ Minimum Confidence:            │ ← Global slider (for automated)
│ [========|======] 65%          │
│                                │
│ Stop Loss (%): [10]            │ ← Global input (for automated)
│                                │
│ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │
│ ┃ ⚙️ Force Trade:          ┃ │ ← New dialog section
│ ┃                          ┃ │
│ ┃ Symbol: [AAPL_______]   ┃ │ ← All inputs together
│ ┃                          ┃ │
│ ┃ Confidence (%): [70__]  ┃ │
│ ┃ Set level (50-95%)       ┃ │
│ ┃                          ┃ │
│ ┃ Stop Loss (%): [-3__]   ┃ │
│ ┃ Set loss (-1% to -10%)   ┃ │
│ ┃                          ┃ │
│ ┃ [📈 BUY] [📉 SELL]       ┃ │
│ ┃                          ┃ │
│ ┃ ✅ Status: Success       ┃ │
│ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │
└────────────────────────────────┘
```

---

## 🎯 **Summary**

**Change**: Added dialog-style form for Force Trade with dedicated confidence and stop-loss inputs

**Benefits**:
- ✅ Clear separation between automated trading controls and manual Force Trade
- ✅ All Force Trade inputs in one visually distinct section (gold border)
- ✅ Stop-loss enforced as negative with validation
- ✅ Instant feedback on invalid inputs
- ✅ Better UX with helper text and validation messages

**Files Modified**:
- `core/unified_trading_dashboard.py` (Force Trade section + callback)

**Status**: ✅ IMPLEMENTED (v1.3.15.162)  
**Testing Required**: User verification of new dialog-style form
