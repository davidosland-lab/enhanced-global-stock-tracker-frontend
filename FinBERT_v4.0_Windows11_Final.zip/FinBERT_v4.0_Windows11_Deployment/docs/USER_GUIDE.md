# FinBERT v4.0 - User Guide

## Table of Contents
1. [Overview](#overview)
2. [Getting Started](#getting-started)
3. [Features](#features)
4. [Using the Web Interface](#using-the-web-interface)
5. [Understanding Results](#understanding-results)
6. [Advanced Usage](#advanced-usage)
7. [Configuration](#configuration)
8. [Troubleshooting](#troubleshooting)

---

## Overview

**FinBERT v4.0** is a comprehensive stock analysis platform combining:
- **Real Sentiment Analysis** - ProsusAI/finbert model trained on 4,840 financial sentences (97% accuracy)
- **LSTM Neural Networks** - Deep learning for price predictions
- **Real-time News** - Web scraping from Yahoo Finance and Finviz
- **Interactive Charts** - Non-overlapping candlesticks with ECharts 5.x
- **Ensemble Predictions** - Combines LSTM (70%) + sentiment (30%) for accuracy

### What Makes v4.0 Different?
✅ **NO MOCK DATA** - All sentiment from real news articles  
✅ **Fixed Candlesticks** - Replaced Chart.js with ECharts (no overlapping)  
✅ **Protected Code** - Git tags + backups prevent accidental changes  
✅ **15-min Caching** - SQLite cache reduces API calls  
✅ **Dual News Sources** - Yahoo Finance + Finviz for reliability  

---

## Getting Started

### Step 1: Start the Application

**Option A: Double-click Startup Script**
- Navigate to deployment folder
- Double-click: `START_FINBERT_V4.bat`
- Wait for: `Running on http://127.0.0.1:5000`

**Option B: Command Line**
```cmd
cd FinBERT_v4.0_Windows11_Deployment
call venv\Scripts\activate.bat
python app_finbert_v4_dev.py
```

### Step 2: Open Web Interface
- Open browser (Chrome recommended)
- Navigate to: `http://localhost:5000`
- You should see the FinBERT v4.0 interface

### Step 3: First Analysis
1. **Enter stock symbol** in search box (e.g., `AAPL`)
2. Click **"Analyze"** button
3. Wait for results (5-30 seconds)
4. View sentiment, prediction, and charts

---

## Features

### 1. Real Sentiment Analysis

**How It Works:**
1. **News Scraping** - Fetches articles from Yahoo Finance + Finviz
2. **FinBERT Processing** - Analyzes each article with ProsusAI/finbert model
3. **Aggregation** - Combines scores into overall sentiment
4. **Caching** - Stores results for 15 minutes in SQLite

**What You See:**
- **Sentiment Label:** POSITIVE, NEUTRAL, or NEGATIVE
- **Confidence Score:** 0-100% (model certainty)
- **Article Count:** Number of articles analyzed
- **Source Badge:** Shows news source (Finviz/Yahoo)

**Example Output:**
```
Sentiment: POSITIVE (85% confidence)
Based on 9 news articles from Finviz
Articles include:
- "Apple announces record earnings..."
- "iPhone 15 exceeds expectations..."
```

**No News Articles?**
- ✅ **Expected behavior** - Not a bug!
- System uses REAL news (NO FAKE DATA)
- Some stocks genuinely lack recent coverage
- Major stocks (AAPL, TSLA, MSFT) always have news

### 2. LSTM Price Predictions

**How It Works:**
1. **Historical Data** - Fetches 2 years of price history from Yahoo Finance
2. **Feature Engineering** - Calculates 20+ technical indicators
3. **Neural Network** - 3-layer LSTM with dropout regularization
4. **Ensemble** - Combines LSTM (70%) + sentiment (30%)

**Model Architecture:**
```
Input Layer: 20 features × 60 timesteps
LSTM Layer 1: 128 units + 20% dropout
LSTM Layer 2: 64 units + 20% dropout
LSTM Layer 3: 32 units + 20% dropout
Dense Layer: 16 units
Output Layer: 1 unit (next-day price)
```

**Training Process:**
- **First run:** Downloads data + trains model (5-10 minutes)
- **Subsequent runs:** Loads cached model (instant)
- **Model updates:** Automatically retrains weekly

**What You See:**
- **Current Price:** Latest close from Yahoo Finance
- **Predicted Price:** Next-day forecast
- **Change:** Percentage difference (green/red)
- **Confidence:** Model certainty (based on loss)
- **Recommendation:** BUY/HOLD/SELL based on prediction

**Example Output:**
```
Current Price: $182.45
Predicted Price: $185.20 (+1.51%)
Confidence: 72%
Recommendation: BUY
Model: LSTM Ensemble (70% Neural Network + 30% Sentiment)
```

### 3. Interactive Candlestick Charts

**Features:**
- **Non-overlapping Candles** - Fixed with ECharts 5.x
- **Color Coding:**
  - 🟢 Green: Price increased (close > open)
  - 🔴 Red: Price decreased (close < open)
- **Zoom & Pan:**
  - Mouse wheel: Zoom in/out
  - Click & drag: Pan timeline
  - Slider: Select date range
- **Tooltip:**
  - Hover over candle → Shows OHLC data
  - Date, Open, High, Low, Close values

**Chart Controls:**
- **Data Range Slider** - Bottom of chart
- **Reset View** - Refresh page
- **Responsive** - Auto-resizes with window

### 4. Volume Chart

**Shows:**
- Daily trading volume bars
- Color coded to match price movement
- Synchronized with candlestick chart

**Use Cases:**
- Identify high-volume days (institutional activity)
- Spot volume spikes (news events)
- Confirm price trends (volume should support direction)

### 5. Real-time News Scraping

**News Sources:**
- **Primary:** Finviz.com (financial news aggregator)
- **Backup:** Yahoo Finance (company-specific news)

**Scraping Process:**
1. Check SQLite cache (15-minute expiry)
2. If expired, fetch fresh articles:
   - Async concurrent requests to both sources
   - Parse HTML with BeautifulSoup4
   - Extract headlines, snippets, publish dates
3. Analyze each article with FinBERT
4. Aggregate sentiment scores
5. Cache results for future requests

**Rate Limiting:**
- 15-minute cache prevents excessive requests
- Async fetching reduces wait time
- Fallback sources ensure reliability

**Privacy:**
- No API keys required
- Public news sources only
- No user data collection

---

## Using the Web Interface

### Stock Symbol Input

**Supported Formats:**
- **US Stocks:** `AAPL`, `TSLA`, `MSFT`
- **International:** `CBA.AX` (Australia), `BP.L` (London)
- **Case Insensitive:** `aapl` = `AAPL`

**Symbol Validation:**
- Maximum 10 characters
- Letters, numbers, dots, dashes only
- Invalid symbols show error message

### Analyze Button

**Click to trigger:**
1. Loading animation appears
2. Backend processes request:
   - Fetches stock data
   - Scrapes news articles
   - Runs FinBERT analysis
   - Generates LSTM prediction
   - Renders charts
3. Results display (5-30 seconds)

**Progress Indicators:**
- Spinning loader icon
- "Analyzing..." status text
- Console logs (open browser DevTools)

### Results Display

**Layout Sections:**

**1. Sentiment Card (Top Left)**
- Sentiment label with color:
  - 🟢 POSITIVE (green)
  - 🟡 NEUTRAL (yellow)
  - 🔴 NEGATIVE (red)
- Confidence percentage
- Article count badge
- News source badge

**2. Prediction Card (Top Right)**
- Current price (large text)
- Predicted price (large text)
- Change percentage (colored)
- Recommendation badge
- Model information

**3. Charts Section (Bottom)**
- Candlestick chart (top half)
- Volume chart (bottom half)
- Synchronized zoom/pan

### Error Messages

**Common Errors:**

**1. "Symbol not found"**
- Yahoo Finance has no data for symbol
- Check spelling/format
- Try alternative symbol (e.g., `AAPL.O` vs `AAPL`)

**2. "No news articles found"**
- ✅ Expected for some stocks (NO MOCK DATA)
- Symbol may lack recent news coverage
- Try major stocks for testing

**3. "Connection error"**
- Check internet connection
- Yahoo/Finviz may be temporarily down
- Try again in 1-2 minutes

**4. "LSTM model training failed"**
- Insufficient historical data (< 60 days)
- Data quality issues
- Check console logs for details

### Browser Compatibility

**Recommended:**
- ✅ Chrome 100+ (best performance)
- ✅ Edge 100+ (Chromium-based)
- ✅ Firefox 100+
- ⚠️ Safari (ECharts may have issues)
- ❌ Internet Explorer (not supported)

**Requirements:**
- JavaScript enabled
- Cookies enabled (for session)
- Internet connection (for CDN libraries)

---

## Understanding Results

### Sentiment Interpretation

**POSITIVE (Score > 0.6)**
- Majority of articles have bullish sentiment
- Good news coverage (earnings, products, partnerships)
- May indicate upward price pressure
- **Confidence:**
  - 80-100%: Very reliable
  - 60-79%: Fairly reliable
  - < 60%: Mixed signals

**NEUTRAL (Score 0.4-0.6)**
- Balanced news coverage
- No strong positive/negative bias
- Market consensus uncertain
- Often occurs with low article counts

**NEGATIVE (Score < 0.4)**
- Majority of articles have bearish sentiment
- Bad news coverage (lawsuits, losses, scandals)
- May indicate downward price pressure
- **Action:** Consider selling or avoiding

### Prediction Interpretation

**BUY Signals:**
- Predicted price > Current price by 1%+
- POSITIVE sentiment with high confidence
- Strong volume trends
- LSTM confidence > 70%

**HOLD Signals:**
- Predicted change within ±1%
- NEUTRAL sentiment
- No clear trend
- Wait for better entry/exit point

**SELL Signals:**
- Predicted price < Current price by 1%+
- NEGATIVE sentiment with high confidence
- Declining volume
- LSTM confidence > 70%

### Model Confidence

**How It's Calculated:**
```python
confidence = 100 - (model_loss × 10)
```

**Interpretation:**
- **90-100%:** Excellent - Model very certain
- **75-89%:** Good - Reliable prediction
- **60-74%:** Fair - Use with caution
- **< 60%:** Poor - High uncertainty, wait for clarity

**Factors Affecting Confidence:**
- Data quality (missing values, outliers)
- Market volatility (sudden spikes)
- News sentiment strength (conflicting articles)
- Historical pattern consistency

### Risk Disclaimer

⚠️ **IMPORTANT:**
- This tool is for **educational purposes** only
- Predictions are NOT financial advice
- Past performance ≠ future results
- Always do your own research
- Consult financial advisor before trading
- Markets are unpredictable - use at your own risk

**Known Limitations:**
- Cannot predict black swan events
- News sentiment lags market reaction
- LSTM trained on historical data (may not reflect future)
- Technical indicators don't account for fundamentals
- No insider information or institutional data

---

## Advanced Usage

### Configuration Files

**config_dev.py** - Main configuration
```python
# Flask Settings
FLASK_HOST = '0.0.0.0'
FLASK_PORT = 5000
DEBUG = True

# Model Settings
LSTM_SEQUENCE_LENGTH = 60
LSTM_EPOCHS = 50
LSTM_BATCH_SIZE = 32

# Cache Settings
SENTIMENT_CACHE_DURATION = 900  # 15 minutes
```

**Customization:**
- Change port: `FLASK_PORT = 5001`
- Disable debug: `DEBUG = False`
- Adjust LSTM sequence: `LSTM_SEQUENCE_LENGTH = 90`
- Extend cache: `SENTIMENT_CACHE_DURATION = 1800`

### Command-Line Options

**Start with custom port:**
```cmd
set FLASK_PORT=8080
python app_finbert_v4_dev.py
```

**Enable verbose logging:**
```cmd
set LOG_LEVEL=DEBUG
python app_finbert_v4_dev.py
```

**Disable sentiment analysis:**
```cmd
set DISABLE_SENTIMENT=True
python app_finbert_v4_dev.py
```

### API Endpoints

**Health Check:**
```
GET /health
Returns: {"status": "healthy", "timestamp": "..."}
```

**Stock Analysis:**
```
GET /api/analyze?symbol=AAPL
Returns: {
  "sentiment": {...},
  "prediction": {...},
  "chart_data": [...]
}
```

**Sentiment Only:**
```
GET /api/sentiment?symbol=AAPL
Returns: {
  "sentiment": "POSITIVE",
  "confidence": 0.85,
  "article_count": 9
}
```

**Prediction Only:**
```
GET /api/predict?symbol=AAPL
Returns: {
  "current_price": 182.45,
  "predicted_price": 185.20,
  "change": 1.51
}
```

### Python API Usage

**Sentiment Analysis:**
```python
from models.news_sentiment_real import get_sentiment_sync

sentiment = get_sentiment_sync('AAPL', use_cache=True)
print(f"Sentiment: {sentiment['sentiment']}")
print(f"Confidence: {sentiment['confidence']}")
print(f"Articles: {sentiment['article_count']}")
```

**LSTM Prediction:**
```python
from models.lstm_predictor import LSTMStockPredictor

predictor = LSTMStockPredictor()
prediction = predictor.predict('AAPL')
print(f"Current: ${prediction['current_price']:.2f}")
print(f"Predicted: ${prediction['predicted_price']:.2f}")
```

**Async News Scraping:**
```python
import asyncio
from models.news_sentiment_real import get_real_sentiment_for_symbol

async def main():
    result = await get_real_sentiment_for_symbol('AAPL', use_cache=False)
    print(result)

asyncio.run(main())
```

### Database Management

**Cache Database Location:**
```
FinBERT_v4.0_Windows11_Deployment/news_sentiment_cache.db
```

**Clear Cache:**
```cmd
del news_sentiment_cache.db
```

**Inspect Cache:**
```cmd
sqlite3 news_sentiment_cache.db
SELECT symbol, created_at, article_count FROM sentiment_cache;
```

**Backup Cache:**
```cmd
copy news_sentiment_cache.db news_sentiment_cache_backup.db
```

### Model Management

**LSTM Model Location:**
```
FinBERT_v4.0_Windows11_Deployment/models/lstm_models/{symbol}_lstm_model.h5
```

**Retrain Model:**
```cmd
python models/train_lstm.py --symbol AAPL --epochs 100
```

**Delete Model (Forces Retrain):**
```cmd
del models\lstm_models\AAPL_lstm_model.h5
```

**FinBERT Cache Location:**
```
C:\Users\YourName\.cache\huggingface\hub\models--ProsusAI--finbert\
```

**FinBERT Model Size:** ~500MB (downloaded once)

---

## Configuration

### Environment Variables

Create `.env` file in deployment folder:
```bash
# Flask Configuration
FLASK_ENV=development
FLASK_PORT=5000
FLASK_DEBUG=True

# Logging
LOG_LEVEL=INFO
LOG_FILE=finbert.log

# Features
ENABLE_SENTIMENT=True
ENABLE_LSTM=True
ENABLE_CACHE=True

# Cache
CACHE_DURATION=900
CACHE_DB=news_sentiment_cache.db

# News Sources
YAHOO_TIMEOUT=10
FINVIZ_TIMEOUT=10
MAX_ARTICLES=10

# Model Training
LSTM_EPOCHS=50
LSTM_BATCH_SIZE=32
LSTM_VALIDATION_SPLIT=0.2
```

Load in Python:
```python
from dotenv import load_dotenv
load_dotenv()
```

### Performance Tuning

**Speed Up Sentiment Analysis:**
```python
# config_dev.py
MAX_ARTICLES = 5  # Reduce from 10
SENTIMENT_CACHE_DURATION = 3600  # 1 hour
```

**Speed Up LSTM Training:**
```python
# config_dev.py
LSTM_EPOCHS = 30  # Reduce from 50
LSTM_BATCH_SIZE = 64  # Increase from 32
```

**Reduce Memory Usage:**
```python
# config_dev.py
LSTM_SEQUENCE_LENGTH = 30  # Reduce from 60
DISABLE_GPU = True  # Use CPU only
```

### Multi-User Setup

**Run on Network:**
```python
# config_dev.py
FLASK_HOST = '0.0.0.0'  # Listen on all interfaces
```

**Access from other devices:**
```
http://<SERVER_IP>:5000
```

**Security Warning:**
- Do NOT expose to public internet
- Use only on trusted local networks
- No authentication/authorization implemented
- Intended for single-user/development use

---

## Troubleshooting

### Charts Not Displaying

**Symptoms:** Blank chart areas

**Solutions:**
1. Check browser console (F12) for errors
2. Verify internet connection (ECharts CDN required)
3. Clear browser cache (Ctrl + Shift + Delete)
4. Try different browser (Chrome recommended)
5. Disable browser extensions (ad blockers)

### Sentiment Shows "No Articles"

**Symptoms:** "Error: No news articles found for this symbol"

**Explanation:**
- ✅ **NOT A BUG** - Expected behavior
- System uses REAL news (NO MOCK DATA)
- Some stocks lack recent coverage

**Solutions:**
1. Test with major stocks: AAPL, TSLA, MSFT
2. Check symbol spelling/format
3. Wait and try again (news updates throughout day)
4. Accept this is normal for lesser-known stocks

### Slow Performance

**Symptoms:** Analysis takes > 1 minute

**Causes:**
- First run: FinBERT model download (~500MB)
- First analysis: LSTM training (5-10 minutes)
- Slow internet: News scraping timeout
- Cache disabled: Re-scraping every request

**Solutions:**
1. Enable cache: `use_cache=True`
2. Reduce article count: `MAX_ARTICLES = 5`
3. Use MINIMAL install (no AI features)
4. Increase timeouts in config

### FinBERT Errors

**Symptoms:** "Transformers model failed to load"

**Solutions:**
1. Check internet connection (model downloads automatically)
2. Clear HuggingFace cache:
   ```cmd
   rmdir /s /q %USERPROFILE%\.cache\huggingface
   ```
3. Manual download from: https://huggingface.co/ProsusAI/finbert
4. Verify transformers installed:
   ```cmd
   pip install transformers sentencepiece
   ```

### LSTM Training Fails

**Symptoms:** "Model training error" or "Insufficient data"

**Causes:**
- Stock has < 60 days of history
- Yahoo Finance API issues
- Missing data points

**Solutions:**
1. Try different symbol
2. Check symbol format (e.g., `AAPL` not `AAPL.O`)
3. Increase data fetch period:
   ```python
   # models/lstm_predictor.py
   data = yf.download(symbol, period='5y')  # Instead of 2y
   ```
4. Use prediction without LSTM:
   ```python
   ENABLE_LSTM = False
   ```

### For More Help

See: `TROUBLESHOOTING.md` for detailed issue resolution

---

## Best Practices

### Daily Usage

1. **Morning:** Analyze watchlist symbols
2. **Check sentiment:** Look for extreme POSITIVE/NEGATIVE
3. **Review predictions:** Identify potential trades
4. **Compare charts:** Look for technical patterns
5. **Evening:** Re-analyze for news updates

### Symbol Selection

**Best Results:**
- Large-cap stocks (AAPL, MSFT, TSLA)
- High news coverage (tech, automotive)
- NYSE/NASDAQ listings

**Limited Results:**
- Small-cap stocks (< $1B market cap)
- International stocks (limited news)
- OTC/penny stocks (no data)

### Combining Signals

**Strong BUY Signal:**
- POSITIVE sentiment (85%+ confidence)
- +2%+ predicted price increase
- High volume trend
- Technical indicators confirm

**Strong SELL Signal:**
- NEGATIVE sentiment (85%+ confidence)
- -2%+ predicted price decrease
- Declining volume
- Technical indicators confirm

**HOLD/Wait:**
- NEUTRAL sentiment
- Predicted change < ±1%
- Low confidence (< 60%)
- Conflicting signals

---

## Appendix

### Keyboard Shortcuts

- **Ctrl + R** - Reload page (reset charts)
- **F12** - Open browser DevTools (debugging)
- **Ctrl + Shift + Delete** - Clear browser cache

### File Structure

```
FinBERT_v4.0_Windows11_Deployment/
├── app_finbert_v4_dev.py          # Main Flask application
├── config_dev.py                   # Configuration settings
├── finbert_v4_enhanced_ui.html     # Web interface (ECharts)
├── requirements-full.txt           # Full dependencies (AI)
├── requirements-minimal.txt        # Minimal dependencies
├── START_FINBERT_V4.bat           # Quick start script
├── models/
│   ├── finbert_sentiment.py       # Sentiment analyzer (no mock)
│   ├── news_sentiment_real.py     # Real news scraper
│   ├── lstm_predictor.py          # LSTM neural network
│   └── train_lstm.py              # Model training script
├── scripts/
│   └── INSTALL_WINDOWS11.bat      # Installation script
├── docs/
│   ├── INSTALLATION_GUIDE.md      # Setup instructions
│   ├── USER_GUIDE.md              # This file
│   └── TROUBLESHOOTING.md         # Issue resolution
└── venv/                          # Virtual environment
```

### Version History

**v4.0 (2025-10-30):**
- ✅ Real sentiment analysis (NO MOCK DATA)
- ✅ Fixed overlapping candlesticks (ECharts)
- ✅ Real news scraping (Yahoo + Finviz)
- ✅ 15-minute SQLite caching
- ✅ Protected sentiment code (git tags + backups)
- ✅ Windows 11 deployment package

**Previous Versions:**
- v3.x: Mock sentiment implementation (replaced)
- v2.x: Chart.js candlesticks (replaced with ECharts)
- v1.x: Initial LSTM implementation

### Credits

**Models & Libraries:**
- ProsusAI/finbert - Pre-trained financial BERT model
- TensorFlow - Deep learning framework
- PyTorch - ML framework for BERT
- ECharts - Interactive charting library
- Flask - Python web framework
- Yahoo Finance - Stock market data API
- Finviz - Financial news aggregation

**Technologies:**
- Python 3.9+
- BeautifulSoup4 - HTML parsing
- aiohttp - Async HTTP client
- SQLite - Local database caching

---

**User Guide Version:** 1.0  
**Last Updated:** 2025-10-30  
**Compatible With:** FinBERT v4.0 Windows 11 Deployment Package
