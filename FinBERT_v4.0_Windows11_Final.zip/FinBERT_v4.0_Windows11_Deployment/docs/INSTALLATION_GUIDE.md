# FinBERT v4.0 - Windows 11 Installation Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Installation Steps](#installation-steps)
3. [Installation Options](#installation-options)
4. [Post-Installation Verification](#post-installation-verification)
5. [First Run](#first-run)
6. [Common Installation Issues](#common-installation-issues)

---

## Prerequisites

### Required Software
- **Windows 11** (64-bit)
- **Python 3.9+** (Python 3.10 or 3.11 recommended)
  - Download from: https://www.python.org/downloads/
  - ⚠️ **CRITICAL:** Check "Add Python to PATH" during installation
- **Internet Connection** (for downloading dependencies)
- **Minimum 4GB RAM** (8GB+ recommended for FULL install)
- **Minimum 2GB free disk space** (5GB+ for FULL install with models)

### Python Installation Verification
1. Open **Command Prompt** (Win + R → type `cmd` → Enter)
2. Run: `python --version`
3. Should show: `Python 3.9.x` or higher
4. Run: `pip --version`
5. Should show pip version

If not recognized:
- Reinstall Python with "Add to PATH" checked
- Or manually add Python to PATH (see Troubleshooting)

---

## Installation Steps

### Step 1: Extract the Package
1. **Locate** the downloaded ZIP file: `FinBERT_v4.0_Windows11_Final.zip`
2. **Right-click** → "Extract All..."
3. **Choose** a location (e.g., `C:\FinBERT\`)
4. **Extract** - Creates folder: `FinBERT_v4.0_Windows11_Deployment`

### Step 2: Run Installation Script
1. **Navigate** to the extracted folder
2. **Open** the `scripts` subfolder
3. **Right-click** on `INSTALL_WINDOWS11.bat`
4. Select **"Run as administrator"** (recommended)
5. **Choose** installation type:
   - Type `1` for **FULL INSTALL** (AI/ML with FinBERT + LSTM)
   - Type `2` for **MINIMAL INSTALL** (Basic features only)
6. Press **Enter** and wait for installation to complete

### Step 3: Wait for Dependencies
**FULL INSTALL:**
- Installs ~30+ packages including TensorFlow, PyTorch, Transformers
- Download size: ~2GB
- Time: 10-30 minutes (depends on internet speed)
- Progress messages will display

**MINIMAL INSTALL:**
- Installs ~10 packages (Flask, requests, etc.)
- Download size: ~200MB
- Time: 2-5 minutes
- Faster but no AI features

### Step 4: Verify Installation
The script will automatically verify:
- ✅ Flask server can start
- ✅ Configuration loads correctly
- ✅ Required modules import successfully
- ✅ Database initialization works

If errors occur, see [Common Installation Issues](#common-installation-issues)

---

## Installation Options

### Option 1: FULL INSTALL (Recommended)
**What You Get:**
- ✅ Real FinBERT sentiment analysis (ProsusAI/finbert model)
- ✅ LSTM neural network price predictions
- ✅ Real-time news scraping (Yahoo Finance + Finviz)
- ✅ 15-minute sentiment caching
- ✅ Ensemble predictions (70% LSTM + 30% sentiment)
- ✅ Fixed candlestick charts (ECharts 5.x)

**Packages Installed:**
```
Flask, beautifulsoup4, aiohttp, lxml, requests, yfinance
pandas, numpy, scikit-learn
tensorflow>=2.15.0
torch>=2.0.0
transformers>=4.30.0
sentencepiece>=0.1.99
```

**Disk Space:** ~3.5GB total
**First Run:** Downloads FinBERT model (~500MB) automatically

### Option 2: MINIMAL INSTALL
**What You Get:**
- ✅ Stock price data from Yahoo Finance
- ✅ Basic charting (historical prices)
- ✅ Simple predictions (technical indicators only)
- ❌ NO sentiment analysis
- ❌ NO LSTM predictions
- ❌ NO news scraping

**Packages Installed:**
```
Flask, requests, yfinance
pandas, numpy
```

**Disk Space:** ~500MB total
**Use Case:** Quick testing, low-resource systems

**⚠️ Upgrade Later:**
To add AI features later, run:
```cmd
cd FinBERT_v4.0_Windows11_Deployment
call venv\Scripts\activate.bat
pip install -r requirements-full.txt
pip install tensorflow torch transformers sentencepiece
```

---

## Post-Installation Verification

### Test 1: Virtual Environment
```cmd
cd FinBERT_v4.0_Windows11_Deployment
call venv\Scripts\activate.bat
```
- Prompt should show: `(venv) C:\...\FinBERT_v4.0_Windows11_Deployment>`

### Test 2: Import Check
```cmd
python -c "import flask; print('Flask OK')"
python -c "import torch; print('PyTorch OK')"  # FULL install only
python -c "import tensorflow; print('TensorFlow OK')"  # FULL install only
python -c "from transformers import pipeline; print('Transformers OK')"  # FULL install only
```

### Test 3: Configuration
```cmd
python -c "from config_dev import Config; print('Config OK')"
```

### Test 4: Models (FULL Install)
```cmd
python -c "from models.finbert_sentiment import FinBERTSentimentAnalyzer; print('FinBERT OK')"
python -c "from models.news_sentiment_real import get_sentiment_sync; print('News Scraper OK')"
python -c "from models.lstm_predictor import LSTMStockPredictor; print('LSTM OK')"
```

**All tests pass?** ✅ Installation successful!

---

## First Run

### Method 1: Using Startup Script (Easiest)
1. **Double-click** `START_FINBERT_V4.bat` in the main folder
2. Wait for message: `Running on http://127.0.0.1:5000`
3. **Open browser** → navigate to: `http://localhost:5000`
4. **Test with symbol:** Type `AAPL` → Click "Analyze"

### Method 2: Manual Start
1. **Open Command Prompt**
2. **Navigate** to deployment folder:
   ```cmd
   cd C:\FinBERT\FinBERT_v4.0_Windows11_Deployment
   ```
3. **Activate** virtual environment:
   ```cmd
   call venv\Scripts\activate.bat
   ```
4. **Start** Flask server:
   ```cmd
   python app_finbert_v4_dev.py
   ```
5. **Open browser** → `http://localhost:5000`

### Expected Behavior on First Run (FULL Install)
1. **FinBERT Model Download:**
   - Automatically downloads ProsusAI/finbert (~500MB)
   - Shows progress: "Downloading (…)..."
   - Takes 5-15 minutes (first run only)
   - Cached locally for future runs

2. **News Scraping:**
   - Fetches real articles from Finviz
   - Yahoo Finance as backup source
   - Creates SQLite cache database
   - Shows article count in console

3. **LSTM Predictions:**
   - If trained model exists: Loads instantly
   - If no model: Shows "Training LSTM..." (5-10 minutes)
   - Model saved for future use

### Expected UI Elements
- ✅ Stock symbol input field
- ✅ "Analyze" button
- ✅ Sentiment display with score and confidence
- ✅ Price prediction with next-day forecast
- ✅ Candlestick chart (non-overlapping, ECharts)
- ✅ Volume chart
- ✅ Article count badge

---

## Common Installation Issues

### Issue 1: "Python is not recognized"
**Symptoms:**
```
'python' is not recognized as an internal or external command
```

**Solution A: Add to PATH (Recommended)**
1. Press **Win + R** → type `sysdm.cpl` → Enter
2. Click **"Advanced"** tab → **"Environment Variables"**
3. Under **"System variables"** → select **"Path"** → **"Edit"**
4. Click **"New"** → Add: `C:\Users\YourName\AppData\Local\Programs\Python\Python311\`
5. Click **"New"** → Add: `C:\Users\YourName\AppData\Local\Programs\Python\Python311\Scripts\`
6. Click **OK** → **OK** → **OK**
7. **Restart Command Prompt**

**Solution B: Use Python Launcher**
- Replace `python` with `py` in all commands
- Replace `pip` with `py -m pip`

### Issue 2: "Access Denied" During Installation
**Cause:** Insufficient permissions

**Solution:**
1. **Right-click** `INSTALL_WINDOWS11.bat`
2. Select **"Run as administrator"**
3. Click **"Yes"** on UAC prompt

### Issue 3: TensorFlow Installation Fails
**Symptoms:**
```
ERROR: Could not find a version that satisfies the requirement tensorflow
```

**Solution A: Check Python Version**
- TensorFlow requires Python 3.9-3.11 (NOT 3.12+)
- Run: `python --version`
- If 3.12+, install Python 3.11 from python.org

**Solution B: Use Minimal Install**
- Choose option `2` during installation
- Use basic features without TensorFlow

**Solution C: Manual TensorFlow Install**
```cmd
pip install tensorflow-cpu>=2.15.0
```

### Issue 4: PyTorch Installation Fails
**Symptoms:**
```
ERROR: Could not find a version that satisfies the requirement torch
```

**Solution: Install from PyTorch Website**
```cmd
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### Issue 5: "FinBERT model download hangs"
**Symptoms:**
- First run stuck at "Downloading (…)..."
- No progress for 10+ minutes

**Solution:**
1. **Check internet connection**
2. **Disable VPN/Proxy** (can block HuggingFace)
3. **Manual download:**
   - Visit: https://huggingface.co/ProsusAI/finbert
   - Click "Files and versions"
   - Download all files to: `C:\Users\YourName\.cache\huggingface\hub\models--ProsusAI--finbert`
4. **Restart application**

### Issue 6: "Port 5000 already in use"
**Symptoms:**
```
Address already in use: Port 5000
```

**Solution A: Change Port**
Edit `config_dev.py`:
```python
FLASK_PORT = 5001  # Change from 5000
```

**Solution B: Kill Existing Process**
```cmd
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F
```

### Issue 7: Charts Not Displaying
**Symptoms:**
- UI loads but charts are blank
- Console shows "echarts is not defined"

**Solution:**
1. **Check internet connection** (CDN required for ECharts)
2. **Clear browser cache** (Ctrl + Shift + Delete)
3. **Try different browser** (Chrome recommended)
4. **Check firewall** - Allow Flask port 5000

### Issue 8: "No articles found for symbol"
**Symptoms:**
- Sentiment shows "Error: No news articles found"
- Works for AAPL/TSLA but not others

**Explanation:**
- ✅ **NOT A BUG** - This is correct behavior
- System uses REAL news scraping (NO MOCK DATA)
- Some symbols genuinely have no recent news
- Yahoo Finance may 404 for certain symbols
- Finviz may not have coverage for all stocks

**Solution:**
- Test with major symbols first: AAPL, TSLA, MSFT, GOOGL
- International symbols may have limited coverage
- Consider this expected behavior for lesser-known stocks

### Issue 9: SQLite Database Errors
**Symptoms:**
```
sqlite3.OperationalError: database is locked
```

**Solution:**
- Delete cache database: `news_sentiment_cache.db`
- Restart application (auto-recreates)

### Issue 10: Memory Errors During Installation
**Symptoms:**
```
MemoryError: Unable to allocate array
```

**Solution:**
1. **Close other applications**
2. **Use MINIMAL install** instead
3. **Upgrade RAM** (minimum 4GB, recommend 8GB)

---

## Uninstallation

### Option 1: Complete Removal
1. **Stop Flask server** (Ctrl + C in command prompt)
2. **Delete entire folder:** `FinBERT_v4.0_Windows11_Deployment`
3. **Delete cache** (optional):
   - `C:\Users\YourName\.cache\huggingface\` (~500MB)
   - `C:\Users\YourName\AppData\Local\pip\cache\` (~varies)

### Option 2: Keep Virtual Environment
- Only delete: `app_finbert_v4_dev.py` and related files
- Keep: `venv` folder for future Python projects

---

## Upgrade from Minimal to Full

If you initially chose MINIMAL and want AI features:

```cmd
cd FinBERT_v4.0_Windows11_Deployment
call venv\Scripts\activate.bat

REM Install AI packages
pip install -r requirements-full.txt
pip install tensorflow>=2.15.0
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install transformers>=4.30.0
pip install sentencepiece>=0.1.99

REM Verify
python -c "import tensorflow; import torch; import transformers; print('Upgrade complete!')"
```

Restart the application - AI features now available! ✅

---

## Support

**Documentation:**
- `README.md` - Quick start guide
- `USER_GUIDE.md` - Feature documentation
- `TROUBLESHOOTING.md` - Detailed issue resolution

**Technical Details:**
- `CRITICAL_ISSUES_AND_CORRECTIONS.md` - Bug fixes implemented
- `REAL_SENTIMENT_TEST_RESULTS.md` - Sentiment verification
- `CANDLESTICK_FIX_COMPLETE.md` - Chart fix documentation

**Contact:**
- Check GitHub repository for updates
- Review logs in Command Prompt for detailed error messages
- Check Flask console output for debugging information

---

**Installation Guide Version:** 1.0  
**Last Updated:** 2025-10-30  
**Compatible With:** FinBERT v4.0 Windows 11 Deployment Package
