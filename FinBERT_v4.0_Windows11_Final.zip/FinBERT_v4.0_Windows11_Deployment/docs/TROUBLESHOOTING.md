# FinBERT v4.0 - Troubleshooting Guide

## Table of Contents
1. [Installation Issues](#installation-issues)
2. [Runtime Errors](#runtime-errors)
3. [Performance Problems](#performance-problems)
4. [Chart Display Issues](#chart-display-issues)
5. [Sentiment Analysis Issues](#sentiment-analysis-issues)
6. [LSTM Prediction Issues](#lstm-prediction-issues)
7. [Network & Connectivity](#network--connectivity)
8. [Database Issues](#database-issues)
9. [Model Issues](#model-issues)
10. [Platform-Specific Issues](#platform-specific-issues)

---

## Installation Issues

### Issue 1: "Python is not recognized as an internal or external command"

**Symptoms:**
```
'python' is not recognized as an internal or external command,
operable program or batch file.
```

**Cause:** Python not in system PATH

**Solution A: Reinstall Python with PATH**
1. Download Python from https://www.python.org/downloads/
2. Run installer
3. ✅ **CHECK "Add Python to PATH"** (important!)
4. Click "Install Now"
5. Restart Command Prompt
6. Test: `python --version`

**Solution B: Add Python to PATH Manually**
1. Find Python installation path:
   - Common: `C:\Users\YourName\AppData\Local\Programs\Python\Python311\`
   - Or: `C:\Python311\`
2. Press **Win + X** → **System**
3. Click **"Advanced system settings"**
4. Click **"Environment Variables"**
5. Under **"System variables"** → Select **"Path"** → **"Edit"**
6. Click **"New"** → Paste Python path
7. Click **"New"** → Paste Python Scripts path (add `\Scripts` to above)
8. Click **OK** → **OK** → **OK**
9. **Restart Command Prompt**
10. Test: `python --version`

**Solution C: Use Python Launcher**
- Replace `python` with `py` in all commands
- Replace `pip` with `py -m pip`

### Issue 2: "Access Denied" During Installation

**Symptoms:**
```
ERROR: Could not install packages due to an OSError: [WinError 5] Access is denied
```

**Cause:** Insufficient permissions

**Solution A: Run as Administrator**
1. Right-click `INSTALL_WINDOWS11.bat`
2. Select **"Run as administrator"**
3. Click **"Yes"** on UAC prompt

**Solution B: Install to User Directory**
```cmd
pip install --user -r requirements-full.txt
```

**Solution C: Disable Antivirus Temporarily**
- Some antivirus software blocks pip installations
- Temporarily disable during installation
- Re-enable after completion

### Issue 3: TensorFlow Installation Fails

**Symptoms:**
```
ERROR: Could not find a version that satisfies the requirement tensorflow>=2.15.0
ERROR: No matching distribution found for tensorflow>=2.15.0
```

**Cause:** Python version incompatibility

**Check Python Version:**
```cmd
python --version
```

**TensorFlow Compatibility:**
- ✅ Python 3.9, 3.10, 3.11 - Compatible
- ❌ Python 3.12+ - NOT compatible (as of Oct 2025)
- ❌ Python 3.8 or older - NOT compatible

**Solution A: Install Compatible Python**
1. Uninstall current Python
2. Download Python 3.11 from https://www.python.org/downloads/
3. Install with "Add to PATH" checked
4. Retry installation

**Solution B: Use TensorFlow CPU Version**
```cmd
pip install tensorflow-cpu>=2.15.0
```

**Solution C: Use Minimal Install**
- Choose option `2` during installation
- Skips TensorFlow entirely

### Issue 4: PyTorch Installation Fails

**Symptoms:**
```
ERROR: Could not find a version that satisfies the requirement torch
```

**Cause:** Need to use PyTorch index URL

**Solution: Install from PyTorch Repository**
```cmd
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

For GPU support (if CUDA installed):
```cmd
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### Issue 5: Virtual Environment Creation Fails

**Symptoms:**
```
Error: Unable to create virtual environment
```

**Solution A: Ensure venv Module**
```cmd
python -m ensurepip --upgrade
python -m pip install --upgrade pip
```

**Solution B: Use Alternative venv Name**
```cmd
python -m venv finbert_env
finbert_env\Scripts\activate.bat
```

**Solution C: Install virtualenv**
```cmd
pip install virtualenv
virtualenv venv
```

---

## Runtime Errors

### Issue 6: "Port 5000 already in use"

**Symptoms:**
```
OSError: [WinError 10048] Only one usage of each socket address is normally permitted
Address already in use: Port 5000
```

**Cause:** Another application using port 5000

**Solution A: Change Flask Port**
Edit `config_dev.py`:
```python
FLASK_PORT = 5001  # Change from 5000
```

Or use environment variable:
```cmd
set FLASK_PORT=8080
python app_finbert_v4_dev.py
```

**Solution B: Kill Process Using Port**
Find process:
```cmd
netstat -ano | findstr :5000
```

Output shows PID (last column):
```
TCP  0.0.0.0:5000  0.0.0.0:0  LISTENING  12345
```

Kill process:
```cmd
taskkill /PID 12345 /F
```

**Solution C: Use Random Port**
```python
# config_dev.py
FLASK_PORT = 0  # System assigns available port
```

### Issue 7: "Module not found" Errors

**Symptoms:**
```
ModuleNotFoundError: No module named 'flask'
ModuleNotFoundError: No module named 'transformers'
```

**Cause:** Virtual environment not activated or packages not installed

**Solution A: Activate Virtual Environment**
```cmd
cd FinBERT_v4.0_Windows11_Deployment
call venv\Scripts\activate.bat
```

Prompt should show: `(venv) C:\...\>`

**Solution B: Reinstall Packages**
```cmd
call venv\Scripts\activate.bat
pip install -r requirements-full.txt
```

**Solution C: Check Python Interpreter**
```cmd
where python
```

Should show: `.../FinBERT_v4.0_Windows11_Deployment/venv/Scripts/python.exe`

If not, virtual environment not activated.

### Issue 8: "ImportError: DLL load failed"

**Symptoms:**
```
ImportError: DLL load failed while importing _multiarray_umath
ImportError: DLL load failed while importing _sqlite3
```

**Cause:** Missing Visual C++ Redistributables

**Solution: Install VC++ Redistributables**
1. Download from: https://aka.ms/vs/17/release/vc_redist.x64.exe
2. Run installer
3. Restart computer
4. Retry application

### Issue 9: "sqlite3.OperationalError: database is locked"

**Symptoms:**
```
sqlite3.OperationalError: database is locked
```

**Cause:** Multiple processes accessing SQLite cache simultaneously

**Solution A: Close Other Instances**
- Only run one instance of Flask server
- Check Task Manager for duplicate processes

**Solution B: Delete Cache Database**
```cmd
del news_sentiment_cache.db
```

Application will recreate automatically.

**Solution C: Increase Timeout**
Edit `models/news_sentiment_real.py`:
```python
conn = sqlite3.connect('news_sentiment_cache.db', timeout=30)  # Increase from 5
```

### Issue 10: "MemoryError: Unable to allocate array"

**Symptoms:**
```
MemoryError: Unable to allocate 1.23 GiB for an array
```

**Cause:** Insufficient RAM

**Solution A: Close Other Applications**
- Close browser tabs
- Close heavy applications (Photoshop, games, etc.)
- Free up memory

**Solution B: Use Minimal Install**
- Reinstall with option `2` (MINIMAL)
- Avoids TensorFlow/PyTorch memory usage

**Solution C: Reduce LSTM Batch Size**
Edit `config_dev.py`:
```python
LSTM_BATCH_SIZE = 16  # Reduce from 32
LSTM_SEQUENCE_LENGTH = 30  # Reduce from 60
```

**Solution D: Upgrade RAM**
- Minimum: 4GB
- Recommended: 8GB+
- Optimal: 16GB+

---

## Performance Problems

### Issue 11: Application Starts Very Slowly (First Run)

**Symptoms:**
- First run takes 10-30 minutes
- Console shows "Downloading (…)..."

**Cause:** FinBERT model download (~500MB)

**Explanation:**
- ✅ **EXPECTED BEHAVIOR** - Not a bug!
- FinBERT model downloads automatically on first run
- Downloads to: `C:\Users\YourName\.cache\huggingface\`
- Cached for all future runs (instant loading)

**Progress Monitoring:**
```
Downloading (…): 100%|████████| 442M/442M [05:23<00:00, 1.37MB/s]
```

**Solution: Be Patient**
- Let download complete (5-15 minutes)
- Subsequent runs will be instant
- Only happens once per system

**Manual Download (If Stuck):**
1. Visit: https://huggingface.co/ProsusAI/finbert
2. Click "Files and versions"
3. Download all files
4. Place in: `C:\Users\YourName\.cache\huggingface\hub\models--ProsusAI--finbert\`

### Issue 12: Analysis Takes Too Long (> 1 Minute)

**Symptoms:**
- Every analysis takes 60+ seconds
- No improvement on subsequent requests

**Causes & Solutions:**

**Cause A: Cache Disabled**
Check cache enabled:
```python
# models/news_sentiment_real.py
use_cache=True  # Should be True
```

**Cause B: Network Timeout**
Increase timeouts:
```python
# models/news_sentiment_real.py
async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)):
```

**Cause C: Too Many Articles**
Reduce article processing:
```python
# models/news_sentiment_real.py
MAX_ARTICLES = 5  # Reduce from 10
```

**Cause D: LSTM Retraining**
Check if model exists:
```cmd
dir models\lstm_models\*.h5
```

If missing, first analysis trains model (5-10 minutes).

**Cause E: Slow Internet**
- News scraping requires internet
- Test speed: https://fast.com
- Minimum: 5 Mbps recommended

### Issue 13: High CPU Usage

**Symptoms:**
- CPU at 100% during analysis
- Computer becomes unresponsive

**Cause:** TensorFlow/PyTorch using all cores

**Solution A: Limit CPU Cores**
Edit `app_finbert_v4_dev.py`:
```python
import tensorflow as tf
tf.config.threading.set_inter_op_parallelism_threads(2)
tf.config.threading.set_intra_op_parallelism_threads(2)
```

**Solution B: Use CPU-Only Mode**
```cmd
set CUDA_VISIBLE_DEVICES=-1
python app_finbert_v4_dev.py
```

**Solution C: Reduce Model Complexity**
Edit `config_dev.py`:
```python
LSTM_UNITS = [64, 32, 16]  # Reduce from [128, 64, 32]
```

### Issue 14: High Memory Usage

**Symptoms:**
- RAM usage > 4GB
- System swapping to disk

**Solution A: Clear Cache**
```python
import tensorflow as tf
tf.keras.backend.clear_session()
```

**Solution B: Reduce Sequence Length**
```python
# config_dev.py
LSTM_SEQUENCE_LENGTH = 30  # Reduce from 60
```

**Solution C: Disable Caching**
```python
# models/news_sentiment_real.py
use_cache=False  # Trade memory for speed
```

---

## Chart Display Issues

### Issue 15: Charts Not Displaying / Blank Charts

**Symptoms:**
- White/blank area where charts should be
- No errors visible on page

**Cause A: CDN Blocked**
- ECharts loads from CDN (requires internet)

**Check:**
1. Open browser DevTools (F12)
2. Go to "Console" tab
3. Look for errors like:
   ```
   Failed to load resource: net::ERR_INTERNET_DISCONNECTED
   https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js
   ```

**Solution:**
- Check internet connection
- Disable VPN (may block CDN)
- Try different network

**Cause B: JavaScript Disabled**

**Check:**
- Browser settings → JavaScript enabled

**Cause C: Ad Blocker**
- Some ad blockers block CDN scripts

**Solution:**
- Disable ad blocker for localhost
- Add exception for `cdn.jsdelivr.net`

**Cause D: Browser Cache**

**Solution:**
1. Press **Ctrl + Shift + Delete**
2. Select "Cached images and files"
3. Click "Clear data"
4. Reload page (Ctrl + R)

**Cause E: Browser Compatibility**

**Test:**
- Chrome 100+ (best)
- Edge 100+ (good)
- Firefox 100+ (good)
- Safari (may have issues)

### Issue 16: Candlesticks Overlapping (Should Be Fixed!)

**Symptoms:**
- Candles overlap each other
- Cannot read individual candles

**Explanation:**
- ✅ This should be **FIXED** in v4.0!
- Version 4.0 replaced Chart.js with ECharts
- ECharts auto-calculates spacing

**If still occurring:**

**Check 1: Correct UI File**
```cmd
findstr /C:"echarts" finbert_v4_enhanced_ui.html
```

Should show ECharts CDN, NOT Chart.js.

**Check 2: Browser Cache**
- Clear cache completely
- Hard refresh: Ctrl + Shift + R

**Check 3: Verify Version**
Open page → Right-click → "View Page Source"
Look for:
```html
<!-- Should see: -->
<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>

<!-- Should NOT see: -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
```

If Chart.js still present, you have old UI file!

### Issue 17: Charts Not Responsive / Don't Resize

**Symptoms:**
- Chart doesn't resize with window
- Chart appears cut off

**Solution:**
Add window resize handler:
```javascript
window.addEventListener('resize', () => {
    if (priceChart) priceChart.resize();
    if (volumeChart) volumeChart.resize();
});
```

Already included in v4.0 UI!

### Issue 18: Tooltip Not Showing on Hover

**Symptoms:**
- Hover over candle shows nothing
- Tooltip appears but empty

**Check:**
1. Open DevTools (F12)
2. Console tab
3. Look for JavaScript errors

**Common Error:**
```javascript
TypeError: Cannot read property 'date' of undefined
```

**Solution:**
- Data format mismatch
- Check API response in Network tab
- Verify chart data structure

---

## Sentiment Analysis Issues

### Issue 19: "No news articles found for this symbol"

**Symptoms:**
```
Error: No news articles found for this symbol
Sentiment: Unknown
Article count: 0
```

**Explanation:**
✅ **NOT A BUG** - This is **EXPECTED BEHAVIOR**

**Why This Happens:**
- FinBERT v4.0 uses **REAL news scraping** (NO MOCK DATA)
- Some stocks genuinely have no recent news coverage
- Yahoo Finance may return 404 for certain symbols
- Finviz may not cover all stocks (especially international)

**This is CORRECT behavior because:**
- Previous versions used FAKE sentiment (hash-based mock data)
- Version 4.0 removed all mock data generation
- If no real news exists, system returns error (honest approach)

**What You Can Do:**

**Test with Major Stocks:**
- ✅ AAPL (Apple) - Always has news
- ✅ TSLA (Tesla) - Always has news
- ✅ MSFT (Microsoft) - Always has news
- ✅ GOOGL (Google) - Always has news
- ❌ CBA.AX (Australian stock) - May have no news
- ❌ Small-cap stocks - Often no news

**Accept This Limitation:**
- Real sentiment requires real news
- Not all stocks have news coverage
- This is more honest than fake data

**Check News Sources Manually:**
1. Visit: `https://finviz.com/quote.ashx?t={SYMBOL}`
2. Visit: `https://finance.yahoo.com/quote/{SYMBOL}/news`
3. If no news on these sites, system is correct!

### Issue 20: Sentiment Seems Wrong / Inaccurate

**Symptoms:**
- Stock drops 10% but sentiment shows POSITIVE
- Good news but sentiment shows NEGATIVE

**Explanation:**

**Reason 1: Time Lag**
- News scraping happens NOW
- Stock price reflects PAST news
- Sentiment is FORWARD-LOOKING indicator

**Reason 2: Article Quality**
- System analyzes available articles
- Not all articles are equal quality
- Some articles may be outdated

**Reason 3: Model Limitations**
- FinBERT trained on financial text
- May misinterpret sarcasm, nuance
- Confidence score indicates certainty

**What to Check:**

**1. Article Count:**
- < 3 articles: Low confidence
- 5-10 articles: Good confidence
- 10+ articles: High confidence

**2. Confidence Score:**
- < 60%: Don't trust
- 60-80%: Use with caution
- 80%+: Fairly reliable

**3. Read Articles Yourself:**
- Check console logs for article headlines
- Verify sentiment makes sense
- Use as ONE data point, not sole decision

**4. Verify News Sources:**
Enable debug logging:
```python
# models/news_sentiment_real.py
logger.setLevel(logging.DEBUG)
```

Check console for article text being analyzed.

### Issue 21: "FinBERT model failed to load"

**Symptoms:**
```
ERROR: Could not load ProsusAI/finbert model
Falling back to keyword analysis
```

**Cause:** Model download failed or corrupted

**Solution A: Clear Model Cache**
```cmd
rmdir /s /q %USERPROFILE%\.cache\huggingface
```

Restart application (re-downloads model).

**Solution B: Manual Download**
1. Visit: https://huggingface.co/ProsusAI/finbert
2. Download all files:
   - `config.json`
   - `pytorch_model.bin`
   - `tokenizer_config.json`
   - `vocab.txt`
   - `special_tokens_map.json`
3. Create directory: `C:\Users\YourName\.cache\huggingface\hub\models--ProsusAI--finbert\snapshots\{hash}\`
4. Place files in directory
5. Restart application

**Solution C: Check Internet Connection**
- Model downloads from HuggingFace
- Requires stable connection
- ~500MB download

### Issue 22: Sentiment Analysis Very Slow

**Symptoms:**
- Sentiment takes 30+ seconds per request
- No improvement with cache

**Solution A: Enable Cache**
```python
# app_finbert_v4_dev.py
sentiment = get_sentiment_sync(symbol, use_cache=True)
```

**Solution B: Reduce Article Count**
```python
# models/news_sentiment_real.py
MAX_ARTICLES = 5  # Default is 10
```

**Solution C: Extend Cache Duration**
```python
# models/news_sentiment_real.py
CACHE_DURATION = 3600  # 1 hour instead of 15 minutes
```

**Solution D: Use Async**
For multiple symbols:
```python
import asyncio
from models.news_sentiment_real import get_real_sentiment_for_symbol

async def analyze_multiple(symbols):
    tasks = [get_real_sentiment_for_symbol(s) for s in symbols]
    return await asyncio.gather(*tasks)

results = asyncio.run(analyze_multiple(['AAPL', 'TSLA', 'MSFT']))
```

---

## LSTM Prediction Issues

### Issue 23: "LSTM model training failed"

**Symptoms:**
```
ERROR: LSTM training failed
ValueError: Insufficient data for training
```

**Cause:** Not enough historical data

**Requirements:**
- Minimum: 60 days of price data
- Recommended: 2+ years (730 days)

**Solution A: Check Data Availability**
```python
import yfinance as yf
data = yf.download('SYMBOL', period='2y')
print(f"Days of data: {len(data)}")
```

If < 60, stock is too new for LSTM.

**Solution B: Reduce Sequence Length**
```python
# config_dev.py
LSTM_SEQUENCE_LENGTH = 30  # Reduce from 60
```

**Solution C: Try Different Symbol**
- New stocks/IPOs lack history
- Use established stocks (AAPL, MSFT, etc.)

### Issue 24: LSTM Predictions Always Same

**Symptoms:**
- Every prediction shows same price
- Predicted change always 0%

**Cause:** Model not properly trained or converged to mean

**Solution A: Retrain Model**
```cmd
del models\lstm_models\SYMBOL_lstm_model.h5
```

Next analysis will retrain.

**Solution B: Increase Training Epochs**
```python
# config_dev.py
LSTM_EPOCHS = 100  # Increase from 50
```

**Solution C: Check Data Quality**
```python
import yfinance as yf
data = yf.download('SYMBOL', period='2y')
print(data.isnull().sum())  # Should be minimal nulls
```

### Issue 25: "ValueError: Shapes incompatible"

**Symptoms:**
```
ValueError: Shapes (None, 1) and (None, 20) are incompatible
```

**Cause:** Feature mismatch between training and prediction

**Solution: Delete Model and Retrain**
```cmd
del models\lstm_models\*.h5
```

### Issue 26: LSTM Extremely Slow to Train

**Symptoms:**
- Training takes > 30 minutes
- Epoch progress very slow

**Solution A: Reduce Epochs**
```python
# config_dev.py
LSTM_EPOCHS = 30  # Reduce from 50
```

**Solution B: Increase Batch Size**
```python
# config_dev.py
LSTM_BATCH_SIZE = 64  # Increase from 32
```

**Solution C: Use CPU Only (if GPU causing issues)**
```cmd
set CUDA_VISIBLE_DEVICES=-1
```

**Solution D: Reduce Model Complexity**
```python
# models/lstm_predictor.py
model.add(LSTM(64, return_sequences=True))  # Reduce from 128
model.add(LSTM(32, return_sequences=True))  # Reduce from 64
model.add(LSTM(16))  # Reduce from 32
```

---

## Network & Connectivity

### Issue 27: "Connection timeout" Errors

**Symptoms:**
```
aiohttp.ClientConnectionError: Cannot connect to host
TimeoutError: Timeout after 10 seconds
```

**Cause:** Network connectivity issues

**Solution A: Check Internet Connection**
```cmd
ping 8.8.8.8
ping finance.yahoo.com
ping finviz.com
```

**Solution B: Increase Timeout**
```python
# models/news_sentiment_real.py
timeout = aiohttp.ClientTimeout(total=30)  # Increase from 10
```

**Solution C: Disable VPN**
- Some VPNs block financial sites
- Try disabling temporarily

**Solution D: Check Firewall**
- Windows Firewall may block Python
- Add exception for `python.exe`

### Issue 28: "HTTP 403 Forbidden"

**Symptoms:**
```
ClientResponseError: 403 Forbidden
```

**Cause:** Website blocking scraper

**Solution A: Already Implemented**
- v4.0 uses browser-like headers
- Rotates user agents

**Solution B: Wait and Retry**
- May be temporary rate limit
- Wait 5 minutes and try again

**Solution C: Check Yahoo Finance Manually**
- Visit: https://finance.yahoo.com/quote/SYMBOL
- If blocked in browser too, API blocked

### Issue 29: "HTTP 404 Not Found" (Yahoo Finance)

**Symptoms:**
```
Yahoo Finance returned 404 for symbol: AAPL
```

**Explanation:**
- ✅ **KNOWN ISSUE** - Yahoo Finance URLs changed
- System falls back to Finviz automatically

**Why This Happens:**
- Yahoo Finance redesigned their URLs
- Old scraping patterns may fail
- Finviz serves as primary source now

**Impact:**
- ✅ **MINIMAL** - Finviz covers most stocks
- System designed with fallback sources
- Most users won't notice

**Solution: Already Handled**
```python
# models/news_sentiment_real.py
yahoo_articles, finviz_articles = await asyncio.gather(
    yahoo_task, finviz_task, return_exceptions=True
)
# If Yahoo fails, Finviz still works!
```

### Issue 30: SSL Certificate Errors

**Symptoms:**
```
ssl.SSLCertVerificationError: certificate verify failed
```

**Cause:** System certificate store outdated

**Solution A: Update Certificates**
```cmd
pip install --upgrade certifi
```

**Solution B: Disable Verification (NOT RECOMMENDED)**
```python
# models/news_sentiment_real.py
ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE
```

⚠️ **Security Risk:** Only use for testing!

---

## Database Issues

### Issue 31: "Database locked" Error

**Symptoms:**
```
sqlite3.OperationalError: database is locked
```

**Solution: See Issue #9**

### Issue 32: Cache Not Working

**Symptoms:**
- Every request takes full time
- No speed improvement

**Check Cache Status:**
```cmd
dir news_sentiment_cache.db
```

If missing, cache not being created.

**Solution A: Check Permissions**
```cmd
cd FinBERT_v4.0_Windows11_Deployment
icacls news_sentiment_cache.db
```

Should show write permissions.

**Solution B: Manually Create DB**
```python
import sqlite3
conn = sqlite3.connect('news_sentiment_cache.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS sentiment_cache
             (symbol TEXT PRIMARY KEY, 
              sentiment TEXT, 
              confidence REAL,
              article_count INTEGER,
              created_at TIMESTAMP,
              expires_at TIMESTAMP)''')
conn.commit()
conn.close()
```

### Issue 33: Cache Not Expiring

**Symptoms:**
- Old sentiment data showing
- News changed but sentiment same

**Solution: Clear Cache**
```cmd
del news_sentiment_cache.db
```

Or manually:
```cmd
sqlite3 news_sentiment_cache.db "DELETE FROM sentiment_cache WHERE symbol='AAPL';"
```

---

## Model Issues

### Issue 34: FinBERT Model Download Hangs

**Symptoms:**
- First run stuck at "Downloading (…)..."
- No progress for 10+ minutes

**Solution: See Issue #11**

### Issue 35: LSTM Model File Corrupted

**Symptoms:**
```
OSError: Unable to open file (file signature not found)
```

**Solution:**
```cmd
del models\lstm_models\SYMBOL_lstm_model.h5
```

Next run will retrain.

---

## Platform-Specific Issues

### Issue 36: Windows Defender Blocking

**Symptoms:**
- Installation fails silently
- Files disappear after creation

**Cause:** Windows Defender flagging Python scripts

**Solution:**
1. Open **Windows Security**
2. Go to **Virus & threat protection**
3. Click **Manage settings**
4. Add exclusion:
   - **Folder:** `FinBERT_v4.0_Windows11_Deployment`
5. Retry installation

### Issue 37: Windows 10 Compatibility

**Question:** Does this work on Windows 10?

**Answer:** ✅ Yes, fully compatible!
- Package designed for Windows 11
- Works on Windows 10 (64-bit)
- Python 3.9+ required on both

### Issue 38: Running on Mac/Linux

**Question:** Can I use this on Mac or Linux?

**Answer:** ⚠️ Needs adaptation

**Changes Required:**
1. Replace `.bat` files with `.sh` scripts
2. Change path separators: `\` → `/`
3. Activate venv: `source venv/bin/activate`
4. Everything else should work

**Linux/Mac Startup:**
```bash
cd FinBERT_v4.0_Windows11_Deployment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements-full.txt
python app_finbert_v4_dev.py
```

---

## Getting Additional Help

### Enable Debug Logging

**In config_dev.py:**
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

**In app_finbert_v4_dev.py:**
```cmd
set FLASK_DEBUG=True
python app_finbert_v4_dev.py
```

### Check Console Output

**Flask Console:**
- Shows all HTTP requests
- Sentiment analysis progress
- Model loading status
- Error tracebacks

**Browser Console (F12):**
- JavaScript errors
- Network requests
- Chart rendering issues

### Test Individual Components

**Test Sentiment Only:**
```python
from models.news_sentiment_real import get_sentiment_sync
result = get_sentiment_sync('AAPL', use_cache=False)
print(result)
```

**Test LSTM Only:**
```python
from models.lstm_predictor import LSTMStockPredictor
predictor = LSTMStockPredictor()
prediction = predictor.predict('AAPL')
print(prediction)
```

**Test News Scraping:**
```python
import asyncio
from models.news_sentiment_real import fetch_finviz_news

async def test():
    articles = await fetch_finviz_news('AAPL')
    print(f"Found {len(articles)} articles")
    for article in articles:
        print(f"- {article['title']}")

asyncio.run(test())
```

### Documentation

**Read These Files:**
- `INSTALLATION_GUIDE.md` - Setup instructions
- `USER_GUIDE.md` - Feature documentation
- `CRITICAL_ISSUES_AND_CORRECTIONS.md` - Bug fixes implemented
- `REAL_SENTIMENT_TEST_RESULTS.md` - Sentiment verification tests
- `CANDLESTICK_FIX_COMPLETE.md` - Chart fix documentation

### Report Issues

**When Reporting Problems:**
1. **Describe symptoms:** What's happening?
2. **Expected behavior:** What should happen?
3. **Steps to reproduce:** How to recreate?
4. **Error messages:** Copy full error text
5. **Environment:**
   - Windows version: `winver`
   - Python version: `python --version`
   - Package version: Check README.md
6. **Console output:** Include Flask server logs
7. **Browser console:** Include JavaScript errors (F12)

---

**Troubleshooting Guide Version:** 1.0  
**Last Updated:** 2025-10-30  
**Compatible With:** FinBERT v4.0 Windows 11 Deployment Package
