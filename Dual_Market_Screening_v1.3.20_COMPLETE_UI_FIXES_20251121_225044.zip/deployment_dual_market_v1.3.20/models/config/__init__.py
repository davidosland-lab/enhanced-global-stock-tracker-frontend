"""
Event Risk Guard - Configuration Package
"""
