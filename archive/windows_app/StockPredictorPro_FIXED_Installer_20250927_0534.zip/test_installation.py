#!/usr/bin/env python3
"""Test if installation is working correctly"""

import sys
print(f"Python version: {sys.version}")
print("-" * 40)

packages = [
    ("numpy", "Numerical computing"),
    ("pandas", "Data processing"),
    ("customtkinter", "GUI framework"),
    ("sklearn", "Machine learning"),
    ("xgboost", "XGBoost ML"),
    ("yfinance", "Financial data"),
    ("requests", "HTTP requests"),
    ("ta", "Technical analysis"),
]

print("Checking installed packages:")
for package, description in packages:
    try:
        __import__(package)
        print(f"✅ {description} ({package})")
    except ImportError:
        print(f"❌ {description} ({package}) - NOT INSTALLED")

print("-" * 40)
print("\nTest complete!")
input("\nPress Enter to exit...")
