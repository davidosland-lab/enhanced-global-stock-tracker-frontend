# Parameter Optimization - UI Flow

## User Journey

```
┌─────────────────────────────────────────────────────────────────┐
│  1. USER CLICKS "OPTIMIZE PARAMETERS" BUTTON (Header)           │
│     • Amber button with slider icon                             │
│     • Located next to portfolio backtest button                 │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. OPTIMIZATION MODAL OPENS                                     │
│     ┌─────────────────────────────────────────────────────┐    │
│     │  Stock Symbol:    [AAPL              ]              │    │
│     │  Model Type:      [Ensemble ▼        ]              │    │
│     │  Method:          [Random Search ▼   ]              │    │
│     │  Start Date:      [2023-01-01        ]              │    │
│     │  End Date:        [2024-11-01        ]              │    │
│     │                                                       │    │
│     │  [🚀 Start Optimization]                            │    │
│     └─────────────────────────────────────────────────────┘    │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. USER CLICKS "START OPTIMIZATION"                             │
│     • Validation runs (symbol, dates)                           │
│     • Button disables                                            │
│     • Progress indicator appears                                │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  4. OPTIMIZATION IN PROGRESS (2-5 minutes)                       │
│     ┌─────────────────────────────────────────────────────┐    │
│     │  Optimization Progress                               │    │
│     │  Testing configurations...                           │    │
│     │  ████████████████░░░░░░░░░░ 50%                     │    │
│     │  This may take 2-5 minutes                           │    │
│     └─────────────────────────────────────────────────────┘    │
│     • API call to /api/backtest/optimize                        │
│     • Backend runs 50-60 backtests                              │
│     • Train-test split validation                               │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  5. RESULTS DISPLAYED                                            │
│     ┌─────────────────────────────────────────────────────┐    │
│     │  🏆 Optimization Complete!                           │    │
│     │                                                       │    │
│     │  ┌─── Best Parameters Found ─────────────────┐      │    │
│     │  │ Confidence Threshold:  0.65               │      │    │
│     │  │ Lookback Days:         75                 │      │    │
│     │  │ Position Size:         15%                │      │    │
│     │  │ Expected Return:       +12.45%            │      │    │
│     │  └───────────────────────────────────────────┘      │    │
│     │                                                       │    │
│     │  Summary Stats:                                      │    │
│     │  • Configurations Tested: 50                         │    │
│     │  • Avg Train Return: 8.67%                           │    │
│     │  • Avg Test Return: 6.89%                            │    │
│     │  • Low Overfit Configs: 12                           │    │
│     │                                                       │    │
│     │  [✓ Apply Optimal Parameters to Backtest]           │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                  │
│     ┌─── Top 10 Configurations ─────────────────────────┐      │
│     │ Rank│Conf│Look│Pos │Train │Test  │Overfit│        │      │
│     │  1  │0.65│ 75 │15% │15.2% │12.4% │ 18.4% │        │      │
│     │  2  │0.60│ 90 │20% │14.8% │11.9% │ 19.6% │        │      │
│     │  3  │0.70│ 60 │15% │16.1% │11.5% │ 28.6% │        │      │
│     │ ... │... │... │... │ ...  │ ...  │  ...  │        │      │
│     └─────────────────────────────────────────────────────┘    │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  6. USER CLICKS "APPLY OPTIMAL PARAMETERS"                       │
│     • Optimization modal closes                                 │
│     • Backtest modal opens                                      │
│     • Parameters auto-filled with optimal values                │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  7. BACKTEST MODAL OPENS WITH OPTIMIZED PARAMETERS               │
│     ┌─────────────────────────────────────────────────────┐    │
│     │  Stock Symbol:        [AAPL              ]          │    │
│     │  Model Type:          [Ensemble ▼        ]          │    │
│     │  Confidence:          [0.65              ] ← AUTO   │    │
│     │  Lookback Days:       [75                ] ← AUTO   │    │
│     │  Position Size:       [0.15              ] ← AUTO   │    │
│     │  Start Date:          [2023-01-01        ]          │    │
│     │  End Date:            [2024-11-01        ]          │    │
│     │                                                       │    │
│     │  [▶ Run Backtest]                                    │    │
│     └─────────────────────────────────────────────────────┘    │
│     • User can now run backtest with optimal parameters         │
│     • Or adjust parameters manually before running              │
└─────────────────────────────────────────────────────────────────┘
```

---

## Technical Flow

```
Frontend                      Backend                       Database
   │                             │                             │
   │  1. Click Button            │                             │
   ├────────────────────────────►│                             │
   │  openOptimizeModal()        │                             │
   │                             │                             │
   │  2. Fill Form + Submit      │                             │
   ├────────────────────────────►│                             │
   │  POST /api/backtest/optimize│                             │
   │                             │                             │
   │                             │  3. Initialize Optimizer    │
   │                             ├────────────────────────────►│
   │                             │  ParameterOptimizer()       │
   │                             │                             │
   │                             │  4. Split Train/Test        │
   │                             │  train: 75%, test: 25%      │
   │                             │                             │
   │                             │  5. Generate Combinations   │
   │                             │  Random: 50 samples         │
   │                             │  Grid: 60 combinations      │
   │                             │                             │
   │                             │  6. For Each Configuration: │
   │                             │  ┌────────────────────────┐ │
   │                             │  │ Run backtest on train  │ │
   │                             │  │ Run backtest on test   │ │
   │                             │  │ Calculate metrics      │ │
   │                             │  │ Calculate overfit      │ │
   │                             │  │ Store results          │ │
   │                             │  └────────────────────────┘ │
   │                             │  (Repeat 50-60 times)       │
   │                             │                             │
   │                             │  7. Rank by Test Return     │
   │                             │  Select Top 10              │
   │                             │                             │
   │  8. Receive Results         │                             │
   │◄────────────────────────────┤                             │
   │  {best_params, summary}     │                             │
   │                             │                             │
   │  9. Display Results         │                             │
   │  displayOptimizationResults()│                            │
   │                             │                             │
   │  10. User Clicks Apply      │                             │
   │  applyOptimalParameters()   │                             │
   │                             │                             │
   │  11. Transfer to Backtest   │                             │
   │  openBacktestModal()        │                             │
   │  (with optimal params)      │                             │
   │                             │                             │
```

---

## Color Coding in Results

```
Return Values:
  Green  → Positive returns (gains)
  Red    → Negative returns (losses)

Overfit Scores:
  Green  → < 20% (excellent generalization)
  Yellow → 20-40% (acceptable)
  Red    → > 40% (high overfitting risk)

Best Parameters:
  Amber  → Optimal values found
```

---

## Modal States

1. **Initial State**: Clean form with defaults
2. **Progress State**: Animated progress bar, disabled button
3. **Results State**: Full results display, apply button active
4. **Error State**: Error message, retry button enabled

---

## Button States

### "Start Optimization" Button
- **Default**: Amber, enabled, hover effect
- **Disabled**: Amber, opacity-50, no hover
- **After Complete**: Re-enabled automatically

### "Apply Optimal Parameters" Button
- **Always**: Green, enabled when results present
- **Action**: Opens backtest modal with params

---

## Integration Points

1. **Existing Backtest Modal**: Receives parameters from optimization
2. **Stock Symbol Variable**: Uses `currentSymbol` as default
3. **API Configuration**: Uses same `API_BASE` constant
4. **Modal Click-Outside**: Added to existing handler
5. **Styling System**: Uses TailwindCSS like other modals

---

## File Structure

```
finbert_v4_enhanced_ui.html (3,132 lines, 138KB)
├── Line 244: Optimization Button
├── Lines 995-1211: Optimization Modal (218 lines)
│   ├── Stock symbol input
│   ├── Model type selector
│   ├── Optimization method selector
│   ├── Date range inputs
│   ├── Progress indicator
│   ├── Results display
│   │   ├── Best parameters card
│   │   ├── Summary statistics
│   │   └── Top 10 table
│   └── Action buttons
└── Lines 2907-3125: JavaScript Functions (219 lines)
    ├── openOptimizeModal()
    ├── closeOptimizeModal()
    ├── startOptimization()
    ├── displayOptimizationResults()
    ├── displayTop10Configurations()
    └── applyOptimalParameters()
```

---

## Performance Metrics

- **Modal Load Time**: < 100ms
- **API Response Time**: 120-300 seconds (optimization process)
- **Results Display Time**: < 500ms
- **Parameter Transfer Time**: < 100ms

---

## Accessibility

- Keyboard navigation supported
- Screen reader friendly labels
- High contrast color scheme
- Clear error messages
- Loading states indicated
- Focus management on modal open/close
