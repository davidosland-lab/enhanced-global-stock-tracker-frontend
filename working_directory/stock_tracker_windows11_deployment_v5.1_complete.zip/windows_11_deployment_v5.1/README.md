# Stock Tracker - Windows 11 Complete Deployment v5.1

## 🚀 Quick Start

1. **Extract this zip file** to your desired location (e.g., `C:\StockTracker`)
2. **Double-click `windows_start.bat`** to start the backend
3. **Open `index.html`** in your browser for the landing page dashboard

## ✨ What's New in v5.1

### Included in This Package:
- ✅ **NEW Landing Page Dashboard** (`index.html`) - Beautiful central hub for all modules
- ✅ **Update System** - Built-in update scripts for future updates
- ✅ **Version Checking** - Check for updates with `check_for_updates.bat`
- ✅ **All Windows 11 Fixes** - Hardcoded localhost URLs
- ✅ **6 Working Modules** - All tested and functional
- ✅ **Diagnostic Tool** - Connection testing utility

## 📁 Complete Package Contents

```
windows_11_deployment_v5.1/
├── index.html                        # NEW! Landing page dashboard
├── landing_page.html                 # Backup of landing page
├── diagnostic_tool.html              # Connection diagnostic tool
├── backend_fixed_v2.py              # Backend API server
├── requirements.txt                  # Python dependencies
├── VERSION.txt                       # Version tracking (v5.0-windows-11-fix)
│
├── 🚀 Startup Scripts
│   ├── windows_start.bat            # Windows batch startup
│   └── windows_start.ps1            # PowerShell startup
│
├── 🔄 Update System (NEW!)
│   ├── windows_update_deployment.bat    # Update existing installation
│   ├── windows_update_deployment.ps1    # PowerShell updater
│   └── check_for_updates.bat           # Check for new versions
│
├── 📚 Documentation
│   ├── WINDOWS_11_FIX_GUIDE.md         # Troubleshooting guide
│   └── WINDOWS_11_SOLUTION_COMPLETE.md # Complete solution docs
│
└── 📊 modules/
    ├── technical_analysis_enhanced.html     # Main technical analysis
    ├── technical_analysis_desktop.html      # Desktop version
    ├── predictions/
    │   └── prediction_centre_advanced.html  # ML predictions with backtesting
    ├── analysis/
    │   └── cba_analysis_enhanced.html      # CBA specialized analysis
    └── market-tracking/
        └── [various market tracking modules]
```

## 🖥️ System Requirements

- **Windows 11 or 10**
- **Python 3.8+** (Download from python.org if needed)
- **Modern web browser** (Chrome, Edge, Firefox)
- **Internet connection** for Yahoo Finance data
- **Port 8002** available

## 🎯 Features Overview

### Landing Page Dashboard (NEW!)
- Central hub with links to all modules
- Real-time status indicators
- Quick action buttons
- Beautiful gradient design
- Keyboard shortcuts (Ctrl+1/2/3 for modules)

### Technical Analysis Module
- 150+ technical indicators
- Real Yahoo Finance data
- ML predictions
- Pattern recognition
- Candlestick charts

### Prediction Centre
- 6 ML models (LSTM, ARIMA, Random Forest, etc.)
- Comprehensive backtesting
- Learning metrics tracking
- Performance graphs
- Prediction history

### Built-in Update System
- Check for updates anytime
- Automatic backup before updating
- Safe rollback capability
- Downloads latest from GitHub

## 🔧 First Time Setup

```batch
# 1. Extract zip to C:\StockTracker (or any location)

# 2. Install Python if needed (check with: python --version)

# 3. Start the application
windows_start.bat

# 4. Open landing page in browser
# Just double-click index.html
```

## 🌐 Module Access

Once backend is running, access modules via:

1. **Landing Page** - Open `index.html` for dashboard with all module links
2. **Direct Access** - Open any module HTML file directly:
   - `modules\technical_analysis_enhanced.html`
   - `modules\predictions\prediction_centre_advanced.html`
   - `modules\technical_analysis_desktop.html`
   - `diagnostic_tool.html`

## 🔄 Updating Your Installation

This package includes a built-in update system:

```batch
# Check if updates are available
check_for_updates.bat

# Update to latest version
windows_update_deployment.bat
```

Updates will:
- Backup your current installation
- Download latest files
- Apply any new fixes
- Preserve your settings

## 🔍 Troubleshooting

### Quick Diagnostic
1. Run `diagnostic_tool.html` to test all connections
2. Should show all green indicators
3. If red, check backend is running

### Common Issues

**Backend won't start:**
- Check Python is installed: `python --version`
- Check port 8002 is free: `netstat -an | findstr :8002`
- Run as Administrator if needed

**Modules show connection error:**
- Ensure backend is running (console window open)
- All modules use `http://localhost:8002`
- Check Windows Firewall settings

**For detailed help:** See `WINDOWS_11_FIX_GUIDE.md`

## ✅ What's Fixed

All Windows 11 issues resolved:
- ✅ Hardcoded localhost URLs (no dynamic detection)
- ✅ CORS enabled for all origins
- ✅ No more "Failed to fetch" errors
- ✅ No more connection timeouts
- ✅ 100% compatibility with Windows 11

## 📊 Verification Checklist

After installation:
- [ ] Backend starts without errors
- [ ] Landing page opens and shows status
- [ ] Diagnostic tool shows all green
- [ ] Can load stock data (test with AAPL)
- [ ] All module links work from landing page

## 🎉 Key Highlights

- **NO synthetic/mock data** - Real Yahoo Finance only
- **Beautiful landing page** - Professional dashboard
- **Self-updating** - Built-in update system
- **Fully tested** - All modules verified working
- **Windows 11 optimized** - All connection issues fixed

---

**Version:** 5.1 - Complete Edition with Landing Page
**Released:** October 2025
**Status:** Production Ready
**Support:** Full documentation included