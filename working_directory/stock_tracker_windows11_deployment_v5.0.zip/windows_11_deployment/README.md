# Stock Tracker - Windows 11 Deployment Package

## 🚀 Quick Start

1. **Extract this zip file** to your desired location (e.g., `C:\StockTracker`)

2. **Install Python** (if not already installed)
   - Download from: https://www.python.org/downloads/
   - Version 3.8 or higher required
   - ✅ Check "Add Python to PATH" during installation

3. **Run the application**
   - Double-click `windows_start.bat` 
   - OR right-click `windows_start.ps1` → Run with PowerShell

4. **Access the modules** (after backend starts)
   - The script will show you the URLs to open
   - Or manually open the HTML files in your browser

## 📁 Package Contents

```
windows_11_deployment/
├── modules/                           # All frontend modules
│   ├── predictions/
│   │   └── prediction_centre_advanced.html  # ML Prediction Centre with backtesting
│   ├── technical_analysis_enhanced.html     # Main technical analysis module
│   └── technical_analysis_desktop.html      # Desktop version with full charts
├── backend_fixed_v2.py               # Backend API server
├── requirements.txt                  # Python dependencies
├── windows_start.bat                 # Windows batch startup script
├── windows_start.ps1                 # PowerShell startup script
├── diagnostic_tool.html              # Connection diagnostic tool
├── WINDOWS_11_FIX_GUIDE.md          # Detailed troubleshooting guide
└── README.md                         # This file
```

## 🖥️ System Requirements

- **Windows 11** (also works on Windows 10)
- **Python 3.8+** with pip
- **Modern web browser** (Chrome, Edge, Firefox)
- **Internet connection** (for Yahoo Finance data)
- **Port 8002** available (backend API)

## 🌟 Features

### Technical Analysis Module
- Real-time Yahoo Finance data
- 150+ technical indicators
- ML-based predictions
- Candlestick charts
- Volume analysis
- Pattern recognition

### Prediction Centre
- 6 ML models (LSTM, ARIMA, Random Forest, XGBoost, Prophet, Ensemble)
- Comprehensive backtesting
- Learning metrics tracking
- Performance graphs
- Prediction history storage

### Desktop Version
- 4 chart libraries integration
- Full candlestick support
- Professional trading interface
- Dark theme optimized

## 🔧 Troubleshooting

### If backend won't start:
1. Check if Python is installed: `python --version`
2. Check if port 8002 is free: `netstat -an | findstr :8002`
3. Run as Administrator if needed
4. Check Windows Firewall settings

### If modules show connection errors:
1. Ensure backend is running (console window should stay open)
2. Open `diagnostic_tool.html` to test connections
3. Try using `127.0.0.1:8002` instead of `localhost:8002`
4. Disable antivirus temporarily for testing

### For detailed troubleshooting:
See `WINDOWS_11_FIX_GUIDE.md` for comprehensive solutions

## 🚦 First Time Setup

```batch
# 1. Open Command Prompt as Administrator
# 2. Navigate to extraction directory
cd C:\StockTracker\windows_11_deployment

# 3. Install Python packages
pip install -r requirements.txt

# 4. Start the backend
python backend_fixed_v2.py

# 5. Open HTML files in browser
```

## 🌐 URLs After Starting

- **Backend API:** http://localhost:8002
- **Test endpoint:** http://localhost:8002/api/stock/AAPL

Open these files directly in your browser:
- `modules\technical_analysis_enhanced.html`
- `modules\predictions\prediction_centre_advanced.html`
- `modules\technical_analysis_desktop.html`
- `diagnostic_tool.html`

## 📝 Important Notes

- **NO synthetic/mock data** - Uses real Yahoo Finance data only
- **Hardcoded localhost URLs** - Optimized for Windows 11 compatibility
- **No authentication required** - Development version
- **Data updates every 30 seconds** when markets are open

## 🆘 Support

For issues or questions:
1. Check `WINDOWS_11_FIX_GUIDE.md`
2. Run `diagnostic_tool.html` for connection testing
3. Review backend console for error messages
4. Ensure all prerequisites are installed

## 📊 Testing the System

1. Start backend with `windows_start.bat`
2. Open `diagnostic_tool.html` in browser
3. Click "Run All Tests" - all should show green
4. Open any module HTML file
5. Enter a stock symbol (e.g., AAPL, MSFT, TSLA)
6. Data should load within 2-3 seconds

## ✅ Verification Checklist

- [ ] Python 3.8+ installed
- [ ] Port 8002 available
- [ ] Backend starts without errors
- [ ] Diagnostic tool shows all green
- [ ] Modules load stock data successfully
- [ ] No CORS errors in browser console

---

**Version:** 5.0 - Windows 11 Fixed Edition
**Last Updated:** October 2025
**Status:** Production Ready