"""
Unified Paper Trading Dashboard
================================

Combined paper trading system with integrated dashboard and stock selection.

Features:
- Interactive stock selection via web interface
- Real-time paper trading with ML signals
- Live dashboard with portfolio tracking
- All-in-one: no need for separate terminals
- Easy stock selection: choose from UI or command line

Usage:
    python unified_trading_dashboard.py
    
    Or with pre-selected stocks:
    python unified_trading_dashboard.py --symbols RIO.AX,CBA.AX,BHP.AX --capital 100000
    
    Then open browser: http://localhost:8050
"""

import dash
from dash import dcc, html, Input, Output, State, callback_context
import plotly.graph_objs as go
from datetime import datetime, timedelta
import json
from pathlib import Path
import pandas as pd
import numpy as np
import logging
import threading
import time
import sys
from typing import Dict, List, Optional

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Create required directories
Path('logs').mkdir(exist_ok=True)
Path('state').mkdir(exist_ok=True)
Path('config').mkdir(exist_ok=True)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/unified_trading.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import paper trading coordinator
try:
    from paper_trading_coordinator import PaperTradingCoordinator
    PAPER_TRADING_AVAILABLE = True
except ImportError as e:
    logger.error(f"Could not import PaperTradingCoordinator: {e}")
    PAPER_TRADING_AVAILABLE = False

# Import market calendar
try:
    from ml_pipeline.market_calendar import MarketCalendar, Exchange, MarketStatus
    MARKET_CALENDAR_AVAILABLE = True
    market_calendar = MarketCalendar()
    logger.info("[CALENDAR] Market calendar initialized")
except ImportError as e:
    logger.error(f"Could not import MarketCalendar: {e}")
    MARKET_CALENDAR_AVAILABLE = False
    market_calendar = None

# Global trading system instance
trading_system = None
trading_thread = None
is_trading = False

# Initialize Dash app
app = dash.Dash(__name__, 
                meta_tags=[{'http-equiv': 'Cache-Control', 'content': 'no-cache, no-store, must-revalidate'}])
app.title = 'Unified Paper Trading Dashboard v1.3.3'

# Default stock options
STOCK_PRESETS = {
    'ASX Blue Chips': 'CBA.AX,BHP.AX,RIO.AX,WOW.AX,CSL.AX',
    'ASX Mining': 'RIO.AX,BHP.AX,FMG.AX,NCM.AX,S32.AX',
    'ASX Banks': 'CBA.AX,NAB.AX,WBC.AX,ANZ.AX',
    'US Tech Giants': 'AAPL,MSFT,GOOGL,NVDA,TSLA',
    'US Blue Chips': 'AAPL,JPM,JNJ,WMT,XOM',
    'US Growth': 'TSLA,NVDA,AMD,PLTR,SQ',
    'Global Mix': 'AAPL,MSFT,CBA.AX,BHP.AX,HSBA.L',
    'Custom': ''
}

# Create market status panel
def create_market_status_panel():
    """Create market status panel showing exchange hours and holidays"""
    if not MARKET_CALENDAR_AVAILABLE or market_calendar is None:
        return html.Div()  # Return empty if calendar not available
    
    # Get status for all exchanges
    asx_info = market_calendar.get_market_status(Exchange.ASX)
    nyse_info = market_calendar.get_market_status(Exchange.NYSE)
    lse_info = market_calendar.get_market_status(Exchange.LSE)
    
    def format_status_card(info):
        """Format individual exchange status card"""
        # Determine status color and icon
        if info.status == MarketStatus.OPEN:
            status_color = '#4CAF50'
            status_icon = '🟢'
            status_text = 'OPEN'
        elif info.status == MarketStatus.HOLIDAY:
            status_color = '#FF9800'
            status_icon = '🏖️'
            status_text = f'HOLIDAY - {info.holiday_name}'
        elif info.status == MarketStatus.WEEKEND:
            status_color = '#9E9E9E'
            status_icon = '📅'
            status_text = 'WEEKEND'
        elif info.status == MarketStatus.PRE_MARKET:
            status_color = '#2196F3'
            status_icon = '🔵'
            status_text = 'PRE-MARKET'
        elif info.status == MarketStatus.POST_MARKET:
            status_color = '#FF9800'
            status_icon = '🟡'
            status_text = 'POST-MARKET'
        else:
            status_color = '#F44336'
            status_icon = '🔴'
            status_text = 'CLOSED'
        
        # Format time information
        local_time_str = info.current_time.strftime('%H:%M %Z')
        
        # Calculate time to next event
        time_info = ""
        if info.status == MarketStatus.OPEN and info.time_to_close:
            hours = int(info.time_to_close.total_seconds() // 3600)
            minutes = int((info.time_to_close.total_seconds() % 3600) // 60)
            time_info = f"Closes in {hours}h {minutes}m"
        elif info.time_to_open:
            total_seconds = info.time_to_open.total_seconds()
            if total_seconds >= 86400:  # More than 24 hours
                days = int(total_seconds // 86400)
                hours = int((total_seconds % 86400) // 3600)
                time_info = f"Opens in {days}d {hours}h"
            else:
                hours = int(total_seconds // 3600)
                minutes = int((total_seconds % 3600) // 60)
                time_info = f"Opens in {hours}h {minutes}m"
        
        return html.Div([
            html.Div([
                html.H4(info.exchange.value, 
                       style={'color': '#ffffff', 'margin': '0 0 5px 0', 'fontSize': '16px'}),
                html.Div([
                    html.Span(status_icon, style={'marginRight': '5px'}),
                    html.Span(status_text, 
                             style={'color': status_color, 'fontWeight': 'bold', 'fontSize': '14px'})
                ], style={'marginBottom': '5px'}),
                html.P(local_time_str, 
                      style={'color': '#ccc', 'fontSize': '12px', 'margin': '3px 0'}),
                html.P(time_info if time_info else '  ', 
                      style={'color': '#888', 'fontSize': '11px', 'margin': '3px 0', 'minHeight': '15px'})
            ])
        ], style={
            'backgroundColor': '#1e1e1e',
            'padding': '15px',
            'borderRadius': '8px',
            'border': f'2px solid {status_color}',
            'flex': '1',
            'minWidth': '180px'
        })
    
    return html.Div([
        html.Div([
            html.H3('🕐 Market Hours & Status', 
                   style={'color': '#2196F3', 'margin': '0 0 15px 0', 'fontSize': '18px'}),
            html.Div([
                format_status_card(asx_info),
                format_status_card(nyse_info),
                format_status_card(lse_info)
            ], style={
                'display': 'flex',
                'gap': '15px',
                'flexWrap': 'wrap'
            })
        ])
    ], style={
        'backgroundColor': '#2a2a2a',
        'padding': '20px',
        'borderRadius': '10px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.2)'
    })

# Load state function
def load_state():
    """Load current trading state"""
    state_file = 'state/paper_trading_state.json'
    
    try:
        if Path(state_file).exists():
            with open(state_file, 'r') as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Error loading state: {e}")
    
    # Return default empty state
    return {
        'timestamp': datetime.now().isoformat(),
        'symbols': [],
        'capital': {
            'total': 0,
            'cash': 0,
            'invested': 0,
            'initial': 0,
            'total_return_pct': 0
        },
        'positions': {
            'count': 0,
            'open': [],
            'unrealized_pnl': 0
        },
        'performance': {
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'win_rate': 0,
            'realized_pnl': 0,
            'max_drawdown': 0
        },
        'market': {
            'sentiment': 50,
            'sentiment_class': 'neutral'
        },
        'intraday_alerts': [],
        'closed_trades': []
    }

# App Layout
app.layout = html.Div([
    # Header
    html.Div([
        html.H1('📈 Unified Paper Trading Dashboard', 
                style={'color': '#ffffff', 'margin': '0'}),
        html.P('All-in-One: Stock Selection + Paper Trading + Live Dashboard (v1.3.3)',
               style={'color': '#cccccc', 'margin': '5px 0 0 0'})
    ], style={
        'backgroundColor': '#1e1e1e',
        'padding': '20px',
        'marginBottom': '20px',
        'borderRadius': '10px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.2)'
    }),
    
    # Stock Selection Panel
    html.Div([
        html.Div([
            html.H3('🎯 Select Stocks to Trade', style={'color': '#4CAF50', 'margin': '0 0 15px 0'}),
            
            # Preset dropdown
            html.Div([
                html.Label('Quick Presets:', style={'color': '#ffffff', 'display': 'block', 'marginBottom': '5px'}),
                dcc.Dropdown(
                    id='preset-dropdown',
                    options=[{'label': k, 'value': v} for k, v in STOCK_PRESETS.items()],
                    value='',
                    placeholder='Select a preset or enter custom symbols',
                    style={'width': '100%', 'marginBottom': '15px'}
                )
            ]),
            
            # Stock symbols input
            html.Div([
                html.Label('Stock Symbols (comma-separated):', style={'color': '#ffffff', 'display': 'block', 'marginBottom': '5px'}),
                dcc.Input(
                    id='symbols-input',
                    type='text',
                    placeholder='e.g., RIO.AX,CBA.AX,BHP.AX',
                    style={'width': '100%', 'padding': '10px', 'fontSize': '14px', 'marginBottom': '15px'},
                    value=''
                )
            ]),
            
            # Capital input
            html.Div([
                html.Label('Initial Capital ($):', style={'color': '#ffffff', 'display': 'block', 'marginBottom': '5px'}),
                dcc.Input(
                    id='capital-input',
                    type='number',
                    placeholder='100000',
                    value=100000,
                    style={'width': '100%', 'padding': '10px', 'fontSize': '14px', 'marginBottom': '15px'}
                )
            ]),
            
            # Control buttons
            html.Div([
                html.Button('▶️ Start Trading', id='start-btn', n_clicks=0,
                           style={'backgroundColor': '#4CAF50', 'color': 'white', 'padding': '12px 30px',
                                  'border': 'none', 'borderRadius': '5px', 'fontSize': '16px',
                                  'marginRight': '10px', 'cursor': 'pointer'}),
                html.Button('⏸️ Stop Trading', id='stop-btn', n_clicks=0,
                           style={'backgroundColor': '#F44336', 'color': 'white', 'padding': '12px 30px',
                                  'border': 'none', 'borderRadius': '5px', 'fontSize': '16px',
                                  'cursor': 'pointer'})
            ], style={'marginTop': '10px'}),
            
            # Status message
            html.Div(id='status-message', 
                    style={'color': '#ffffff', 'marginTop': '15px', 'padding': '10px',
                           'backgroundColor': '#1e1e1e', 'borderRadius': '5px'})
            
        ], style={'flex': '1', 'marginRight': '20px'}),
        
        # Quick Guide
        html.Div([
            html.H3('💡 Quick Guide', style={'color': '#2196F3', 'margin': '0 0 15px 0'}),
            html.Div([
                html.P([html.Strong('Symbol Format:')], style={'color': '#ffffff', 'margin': '5px 0'}),
                html.P('• ASX: SYMBOL.AX (e.g., CBA.AX)', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                html.P('• US: SYMBOL (e.g., AAPL)', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                html.P('• UK: SYMBOL.L (e.g., HSBA.L)', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                
                html.P([html.Strong('How it works:')], style={'color': '#ffffff', 'margin': '15px 0 5px 0'}),
                html.P('1. Select preset or enter symbols', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                html.P('2. Set initial capital', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                html.P('3. Click "Start Trading"', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
                html.P('4. Watch live dashboard below', style={'color': '#ccc', 'margin': '3px 0 3px 15px', 'fontSize': '13px'}),
            ])
        ], style={'flex': '1', 'backgroundColor': '#1e1e1e', 'padding': '20px', 'borderRadius': '10px'})
        
    ], style={
        'backgroundColor': '#2a2a2a',
        'padding': '20px',
        'marginBottom': '20px',
        'borderRadius': '10px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
        'display': 'flex',
        'gap': '20px'
    }),
    
    # Auto-refresh
    dcc.Interval(
        id='interval-component',
        interval=5*1000,  # Update every 5 seconds
        n_intervals=0
    ),
    
    # Current Trading Info
    html.Div(id='trading-info-panel', style={'marginBottom': '20px'}),
    
    # Market Status Panel
    html.Div(id='market-status-panel', style={'marginBottom': '20px'}),
    
    # Top metrics row
    html.Div([
        # Total Capital
        html.Div([
            html.H3('Total Capital', style={'color': '#888', 'fontSize': '14px', 'margin': '0'}),
            html.H2(id='total-capital', style={'color': '#4CAF50', 'margin': '10px 0'}),
            html.P(id='total-return', style={'color': '#888', 'fontSize': '14px', 'margin': '0'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '1',
            'margin': '0 10px'
        }),
        
        # Open Positions
        html.Div([
            html.H3('Open Positions', style={'color': '#888', 'fontSize': '14px', 'margin': '0'}),
            html.H2(id='position-count', style={'color': '#2196F3', 'margin': '10px 0'}),
            html.P(id='unrealized-pnl', style={'color': '#888', 'fontSize': '14px', 'margin': '0'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '1',
            'margin': '0 10px'
        }),
        
        # Win Rate
        html.Div([
            html.H3('Win Rate', style={'color': '#888', 'fontSize': '14px', 'margin': '0'}),
            html.H2(id='win-rate', style={'color': '#FF9800', 'margin': '10px 0'}),
            html.P(id='total-trades', style={'color': '#888', 'fontSize': '14px', 'margin': '0'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '1',
            'margin': '0 10px'
        }),
        
        # Market Sentiment
        html.Div([
            html.H3('Market Sentiment', style={'color': '#888', 'fontSize': '14px', 'margin': '0'}),
            html.H2(id='market-sentiment', style={'color': '#9C27B0', 'margin': '10px 0'}),
            html.P(id='sentiment-class', style={'color': '#888', 'fontSize': '14px', 'margin': '0'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '1',
            'margin': '0 10px'
        })
    ], style={'display': 'flex', 'marginBottom': '20px'}),
    
    # Charts and positions
    html.Div([
        # Portfolio chart
        html.Div([
            html.H3('Portfolio Value', style={'color': '#ffffff', 'marginBottom': '15px'}),
            dcc.Graph(
                id='portfolio-chart',
                config={
                    'displayModeBar': False,
                    'staticPlot': False,
                    'responsive': False
                }
            )
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '2',
            'margin': '0 10px',
            'minWidth': '500px'
        }),
        
        # Performance chart
        html.Div([
            html.H3('Performance', style={'color': '#ffffff', 'marginBottom': '15px'}),
            dcc.Graph(
                id='performance-chart',
                config={
                    'displayModeBar': False,
                    'staticPlot': False,
                    'responsive': False
                }
            )
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'flex': '1',
            'margin': '0 10px',
            'minWidth': '300px'
        })
    ], style={'display': 'flex', 'marginBottom': '20px'}),
    
    # Positions list
    html.Div([
        html.H3('Open Positions', style={'color': '#ffffff', 'marginBottom': '15px'}),
        html.Div(id='positions-list')
    ], style={
        'backgroundColor': '#2a2a2a',
        'padding': '20px',
        'borderRadius': '10px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
        'marginBottom': '20px'
    }),
    
    # Tax Reports Panel
    html.Div([
        html.H3('📊 Tax Reports (ATO Compliant)', style={'color': '#ffffff', 'marginBottom': '15px'}),
        html.Div([
            # Financial Year Selector
            html.Div([
                html.Label('Financial Year:', style={'color': '#ffffff', 'display': 'block', 'marginBottom': '5px'}),
                dcc.Dropdown(
                    id='fy-dropdown',
                    options=[
                        {'label': 'FY 2024-25', 'value': '2024-25'},
                        {'label': 'FY 2025-26', 'value': '2025-26'},
                        {'label': 'FY 2026-27', 'value': '2026-27'},
                        {'label': 'Current FY', 'value': 'current'}
                    ],
                    value='current',
                    style={'width': '200px', 'marginBottom': '15px'}
                )
            ], style={'marginRight': '20px'}),
            
            # Generate Buttons
            html.Div([
                html.Button('📄 Generate ATO Report', id='generate-ato-btn', n_clicks=0,
                           style={'backgroundColor': '#2196F3', 'color': 'white', 'padding': '10px 20px',
                                  'border': 'none', 'borderRadius': '5px', 'fontSize': '14px',
                                  'marginRight': '10px', 'cursor': 'pointer'}),
                html.Button('💾 Export CSV', id='export-csv-btn', n_clicks=0,
                           style={'backgroundColor': '#4CAF50', 'color': 'white', 'padding': '10px 20px',
                                  'border': 'none', 'borderRadius': '5px', 'fontSize': '14px',
                                  'cursor': 'pointer'})
            ], style={'display': 'flex'}),
        ], style={'display': 'flex', 'alignItems': 'flex-end', 'marginBottom': '15px'}),
        
        # Tax Summary Display
        html.Div(id='tax-summary', style={'color': '#ffffff', 'padding': '15px', 
                                          'backgroundColor': '#1e1e1e', 'borderRadius': '5px',
                                          'marginTop': '15px'}),
        
        # Report Status
        html.Div(id='tax-report-status', style={'color': '#4CAF50', 'marginTop': '10px'})
        
    ], style={
        'backgroundColor': '#2a2a2a',
        'padding': '20px',
        'borderRadius': '10px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
        'marginBottom': '20px'
    }),
    
    # Footer
    html.Div([
        html.P(id='last-update', style={'color': '#888', 'textAlign': 'center', 'margin': '0'})
    ], style={
        'backgroundColor': '#1e1e1e',
        'padding': '15px',
        'borderRadius': '10px'
    })
    
], style={
    'backgroundColor': '#121212',
    'minHeight': '100vh',
    'padding': '20px',
    'fontFamily': 'Arial, sans-serif'
})

# Callbacks

# Update symbols input when preset selected
@app.callback(
    Output('symbols-input', 'value'),
    Input('preset-dropdown', 'value'),
    prevent_initial_call=True
)
def update_symbols_from_preset(preset_value):
    """Update symbols input when preset is selected"""
    if preset_value:
        return preset_value
    return ''

# Start/Stop trading
@app.callback(
    Output('status-message', 'children'),
    [Input('start-btn', 'n_clicks'),
     Input('stop-btn', 'n_clicks')],
    [State('symbols-input', 'value'),
     State('capital-input', 'value')],
    prevent_initial_call=True
)
def control_trading(start_clicks, stop_clicks, symbols_str, capital):
    """Start or stop paper trading"""
    global trading_system, trading_thread, is_trading
    
    ctx = callback_context
    if not ctx.triggered:
        return "Ready to start"
    
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if button_id == 'start-btn':
        # Validation
        if not symbols_str or not symbols_str.strip():
            return html.Div("[ERROR] Please enter at least one stock symbol", 
                          style={'color': '#F44336'})
        
        if not capital or capital <= 0:
            return html.Div("[ERROR] Please enter a valid capital amount", 
                          style={'color': '#F44336'})
        
        # Parse symbols
        symbols = [s.strip().upper() for s in symbols_str.split(',') if s.strip()]
        
        if not symbols:
            return html.Div("[ERROR] No valid symbols found", 
                          style={'color': '#F44336'})
        
        # Stop existing trading if running
        if is_trading:
            is_trading = False
            if trading_thread and trading_thread.is_alive():
                trading_thread.join(timeout=2)
        
        # Create new trading system
        try:
            if not PAPER_TRADING_AVAILABLE:
                return html.Div("[ERROR] Paper trading module not available", 
                              style={'color': '#F44336'})
            
            trading_system = PaperTradingCoordinator(
                symbols=symbols,
                initial_capital=float(capital),
                use_real_swing_signals=True
            )
            
            # Start trading in background thread
            is_trading = True
            trading_thread = threading.Thread(
                target=run_trading_loop,
                args=(trading_system,),
                daemon=True
            )
            trading_thread.start()
            
            return html.Div([
                html.P("[OK] Trading Started!", style={'color': '#4CAF50', 'fontWeight': 'bold', 'margin': '0 0 5px 0'}),
                html.P(f"Symbols: {', '.join(symbols)}", style={'color': '#ffffff', 'margin': '0'}),
                html.P(f"Capital: ${capital:,.2f}", style={'color': '#ffffff', 'margin': '0'})
            ])
            
        except Exception as e:
            logger.error(f"Error starting trading: {e}")
            return html.Div(f"[ERROR] Starting trading: {str(e)}", 
                          style={'color': '#F44336'})
    
    elif button_id == 'stop-btn':
        if is_trading:
            is_trading = False
            if trading_thread and trading_thread.is_alive():
                trading_thread.join(timeout=2)
            
            return html.Div("⏸️ Trading Stopped", 
                          style={'color': '#FF9800', 'fontWeight': 'bold'})
        else:
            return html.Div("ℹ️ Trading is not running", 
                          style={'color': '#888'})
    
    return "Ready to start"

def run_trading_loop(system):
    """Run trading system in background"""
    global is_trading
    
    try:
        cycle = 0
        while is_trading:
            cycle += 1
            logger.info(f"[CYCLE] Trading cycle {cycle}")
            
            # Run one trading cycle
            system.run_single_cycle()
            
            # Save state
            system.save_state()
            
            # Wait before next cycle (60 seconds)
            for _ in range(60):
                if not is_trading:
                    break
                time.sleep(1)
                
    except Exception as e:
        logger.error(f"[ERROR] Error in trading loop: {e}")
        is_trading = False

# Update dashboard
@app.callback(
    [
        Output('trading-info-panel', 'children'),
        Output('market-status-panel', 'children'),
        Output('total-capital', 'children'),
        Output('total-return', 'children'),
        Output('position-count', 'children'),
        Output('unrealized-pnl', 'children'),
        Output('win-rate', 'children'),
        Output('total-trades', 'children'),
        Output('market-sentiment', 'children'),
        Output('sentiment-class', 'children'),
        Output('portfolio-chart', 'figure'),
        Output('performance-chart', 'figure'),
        Output('positions-list', 'children'),
        Output('last-update', 'children')
    ],
    Input('interval-component', 'n_intervals')
)
def update_dashboard(n):
    """Update all dashboard components"""
    state = load_state()
    
    # Market Status Panel
    market_status_content = create_market_status_panel()
    
    # Trading info panel
    if state['symbols'] and len(state['symbols']) > 0:
        trading_info = html.Div([
            html.H3('📊 Currently Trading', style={'color': '#4CAF50', 'margin': '0 0 10px 0'}),
            html.P(', '.join(state['symbols']), 
                  style={'color': '#ffffff', 'fontSize': '18px', 'fontWeight': 'bold', 'margin': '0'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'boxShadow': '0 2px 4px rgba(0,0,0,0.2)',
            'textAlign': 'center'
        })
    else:
        trading_info = html.Div([
            html.P('No active trading session. Select stocks and click "Start Trading" above.', 
                  style={'color': '#888', 'textAlign': 'center'})
        ], style={
            'backgroundColor': '#2a2a2a',
            'padding': '20px',
            'borderRadius': '10px',
            'textAlign': 'center'
        })
    
    # Top metrics
    total_capital = f"${state['capital']['total']:,.2f}"
    total_return = f"Return: {state['capital']['total_return_pct']:+.2f}%"
    
    position_count = str(state['positions']['count'])
    unrealized_pnl = f"Unrealized P&L: ${state['positions']['unrealized_pnl']:+,.2f}"
    
    win_rate = f"{state['performance']['win_rate']:.1f}%"
    total_trades = f"{state['performance']['total_trades']} trades"
    
    market_sentiment = f"{state['market']['sentiment']:.1f}"
    sentiment_class = state['market']['sentiment_class'].upper()
    
    # Portfolio chart
    portfolio_fig = go.Figure()
    
    # Generate 30-day history (simplified for now)
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    initial = state['capital']['initial'] if state['capital']['initial'] > 0 else 100000
    current = state['capital']['total'] if state['capital']['total'] > 0 else initial
    values = np.linspace(initial, current, 30)
    
    portfolio_fig.add_trace(go.Scatter(
        x=dates,
        y=values,
        mode='lines',
        name='Portfolio Value',
        line=dict(color='#4CAF50', width=2),
        fill='tozeroy',
        fillcolor='rgba(76, 175, 80, 0.2)'
    ))
    
    portfolio_fig.update_layout(
        plot_bgcolor='#1e1e1e',
        paper_bgcolor='#2a2a2a',
        font=dict(color='#ffffff'),
        xaxis=dict(
            showgrid=False, 
            zeroline=False, 
            fixedrange=True,
            automargin=False
        ),
        yaxis=dict(
            showgrid=True, 
            gridcolor='#333', 
            zeroline=False,
            fixedrange=True,
            range=[initial * 0.95, max(current * 1.05, initial * 1.05)],
            automargin=False,
            tickformat='$,.0f'
        ),
        margin=dict(l=80, r=30, t=30, b=50, autoexpand=False),
        showlegend=False,
        height=250,
        width=650,
        autosize=False,
        hovermode='x unified',
        uirevision='portfolio_chart_v1'
    )
    
    # Performance chart
    perf = state['performance']
    
    performance_fig = go.Figure(data=[go.Pie(
        labels=['Wins', 'Losses', 'Open'],
        values=[
            perf['winning_trades'],
            perf['losing_trades'],
            state['positions']['count']
        ],
        marker=dict(colors=['#4CAF50', '#F44336', '#2196F3']),
        hole=0.4
    )])
    
    performance_fig.update_layout(
        plot_bgcolor='#1e1e1e',
        paper_bgcolor='#2a2a2a',
        font=dict(color='#ffffff'),
        margin=dict(l=20, r=20, t=20, b=20, autoexpand=False),
        showlegend=True,
        height=250,
        width=350,
        autosize=False,
        uirevision='performance_chart_v1'
    )
    
    # Positions list
    positions_children = []
    
    if state['positions']['open']:
        for pos in state['positions']['open']:
            pnl_pct = pos.get('unrealized_pnl_pct', 0)
            pnl_color = '#4CAF50' if pnl_pct >= 0 else '#F44336'
            
            positions_children.append(
                html.Div([
                    html.Div([
                        html.H4(pos['symbol'], style={'color': '#ffffff', 'margin': '0'}),
                        html.P(f"{pos['shares']} shares @ ${pos['entry_price']:.2f}", 
                              style={'color': '#888', 'margin': '5px 0', 'fontSize': '13px'})
                    ], style={'flex': '1'}),
                    
                    html.Div([
                        html.H4(f"${pos.get('current_price', pos['entry_price']):.2f}", 
                               style={'color': '#ffffff', 'margin': '0', 'textAlign': 'right'}),
                        html.P(f"{pnl_pct:+.2f}%", 
                              style={'color': pnl_color, 'margin': '5px 0', 'fontSize': '13px', 'textAlign': 'right'})
                    ], style={'flex': '1'})
                ], style={
                    'backgroundColor': '#1e1e1e',
                    'padding': '15px',
                    'marginBottom': '10px',
                    'borderRadius': '5px',
                    'display': 'flex',
                    'borderLeft': f'4px solid {pnl_color}'
                })
            )
    else:
        positions_children.append(
            html.Div("No open positions", 
                    style={'color': '#888', 'textAlign': 'center', 'padding': '20px'})
        )
    
    # Last update
    last_update = f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    return (
        trading_info,
        market_status_content,
        total_capital, total_return,
        position_count, unrealized_pnl,
        win_rate, total_trades,
        market_sentiment, sentiment_class,
        portfolio_fig, performance_fig,
        positions_children,
        last_update
    )

# Tax report callbacks
@app.callback(
    [Output('tax-summary', 'children'),
     Output('tax-report-status', 'children')],
    [Input('generate-ato-btn', 'n_clicks'),
     Input('export-csv-btn', 'n_clicks'),
     Input('fy-dropdown', 'value')],
    prevent_initial_call=True
)
def handle_tax_reports(ato_clicks, csv_clicks, financial_year):
    """Handle tax report generation"""
    global trading_system
    
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update
    
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if not trading_system or not hasattr(trading_system, 'tax_audit') or not trading_system.tax_audit:
        return (
            html.Div("Tax audit trail not available. Start trading to initialize.", 
                    style={'color': '#FF9800', 'textAlign': 'center'}),
            ""
        )
    
    fy = None if financial_year == 'current' else financial_year
    
    try:
        # Generate summary first
        summary = trading_system.get_tax_summary(fy)
        
        if not summary:
            summary_html = html.Div("No transactions recorded yet.", 
                                   style={'color': '#888', 'textAlign': 'center'})
        else:
            summary_html = html.Div([
                html.H4(f"Tax Summary - FY {summary['financial_year']}", 
                       style={'color': '#4CAF50', 'marginBottom': '10px'}),
                html.Div([
                    html.Div([
                        html.P('Net Capital Gain:', style={'color': '#888', 'margin': '5px 0'}),
                        html.P(f"${summary['net_capital_gain']:,.2f}", 
                              style={'color': '#4CAF50', 'fontSize': '18px', 'fontWeight': 'bold'})
                    ], style={'flex': '1'}),
                    html.Div([
                        html.P('CGT Discount:', style={'color': '#888', 'margin': '5px 0'}),
                        html.P(f"${summary['cgt_discount']:,.2f}", 
                              style={'color': '#2196F3', 'fontSize': '18px', 'fontWeight': 'bold'})
                    ], style={'flex': '1'}),
                    html.Div([
                        html.P('Net After Discount:', style={'color': '#888', 'margin': '5px 0'}),
                        html.P(f"${summary['net_after_discount']:,.2f}", 
                              style={'color': '#FF9800', 'fontSize': '18px', 'fontWeight': 'bold'})
                    ], style={'flex': '1'}),
                    html.Div([
                        html.P('Total Trades:', style={'color': '#888', 'margin': '5px 0'}),
                        html.P(f"{summary['trading_activity']['total_transactions']}", 
                              style={'color': '#9C27B0', 'fontSize': '18px', 'fontWeight': 'bold'})
                    ], style={'flex': '1'})
                ], style={'display': 'flex', 'gap': '20px', 'marginTop': '10px'})
            ])
        
        status = ""
        
        # Handle button clicks
        if trigger_id == 'generate-ato-btn':
            report_path = trading_system.generate_tax_report(fy)
            if report_path:
                status = f"✓ ATO Report generated: {report_path}"
            else:
                status = "⚠️ Failed to generate ATO report"
        
        elif trigger_id == 'export-csv-btn':
            export_path = trading_system.export_tax_records(fy, format='csv')
            if export_path:
                status = f"✓ Transactions exported: {export_path}"
            else:
                status = "⚠️ Failed to export transactions"
        
        return summary_html, status
        
    except Exception as e:
        logger.error(f"Tax report error: {e}")
        return (
            html.Div(f"Error: {str(e)}", style={'color': '#F44336', 'textAlign': 'center'}),
            "⚠️ Error generating tax reports"
        )

if __name__ == '__main__':
    logger.info("Starting Unified Paper Trading Dashboard...")
    logger.info("Open browser to: http://localhost:8050")
    
    # Run app
    app.run(
        debug=False,
        host='0.0.0.0',
        port=8050,
        load_dotenv=False
    )
