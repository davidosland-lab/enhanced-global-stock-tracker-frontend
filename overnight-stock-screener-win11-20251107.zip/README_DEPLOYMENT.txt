# Overnight Stock Screener - Windows 11 Package

## Quick Start

1. Extract this ZIP to a folder (e.g., C:\overnight-stock-screener\)
2. Install Python 3.9+ from python.org
3. Open Command Prompt in the extracted folder
4. Run: python -m venv venv
5. Run: venv\Scripts\activate
6. Run: pip install -r requirements.txt
7. Test: RUN_OVERNIGHT_SCREENER_TEST.bat

## Full Documentation

See DEPLOYMENT_GUIDE.md for complete setup instructions.

## Contents

- models/           - Core screening modules
- scripts/          - Test and utility scripts
- *.bat             - Windows batch scripts
- requirements.txt  - Python dependencies
- DEPLOYMENT_GUIDE.md - Full deployment guide

## Support

Check logs/ directory for execution logs.
Run CHECK_SCREENER_STATUS.bat for system status.

## Version

Phase 3 Complete - Full Automation with Email Notifications and LSTM Training
Date: 2025-11-07
