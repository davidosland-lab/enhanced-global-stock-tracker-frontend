"""
FinBERT Models Package
Core models for LSTM prediction, sentiment analysis, and news processing.
"""
