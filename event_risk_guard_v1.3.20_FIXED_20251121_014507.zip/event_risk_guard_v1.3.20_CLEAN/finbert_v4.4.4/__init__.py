"""
FinBERT v4.4.4 Package
Financial BERT-based models for sentiment analysis and stock prediction.
"""

__version__ = "4.4.4"
