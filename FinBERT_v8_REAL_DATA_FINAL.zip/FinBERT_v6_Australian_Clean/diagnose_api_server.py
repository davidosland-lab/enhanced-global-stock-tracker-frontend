#!/usr/bin/env python3
"""
Diagnostic tool to test the API server and identify exactly where the database error occurs
"""

import os
import sys
import traceback
import json
from pathlib import Path

print("=" * 80)
print("API SERVER DIAGNOSTIC - Testing Data Fetching")
print("=" * 80)

# 1. Check current environment
print("\n1. ENVIRONMENT CHECK:")
print(f"   Current directory: {os.getcwd()}")
print(f"   YFINANCE_CACHE_DISABLE: {os.environ.get('YFINANCE_CACHE_DISABLE', 'NOT SET')}")
print(f"   REQUESTS_CACHE_DISABLED: {os.environ.get('REQUESTS_CACHE_DISABLED', 'NOT SET')}")

# 2. Test importing modules
print("\n2. TESTING MODULE IMPORTS:")
modules_ok = True

try:
    import yfinance as yf
    print(f"   ✓ yfinance imported (v{yf.__version__})")
except ImportError as e:
    print(f"   ✗ Failed to import yfinance: {e}")
    modules_ok = False

try:
    import pandas as pd
    print(f"   ✓ pandas imported (v{pd.__version__})")
except ImportError as e:
    print(f"   ✗ Failed to import pandas: {e}")
    modules_ok = False

try:
    import numpy as np
    print(f"   ✓ numpy imported (v{np.__version__})")
except ImportError as e:
    print(f"   ✗ Failed to import numpy: {e}")
    modules_ok = False

if not modules_ok:
    print("\n⚠️  Required modules missing. Cannot continue.")
    sys.exit(1)

# 3. Test direct yfinance data fetching
print("\n3. TESTING DIRECT YFINANCE DATA FETCHING:")

test_symbols = ["AAPL", "CBA.AX", "MSFT"]

for symbol in test_symbols:
    print(f"\n   Testing {symbol}:")
    try:
        ticker = yf.Ticker(symbol)
        print(f"      ✓ Created ticker object")
        
        # Try to get info (this often doesn't trigger cache)
        try:
            info = ticker.info
            if info:
                print(f"      ✓ Got info - Name: {info.get('longName', 'N/A')}")
        except Exception as e:
            print(f"      ✗ Failed to get info: {e}")
        
        # Try to get history (this usually triggers cache/database)
        try:
            print(f"      Attempting to fetch history...")
            history = ticker.history(period="1d")
            
            if not history.empty:
                latest_close = history['Close'].iloc[-1]
                print(f"      ✓ Got history - Latest close: ${latest_close:.2f}")
            else:
                print(f"      ✗ History returned empty")
                
        except Exception as e:
            print(f"      ✗ Failed to get history: {e}")
            if "database disk image is malformed" in str(e):
                print(f"      🔴 DATABASE CORRUPTION DETECTED!")
                # Try to identify the exact location
                import traceback
                tb_str = traceback.format_exc()
                if ".cache" in tb_str:
                    print(f"      Cache location found in traceback")
                print(f"      Full error trace:")
                print(traceback.format_exc())
                
    except Exception as e:
        print(f"      ✗ Failed to create ticker: {e}")

# 4. Test with explicit cache disable in code
print("\n4. TESTING WITH CACHE EXPLICITLY DISABLED IN CODE:")

# Force disable cache
os.environ['YFINANCE_CACHE_DISABLE'] = '1'
os.environ['REQUESTS_CACHE_DISABLED'] = '1'

# Reimport yfinance to apply settings
if 'yfinance' in sys.modules:
    del sys.modules['yfinance']
    
import yfinance as yf

for symbol in ["AAPL", "CBA.AX"]:
    print(f"\n   Testing {symbol} with cache disabled:")
    try:
        ticker = yf.Ticker(symbol)
        history = ticker.history(period="1d")
        
        if not history.empty:
            latest_close = history['Close'].iloc[-1]
            print(f"      ✓ SUCCESS: Latest close: ${latest_close:.2f}")
        else:
            print(f"      ✗ No data returned")
            
    except Exception as e:
        print(f"      ✗ ERROR: {e}")
        if "database disk image is malformed" in str(e):
            print(f"      🔴 STILL GETTING DATABASE ERROR WITH CACHE DISABLED!")

# 5. Test the actual API functions
print("\n5. TESTING API SERVER FUNCTIONS:")

# Import the API functions
try:
    # First, check if the API file exists
    api_file = Path("app_finbert_api_v5_TRULY_FIXED.py")
    if not api_file.exists():
        print(f"   ✗ API file not found: {api_file}")
    else:
        print(f"   ✓ API file found: {api_file}")
        
        # Try to import the calculate functions
        sys.path.insert(0, str(Path.cwd()))
        
        try:
            from app_finbert_api_v5_TRULY_FIXED import calculate_rsi, calculate_macd, calculate_atr
            print(f"   ✓ Successfully imported calculation functions")
            
            # Test the functions with sample data
            import numpy as np
            test_prices = np.array([100, 102, 101, 103, 104, 102, 105, 106, 104, 107])
            
            rsi = calculate_rsi(test_prices)
            print(f"   ✓ RSI calculation works: {rsi:.2f}")
            
            macd_line, signal_line, histogram = calculate_macd(test_prices)
            print(f"   ✓ MACD calculation works: MACD={macd_line:.4f}")
            
            test_high = test_prices + 1
            test_low = test_prices - 1
            atr = calculate_atr(test_high, test_low, test_prices)
            print(f"   ✓ ATR calculation works: {atr:.2f}")
            
        except ImportError as e:
            print(f"   ✗ Failed to import API functions: {e}")
        except Exception as e:
            print(f"   ✗ Error testing functions: {e}")
            
except Exception as e:
    print(f"   ✗ Error testing API: {e}")

# 6. Test alternative data fetching methods
print("\n6. TESTING ALTERNATIVE DATA FETCHING METHODS:")

print("\n   Method 1: Using download function instead of Ticker:")
try:
    import yfinance as yf
    data = yf.download("AAPL", period="1d", progress=False)
    if not data.empty:
        close = data['Close'].iloc[-1]
        print(f"      ✓ yf.download() works: AAPL close ${close:.2f}")
    else:
        print(f"      ✗ yf.download() returned empty data")
except Exception as e:
    print(f"      ✗ yf.download() failed: {e}")

print("\n   Method 2: Direct HTTP request to Yahoo Finance:")
try:
    import requests
    
    # Yahoo Finance API endpoint
    url = "https://query1.finance.yahoo.com/v8/finance/chart/AAPL"
    headers = {'User-Agent': 'Mozilla/5.0'}
    
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        if 'chart' in data and 'result' in data['chart']:
            result = data['chart']['result'][0]
            if 'meta' in result and 'regularMarketPrice' in result['meta']:
                price = result['meta']['regularMarketPrice']
                print(f"      ✓ Direct HTTP request works: AAPL price ${price:.2f}")
            else:
                print(f"      ✗ No price in response")
        else:
            print(f"      ✗ Unexpected response structure")
    else:
        print(f"      ✗ HTTP request failed: {response.status_code}")
except Exception as e:
    print(f"      ✗ Direct HTTP failed: {e}")

# 7. Identify cache locations
print("\n7. IDENTIFYING CACHE LOCATIONS:")

import platform
if platform.system() == "Windows":
    userprofile = os.environ.get('USERPROFILE', '')
    possible_caches = [
        Path(userprofile) / '.cache' / 'py-yfinance',
        Path(userprofile) / 'AppData' / 'Local' / 'py-yfinance',
        Path(userprofile) / 'AppData' / 'Roaming' / 'py-yfinance',
    ]
else:
    home = Path.home()
    possible_caches = [
        home / '.cache' / 'py-yfinance',
        home / '.cache' / 'yfinance',
    ]

print("   Checking for cache directories:")
found_caches = []
for cache_dir in possible_caches:
    if cache_dir.exists():
        print(f"      📁 Found: {cache_dir}")
        found_caches.append(cache_dir)
        
        # List contents
        for item in cache_dir.iterdir():
            size = item.stat().st_size if item.is_file() else "DIR"
            print(f"         └─ {item.name} ({size})")

# 8. Summary and recommendations
print("\n" + "=" * 80)
print("DIAGNOSTIC SUMMARY:")
print("=" * 80)

print("\n📊 TEST RESULTS:")
print("   - Module imports: ✓")
print("   - Direct yfinance: Check results above")
print("   - Cache disabled: Check results above")
print("   - Alternative methods: Check results above")

if found_caches:
    print(f"\n⚠️  CACHE DIRECTORIES FOUND:")
    for cache in found_caches:
        print(f"   - {cache}")
    
    print("\n📋 RECOMMENDED FIX:")
    print("   1. Delete all cache directories listed above")
    print("   2. Use one of these methods in your code:")
    print("      a) Use yf.download() instead of Ticker.history()")
    print("      b) Make direct HTTP requests to Yahoo Finance")
    print("      c) Set environment variables AND delete cache")

print("\n💡 CODE FIX SUGGESTION:")
print("   Replace ticker.history() calls with yf.download():")
print("   OLD: history = ticker.history(period='3mo')")
print("   NEW: history = yf.download(symbol, period='3mo', progress=False)")

print("\n" + "=" * 80)