#!/usr/bin/env python3
"""
Debug script for CBA.AX data issues
"""

import yfinance as yf
import json
import sys

def test_cba_data():
    """Test if CBA.AX data can be fetched"""
    
    print("=" * 60)
    print("Testing CBA.AX Data Fetching")
    print("=" * 60)
    
    symbol = "CBA.AX"
    
    try:
        # Test basic ticker
        print(f"\n1. Creating ticker for {symbol}...")
        ticker = yf.Ticker(symbol)
        print("✅ Ticker created")
        
        # Test info
        print(f"\n2. Fetching info for {symbol}...")
        info = ticker.info
        if info:
            print(f"✅ Info fetched")
            print(f"   Company: {info.get('longName', 'N/A')}")
            print(f"   Current Price: ${info.get('currentPrice', 'N/A')}")
            print(f"   Regular Market Price: ${info.get('regularMarketPrice', 'N/A')}")
            print(f"   Previous Close: ${info.get('previousClose', 'N/A')}")
        else:
            print("⚠️ Info is empty")
        
        # Test history
        print(f"\n3. Fetching 3-month history for {symbol}...")
        history = ticker.history(period="3mo")
        
        if not history.empty:
            print(f"✅ History fetched: {len(history)} days")
            print(f"   Latest close: ${history['Close'].iloc[-1]:.2f}")
            print(f"   Latest date: {history.index[-1]}")
            print(f"   Latest volume: {history['Volume'].iloc[-1]:,.0f}")
            
            # Show last 5 days
            print("\n   Last 5 days:")
            for i in range(min(5, len(history))):
                idx = -(i+1)
                print(f"   {history.index[idx].strftime('%Y-%m-%d')}: "
                      f"Close=${history['Close'].iloc[idx]:.2f}, "
                      f"Volume={history['Volume'].iloc[idx]:,.0f}")
        else:
            print("❌ History is empty!")
            
        # Test 1-month history
        print(f"\n4. Testing 1-month history...")
        history_1m = ticker.history(period="1mo")
        if not history_1m.empty:
            print(f"✅ 1-month history: {len(history_1m)} days")
        else:
            print("❌ 1-month history is empty!")
            
        # Test different intervals
        print(f"\n5. Testing different intervals...")
        for interval in ['1d', '1h', '5m']:
            try:
                hist = ticker.history(period="5d", interval=interval)
                if not hist.empty:
                    print(f"   ✅ {interval} interval: {len(hist)} data points")
                else:
                    print(f"   ❌ {interval} interval: empty")
            except Exception as e:
                print(f"   ❌ {interval} interval: {e}")
        
        # Test news
        print(f"\n6. Fetching news...")
        try:
            news = ticker.news
            if news:
                print(f"✅ Found {len(news)} news articles")
                if len(news) > 0:
                    print(f"   Latest: {news[0].get('title', 'N/A')[:60]}...")
            else:
                print("⚠️ No news found")
        except Exception as e:
            print(f"❌ News fetch error: {e}")
            
        # Alternative symbol test
        print(f"\n7. Testing alternative symbol formats...")
        for alt_symbol in ["CBA.AX", "CBA.ASX", "CBA", "CBA.AU"]:
            try:
                alt_ticker = yf.Ticker(alt_symbol)
                alt_hist = alt_ticker.history(period="1d")
                if not alt_hist.empty:
                    print(f"   ✅ {alt_symbol}: ${alt_hist['Close'].iloc[-1]:.2f}")
                else:
                    print(f"   ❌ {alt_symbol}: No data")
            except Exception as e:
                print(f"   ❌ {alt_symbol}: Error - {e}")
                
        return True
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_api_response_format():
    """Test what the API should return"""
    print("\n" + "=" * 60)
    print("Expected API Response Format")
    print("=" * 60)
    
    expected = {
        "symbol": "CBA.AX",
        "currentPrice": 155.23,  # Example
        "price": 155.23,
        "previousClose": 154.80,
        "change": 0.43,
        "changePercent": 0.28,
        "dayHigh": 156.00,
        "dayLow": 154.50,
        "volume": 2500000,
        "RSI": 55.5,
        "MACD": {"macd": 1.2, "signal": 1.1, "histogram": 0.1},
        "ATR": 2.5,
        "SMA_20": 154.00,
        "SMA_50": 152.00
    }
    
    print("Frontend expects these fields:")
    for key in expected.keys():
        print(f"  • {key}")
    
    print("\nCritical fields for display:")
    print("  • currentPrice (or price) - for price display")
    print("  • RSI, MACD, ATR - for indicators")
    print("  • SMA_20, SMA_50 - for moving averages")

if __name__ == "__main__":
    success = test_cba_data()
    test_api_response_format()
    
    if success:
        print("\n✅ CBA.AX data is accessible via yfinance")
        print("If the API still fails, check:")
        print("  1. Network/firewall issues")
        print("  2. API response formatting")
        print("  3. Frontend parsing of response")
    else:
        print("\n❌ CBA.AX data fetch failed")
        print("Possible solutions:")
        print("  1. Check internet connection")
        print("  2. Try VPN if in restricted region")
        print("  3. Update yfinance: pip install --upgrade yfinance")
    
    sys.exit(0 if success else 1)