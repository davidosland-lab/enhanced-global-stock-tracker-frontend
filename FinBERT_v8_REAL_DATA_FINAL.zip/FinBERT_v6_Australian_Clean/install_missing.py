#!/usr/bin/env python3
"""
Install all missing packages for FinBERT
"""

import subprocess
import sys

def install_package(package):
    """Install a package using pip"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError:
        return False

def main():
    print("=" * 60)
    print("INSTALLING MISSING PACKAGES FOR FINBERT")
    print("=" * 60)
    
    # Critical packages that MUST be installed
    required_packages = [
        ("scikit-learn", "Machine Learning"),
        ("ta", "Technical Analysis"),
        ("flask", "Web Framework"),
        ("flask-cors", "CORS Support"),
        ("pandas", "Data Analysis"),
        ("numpy==1.26.4", "Numerical Computing"),
        ("yfinance", "Yahoo Finance Data"),
        ("feedparser", "RSS Feed Parser"),
        ("joblib", "Model Persistence"),
        ("python-dateutil", "Date Utilities"),
        ("requests", "HTTP Library")
    ]
    
    failed = []
    
    for package, description in required_packages:
        print(f"\nInstalling {package} ({description})...")
        if install_package(package):
            print(f"✅ {package} installed successfully")
        else:
            print(f"❌ {package} failed to install")
            failed.append(package)
    
    print("\n" + "=" * 60)
    
    if not failed:
        print("✅ ALL PACKAGES INSTALLED SUCCESSFULLY!")
        print("\nNow testing imports...")
        
        # Test critical imports
        try:
            import sklearn
            import ta
            import flask
            import yfinance
            import pandas
            import numpy
            import feedparser
            
            print("✅ All imports working!")
            print("\nYou can now run START.bat to launch FinBERT")
            return 0
            
        except ImportError as e:
            print(f"❌ Import error: {e}")
            print("\nTry running this script again or install manually:")
            print("pip install scikit-learn ta yfinance flask flask-cors pandas numpy feedparser joblib")
            return 1
    else:
        print("❌ SOME PACKAGES FAILED TO INSTALL:")
        for pkg in failed:
            print(f"  - {pkg}")
        print("\nTry installing manually with:")
        print(f"pip install {' '.join([p for p, _ in required_packages])}")
        return 1

if __name__ == "__main__":
    exit_code = main()
    print("\nPress Enter to close...")
    input()
    sys.exit(exit_code)