# FinBERT Ultimate v6 - Australian Enhanced Edition

## 🚀 Quick Start

1. **Install**: Run `INSTALL.bat` (first time only)
2. **Start**: Run `START.bat` 
3. **Test**: Run `TEST_AUSTRALIAN.bat` to verify Australian indicators
4. **Use**: Open the web interface and enter ASX stocks (e.g., CBA.AX)

## 📊 Features

### Core Trading Features
- **FinBERT Sentiment Analysis**: State-of-the-art financial sentiment from news
- **Random Forest ML**: Price predictions with confidence percentages
- **Technical Indicators**: RSI, MACD, Bollinger Bands, ATR, SMA
- **Economic Indicators**: VIX, Treasury Yields, Dollar Index, Gold prices
- **Real-time Data**: Live market data from Yahoo Finance
- **Advanced Charting**: Candlestick, OHLC, and line charts

### Australian Market Integration (NEW in v6)
- **Automatic Detection**: Recognizes .AX stocks automatically
- **Weighted Sentiment**: 60% news sentiment + 40% Australian market indicators
- **Comprehensive Indicators**:
  - RBA cash rate and monetary policy
  - CPI and inflation data
  - Unemployment and labour market stats
  - Housing prices and loan rates
  - Trade balance and commodity prices
  - Consumer and business confidence
  - China economic indicators (key trading partner)
  - AUD exchange rates

## 🔧 System Requirements

- Windows 10/11
- Python 3.10 or higher
- 4GB RAM minimum
- Internet connection
- ~2GB disk space (includes FinBERT model)

## 📁 File Structure

```
FinBERT_v6_Australian_Clean/
├── app_finbert_api_v5_fixed.py     # Main API server with Australian endpoint
├── app_finbert_ultimate.py         # Core FinBERT trading logic
├── australian_market_indicators.py # Australian economic data module
├── finbert_charts.html             # Standard trading interface
├── finbert_charts_australian.html  # Enhanced interface with AU panel
├── INSTALL.bat                     # One-click installer
├── START.bat                       # Start the system
├── TEST_AUSTRALIAN.bat             # Test Australian indicators
├── requirements.txt                # Python dependencies
└── README.md                       # This file
```

## 🌐 API Endpoints

- `http://localhost:5000/` - API information page
- `/api/stock/{symbol}` - Get stock data with indicators
- `/api/predict/{symbol}` - ML predictions with confidence
- `/api/economic` - Global economic indicators
- `/api/australian-indicators` - Australian market data
- `/api/news/{symbol}` - Latest news for symbol

## 🇦🇺 Using Australian Features

1. **ASX Stocks**: Enter any ASX symbol ending in .AX
   - Examples: CBA.AX, BHP.AX, CSL.AX, WBC.AX

2. **Automatic Display**: Australian indicators panel appears automatically for .AX stocks

3. **Weighted Analysis**: Sentiment calculation automatically adjusts for Australian stocks

4. **Key Indicators Tracked**:
   - RBA Cash Rate: Current 4.35%
   - Inflation (CPI): Target 2-3%
   - Unemployment Rate
   - Iron Ore & Gold Prices
   - China GDP & PMI
   - AUD/USD Exchange Rate

## 🧪 Testing

### Test Australian Indicators
```batch
TEST_AUSTRALIAN.bat
```

### Manual API Test
```
curl http://localhost:5000/api/australian-indicators
curl http://localhost:5000/api/stock/CBA.AX
```

### Python Test
```python
import requests
response = requests.get("http://localhost:5000/api/australian-indicators")
print(response.json())
```

## ⚠️ Troubleshooting

### Server Won't Start
- Check Python is installed: `python --version`
- Install dependencies: `pip install -r requirements.txt`
- Check port 5000 is free

### Australian Indicators Show 404
- Ensure you're running `app_finbert_api_v5_fixed.py`
- Check `australian_market_indicators.py` is in the same directory
- Restart the server

### FinBERT Not Working
- First run downloads ~400MB model
- If download fails, system uses fallback sentiment
- Check internet connection and retry

## 📈 Popular ASX Stocks

- **Banks**: CBA.AX, WBC.AX, ANZ.AX, NAB.AX
- **Mining**: BHP.AX, RIO.AX, FMG.AX
- **Healthcare**: CSL.AX, COH.AX, SHL.AX
- **Retail**: WES.AX, WOW.AX, JBH.AX
- **Telecom**: TLS.AX, TPG.AX
- **Energy**: WPL.AX, ORG.AX, STO.AX

## 📝 Version History

- **v6.0** (Oct 27, 2024): Added Australian market indicators
- **v5.0**: Fixed all technical indicators and confidence percentages
- **v4.0**: Enhanced charting and news integration
- **v3.0**: Added Random Forest ML predictions
- **v2.0**: Integrated FinBERT sentiment analysis
- **v1.0**: Initial release with basic indicators

## 💡 Tips

1. **Best Performance**: Close other applications while running
2. **Market Hours**: ASX trades 10:00 AM - 4:00 PM AEST
3. **News Impact**: Check news feed for context on price movements
4. **Confidence Levels**: Higher confidence % = more reliable prediction
5. **Australian Context**: RBA decisions significantly impact ASX

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Run `TEST_AUSTRALIAN.bat` for diagnostics
3. Review error messages in the server window
4. Ensure all files are in the same directory

---

**FinBERT Ultimate v6** - Australian Enhanced Edition
*Advanced AI-Powered Trading Analysis System*