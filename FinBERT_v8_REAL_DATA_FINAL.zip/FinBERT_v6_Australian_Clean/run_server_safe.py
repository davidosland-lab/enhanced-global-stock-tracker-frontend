#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Safe server runner with proper encoding
"""

import os
import sys
import io

# Set UTF-8 encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Disable cache
os.environ['YFINANCE_CACHE_DISABLE'] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

# Add user packages
import site
user_site = site.getusersitepackages()
if user_site not in sys.path:
    sys.path.insert(0, user_site)

user_path = r"C:\Users\david\AppData\Roaming\Python\Python312\site-packages"
if os.path.exists(user_path) and user_path not in sys.path:
    sys.path.insert(0, user_path)

print("=" * 60)
print("FINBERT API SERVER - SAFE MODE")
print("=" * 60)
print("UTF-8 encoding enabled")
print("Cache disabled")
print()

# Import the API file with proper encoding
api_file = None
if os.path.exists("app_finbert_api_v5_TRULY_FIXED.py"):
    api_file = "app_finbert_api_v5_TRULY_FIXED.py"
elif os.path.exists("app_finbert_api_v5_fixed.py"):
    api_file = "app_finbert_api_v5_fixed.py"

if api_file:
    print(f"Loading {api_file}...")
    try:
        # Read with UTF-8 encoding
        with open(api_file, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # Execute the code
        exec(code)
    except UnicodeDecodeError:
        print("Trying with latin-1 encoding...")
        with open(api_file, 'r', encoding='latin-1') as f:
            code = f.read()
        exec(code)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
else:
    print("ERROR: No API file found!")
    
input("\nPress Enter to exit...")