#!/usr/bin/env python3
"""
Comprehensive diagnostic tool to identify yfinance database corruption issue
"""

import os
import sys
import sqlite3
import traceback
from pathlib import Path

print("=" * 80)
print("YFINANCE DATABASE CORRUPTION DIAGNOSTIC TOOL")
print("=" * 80)

# 1. Check Python environment
print("\n1. PYTHON ENVIRONMENT:")
print(f"   Python version: {sys.version}")
print(f"   Python executable: {sys.executable}")
print(f"   Python path: {sys.path}")

# 2. Check installed packages
print("\n2. CHECKING INSTALLED PACKAGES:")
try:
    import yfinance as yf
    print(f"   ✓ yfinance version: {yf.__version__}")
    print(f"   ✓ yfinance location: {yf.__file__}")
except ImportError as e:
    print(f"   ✗ yfinance not found: {e}")

try:
    import peewee
    print(f"   ✓ peewee version: {peewee.__version__}")
    print(f"   ✓ peewee location: {peewee.__file__}")
except ImportError as e:
    print(f"   ✗ peewee not found: {e}")

try:
    import requests_cache
    print(f"   ✓ requests_cache installed")
except ImportError:
    print(f"   ✗ requests_cache not found")

# 3. Check environment variables
print("\n3. ENVIRONMENT VARIABLES:")
cache_related_vars = [
    'YFINANCE_CACHE_DISABLE',
    'YFINANCE_CACHE_DIR',
    'HOME',
    'APPDATA',
    'USERPROFILE',
    'XDG_CACHE_HOME'
]
for var in cache_related_vars:
    value = os.environ.get(var, "NOT SET")
    print(f"   {var}: {value}")

# 4. Locate yfinance cache directories
print("\n4. YFINANCE CACHE LOCATIONS:")
possible_cache_dirs = []

# Check home directory locations
home_dir = Path.home()
possible_cache_dirs.extend([
    home_dir / '.cache' / 'py-yfinance',
    home_dir / '.cache' / 'yfinance',
    home_dir / 'AppData' / 'Local' / 'py-yfinance',
    home_dir / 'AppData' / 'Roaming' / 'py-yfinance',
])

# Check XDG cache
if 'XDG_CACHE_HOME' in os.environ:
    xdg_cache = Path(os.environ['XDG_CACHE_HOME'])
    possible_cache_dirs.append(xdg_cache / 'py-yfinance')

# Check for any .db files in current directory
possible_cache_dirs.extend([
    Path.cwd(),
    Path.cwd() / 'cache',
    Path.cwd() / '.cache',
])

print("   Checking for cache directories and databases:")
found_databases = []
for cache_dir in possible_cache_dirs:
    if cache_dir.exists():
        print(f"   📁 {cache_dir} EXISTS")
        # Look for .db files
        for db_file in cache_dir.glob("*.db"):
            print(f"      └─ Found database: {db_file.name} ({db_file.stat().st_size} bytes)")
            found_databases.append(db_file)
        for db_file in cache_dir.glob("**/*.db"):
            if db_file not in found_databases:
                print(f"      └─ Found database: {db_file.relative_to(cache_dir)} ({db_file.stat().st_size} bytes)")
                found_databases.append(db_file)

# 5. Test each database for corruption
print("\n5. DATABASE INTEGRITY CHECK:")
for db_path in found_databases:
    print(f"\n   Testing: {db_path}")
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Check integrity
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()
        if result and result[0] == 'ok':
            print(f"      ✓ Database is OK")
        else:
            print(f"      ✗ Database is CORRUPTED: {result}")
        
        # Try to list tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        print(f"      Tables: {[t[0] for t in tables]}")
        
        conn.close()
    except Exception as e:
        print(f"      ✗ ERROR accessing database: {e}")

# 6. Test yfinance directly
print("\n6. TESTING YFINANCE DIRECTLY:")

# Test 1: Import and basic functionality
try:
    import yfinance as yf
    print("   ✓ yfinance imported successfully")
    
    # Check yfinance cache settings
    print("\n   Checking yfinance cache configuration:")
    
    # Try to find yfinance's cache manager
    try:
        # Try to access the cache through yfinance's internals
        if hasattr(yf, '_requests_cache'):
            print(f"      yfinance._requests_cache exists")
        
        # Look for cache in Ticker object
        test_ticker = yf.Ticker("AAPL")
        if hasattr(test_ticker, '_data'):
            print(f"      Ticker._data exists")
            if hasattr(test_ticker._data, 'cache'):
                print(f"      Ticker._data.cache exists")
    except Exception as e:
        print(f"      Note: {e}")
    
except ImportError as e:
    print(f"   ✗ Cannot import yfinance: {e}")

# Test 2: Try to fetch data with cache disabled
print("\n7. TESTING DATA FETCH WITH CACHE DISABLED:")
os.environ['YFINANCE_CACHE_DISABLE'] = '1'
os.environ['REQUESTS_CACHE_DISABLED'] = '1'

try:
    import yfinance as yf
    
    # Try a simple ticker fetch
    print("   Testing AAPL ticker fetch...")
    ticker = yf.Ticker("AAPL")
    
    # Try to get history with minimal period
    print("   Attempting to fetch 1 day of history...")
    history = ticker.history(period="1d")
    
    if not history.empty:
        print(f"   ✓ Successfully fetched data: {len(history)} rows")
        print(f"      Latest close: ${history['Close'].iloc[-1]:.2f}")
    else:
        print("   ✗ No data returned")
        
except Exception as e:
    print(f"   ✗ Error fetching data: {e}")
    print(f"   Full traceback:")
    traceback.print_exc()

# 8. Check for specific peewee database issues
print("\n8. PEEWEE DATABASE ANALYSIS:")
try:
    import peewee
    
    # Look for yfinance's database file specifically
    yf_db_paths = [
        Path.home() / '.cache' / 'py-yfinance' / 'prices.db',
        Path.home() / '.cache' / 'yfinance' / 'prices.db',
        Path.cwd() / 'yfinance.cache',
    ]
    
    for db_path in yf_db_paths:
        if db_path.exists():
            print(f"\n   Found yfinance database: {db_path}")
            try:
                # Try to open with peewee
                db = peewee.SqliteDatabase(str(db_path))
                db.connect()
                
                # Try to execute a simple query
                cursor = db.execute_sql("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                print(f"      Tables accessible via peewee: {tables}")
                
                db.close()
            except peewee.DatabaseError as e:
                print(f"      ✗ Peewee DatabaseError: {e}")
                print(f"      This is the error preventing yfinance from working!")
            except Exception as e:
                print(f"      ✗ Other error: {e}")
                
except ImportError:
    print("   peewee not installed")

# 9. Identify the exact cache file causing issues
print("\n9. IDENTIFYING PROBLEMATIC CACHE FILE:")

try:
    # Try to trace yfinance's actual cache location
    import yfinance as yf
    from yfinance import shared
    
    # Check if shared has cache info
    if hasattr(shared, '_CACHE_DIR'):
        print(f"   yfinance cache directory: {shared._CACHE_DIR}")
    
    # Try to create a ticker and see what cache it uses
    import logging
    logging.basicConfig(level=logging.DEBUG)
    
    print("\n   Creating ticker with debug logging...")
    ticker = yf.Ticker("TEST")
    
except Exception as e:
    print(f"   Error during cache identification: {e}")

# 10. Summary and recommendations
print("\n" + "=" * 80)
print("DIAGNOSTIC SUMMARY:")
print("=" * 80)

if found_databases:
    print("\n⚠️  FOUND DATABASE FILES:")
    for db in found_databases:
        print(f"   - {db}")
    print("\n   RECOMMENDATION: These database files may be corrupted.")
    print("   To fix, you can:")
    print("   1. Delete these .db files")
    print("   2. Set YFINANCE_CACHE_DISABLE=1 environment variable")
    print("   3. Use alternative data fetching methods")
else:
    print("\n✓ No local database files found")
    print("  The issue may be with yfinance's internal cache mechanism")

print("\n" + "=" * 80)