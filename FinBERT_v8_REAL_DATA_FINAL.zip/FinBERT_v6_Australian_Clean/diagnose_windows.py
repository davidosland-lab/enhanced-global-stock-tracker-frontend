#!/usr/bin/env python3
"""
Windows 11 specific diagnostic tool for yfinance database corruption issue
"""

import os
import sys
import sqlite3
import traceback
from pathlib import Path
import platform
import subprocess

print("=" * 80)
print("FINBERT WINDOWS 11 DATABASE DIAGNOSTIC")
print("=" * 80)

# 1. System Information
print("\n1. SYSTEM INFORMATION:")
print(f"   Platform: {platform.platform()}")
print(f"   System: {platform.system()}")
print(f"   Release: {platform.release()}")
print(f"   Machine: {platform.machine()}")
print(f"   Processor: {platform.processor()}")

# 2. Python Environment
print("\n2. PYTHON ENVIRONMENT:")
print(f"   Python version: {sys.version}")
print(f"   Python executable: {sys.executable}")
print(f"   Current working directory: {os.getcwd()}")

# 3. Check Python path and site-packages
print("\n3. PYTHON PATHS:")
print("   sys.path locations:")
for i, path in enumerate(sys.path[:10]):  # Show first 10 paths
    print(f"      [{i}] {path}")

# 4. Check installed packages and their locations
print("\n4. CHECKING PACKAGE INSTALLATIONS:")

packages_to_check = [
    'yfinance',
    'peewee',
    'pandas',
    'numpy',
    'transformers',
    'torch',
    'scikit-learn',
    'ta',
    'feedparser',
    'requests',
    'flask',
    'flask_cors',
    'requests_cache',
    'appdirs'
]

installed_packages = {}
for package in packages_to_check:
    try:
        module = __import__(package)
        version = getattr(module, '__version__', 'unknown')
        location = getattr(module, '__file__', 'unknown')
        installed_packages[package] = {'version': version, 'location': location}
        print(f"   ✓ {package:15} v{version:10} at {location}")
    except ImportError:
        print(f"   ✗ {package:15} NOT INSTALLED")
    except Exception as e:
        print(f"   ? {package:15} ERROR: {e}")

# 5. Check environment variables
print("\n5. ENVIRONMENT VARIABLES (Cache Related):")
important_vars = [
    'YFINANCE_CACHE_DISABLE',
    'YFINANCE_CACHE_DIR',
    'PYTHONPATH',
    'USERPROFILE',
    'APPDATA',
    'LOCALAPPDATA',
    'HOME',
    'HOMEPATH',
    'REQUESTS_CACHE_DISABLED',
    'XDG_CACHE_HOME'
]

for var in important_vars:
    value = os.environ.get(var, "NOT SET")
    if len(value) > 60:
        value = value[:57] + "..."
    print(f"   {var:25} = {value}")

# 6. Locate all possible cache directories on Windows
print("\n6. WINDOWS CACHE LOCATIONS:")
cache_locations = []

# Get user profile path
userprofile = os.environ.get('USERPROFILE', '')
if userprofile:
    cache_locations.extend([
        Path(userprofile) / '.cache' / 'py-yfinance',
        Path(userprofile) / '.cache' / 'yfinance',
        Path(userprofile) / 'AppData' / 'Local' / 'py-yfinance',
        Path(userprofile) / 'AppData' / 'Local' / 'yfinance',
        Path(userprofile) / 'AppData' / 'Roaming' / 'py-yfinance',
        Path(userprofile) / 'AppData' / 'Roaming' / 'yfinance',
        Path(userprofile) / '.yfinance',
    ])

# Add current directory locations
cache_locations.extend([
    Path.cwd() / '.cache',
    Path.cwd() / 'cache',
    Path.cwd() / '__pycache__',
])

# Check each location
found_caches = []
found_databases = []

print("   Scanning for cache directories and database files...")
for cache_path in cache_locations:
    if cache_path.exists():
        print(f"\n   📁 Found: {cache_path}")
        found_caches.append(cache_path)
        
        # Look for database files
        for pattern in ['*.db', '*.sqlite', '*.sqlite3', '*.cache']:
            for db_file in cache_path.glob(pattern):
                size = db_file.stat().st_size
                print(f"      └─ Database: {db_file.name} ({size:,} bytes)")
                found_databases.append(db_file)
            
            # Check subdirectories
            for db_file in cache_path.rglob(pattern):
                if db_file not in found_databases:
                    size = db_file.stat().st_size
                    rel_path = db_file.relative_to(cache_path)
                    print(f"      └─ Database: {rel_path} ({size:,} bytes)")
                    found_databases.append(db_file)

# 7. Check database integrity
print("\n7. DATABASE INTEGRITY CHECKS:")
if found_databases:
    for db_path in found_databases:
        print(f"\n   Testing: {db_path.name}")
        print(f"   Full path: {db_path}")
        
        try:
            # Try to connect and check integrity
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # Integrity check
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            
            if result and result[0] == 'ok':
                print(f"      ✓ Database integrity: OK")
                
                # Get table list
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                if tables:
                    print(f"      Tables: {[t[0] for t in tables]}")
                    
                    # Check row counts
                    for table in tables:
                        try:
                            cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
                            count = cursor.fetchone()[0]
                            print(f"        - {table[0]}: {count} rows")
                        except:
                            pass
            else:
                print(f"      ✗ DATABASE CORRUPTED: {result}")
                print(f"      >>> THIS IS THE PROBLEM! <<<")
            
            conn.close()
            
        except sqlite3.DatabaseError as e:
            print(f"      ✗ SQLITE ERROR: {e}")
            print(f"      >>> DATABASE IS CORRUPTED! <<<")
        except Exception as e:
            print(f"      ✗ ERROR: {e}")
else:
    print("   No database files found")

# 8. Test yfinance with different configurations
print("\n8. TESTING YFINANCE WITH DIFFERENT CONFIGURATIONS:")

configurations = [
    ("Default (no modifications)", {}),
    ("Cache disabled via environment", {'YFINANCE_CACHE_DISABLE': '1'}),
    ("Cache disabled + requests cache disabled", {
        'YFINANCE_CACHE_DISABLE': '1',
        'REQUESTS_CACHE_DISABLED': '1'
    }),
]

for config_name, env_vars in configurations:
    print(f"\n   Testing: {config_name}")
    
    # Set environment variables
    original_env = {}
    for key, value in env_vars.items():
        original_env[key] = os.environ.get(key)
        os.environ[key] = value
        print(f"      Set {key}={value}")
    
    try:
        # Import yfinance fresh
        if 'yfinance' in sys.modules:
            del sys.modules['yfinance']
        
        import yfinance as yf
        
        # Try to fetch data
        ticker = yf.Ticker("AAPL")
        history = ticker.history(period="1d")
        
        if not history.empty:
            close_price = history['Close'].iloc[-1]
            print(f"      ✓ SUCCESS: Fetched AAPL data - Close: ${close_price:.2f}")
        else:
            print(f"      ✗ FAILED: No data returned")
            
    except Exception as e:
        print(f"      ✗ ERROR: {e}")
        if "database disk image is malformed" in str(e):
            print(f"      >>> CORRUPTED DATABASE ERROR DETECTED <<<")
    
    # Restore original environment
    for key, value in original_env.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value

# 9. Check for conflicting Python installations
print("\n9. CHECKING FOR PYTHON INSTALLATION CONFLICTS:")

# Check for multiple Python installations
print("   Looking for Python installations...")

# Common Python locations on Windows
python_locations = [
    Path("C:/Python312"),
    Path("C:/Python311"),
    Path("C:/Python310"),
    Path("C:/Python39"),
    Path("C:/Python38"),
    Path("C:/Program Files/Python312"),
    Path("C:/Program Files/Python311"),
    Path("C:/Program Files/Python310"),
    Path("C:/Program Files/Python39"),
    Path("C:/Program Files/Python38"),
    Path("C:/Users") / os.environ.get('USERNAME', '') / "AppData/Local/Programs/Python",
    Path("C:/ProgramData/Anaconda3"),
    Path("C:/ProgramData/Miniconda3"),
]

found_pythons = []
for python_path in python_locations:
    if python_path.exists():
        print(f"   📁 Found: {python_path}")
        found_pythons.append(python_path)
        
        # Check for python.exe
        python_exe = python_path / "python.exe"
        if python_exe.exists():
            print(f"      └─ python.exe found")

# Check PATH for Python
print("\n   Python in PATH:")
try:
    result = subprocess.run(['where', 'python'], capture_output=True, text=True)
    if result.returncode == 0:
        for line in result.stdout.strip().split('\n'):
            print(f"      {line}")
except:
    print("      Could not check PATH")

# 10. Check for user-installed packages
print("\n10. USER-INSTALLED PACKAGES:")
user_site = None
try:
    import site
    user_site = site.getusersitepackages()
    print(f"   User site-packages: {user_site}")
    
    if user_site and Path(user_site).exists():
        print("   Packages in user directory:")
        for item in Path(user_site).iterdir():
            if item.is_dir() and not item.name.startswith('__'):
                print(f"      - {item.name}")
except:
    print("   Could not determine user site-packages")

# 11. Provide recommendations
print("\n" + "=" * 80)
print("DIAGNOSTIC SUMMARY AND RECOMMENDATIONS:")
print("=" * 80)

if found_databases:
    corrupted_dbs = []
    for db in found_databases:
        # Check if it's corrupted
        try:
            conn = sqlite3.connect(str(db))
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            conn.close()
            if result[0] != 'ok':
                corrupted_dbs.append(db)
        except:
            corrupted_dbs.append(db)
    
    if corrupted_dbs:
        print("\n⚠️  CORRUPTED DATABASES FOUND:")
        for db in corrupted_dbs:
            print(f"   - {db}")
        
        print("\n📋 TO FIX THE ISSUE:")
        print("   1. Close all Python/Flask applications")
        print("   2. Delete these corrupted database files:")
        for db in corrupted_dbs:
            print(f"      DEL \"{db}\"")
        print("   3. Clear the entire cache directory:")
        if userprofile:
            print(f"      RMDIR /S /Q \"{userprofile}\\.cache\"")
        print("   4. Set environment variables before running:")
        print("      SET YFINANCE_CACHE_DISABLE=1")
        print("      SET REQUESTS_CACHE_DISABLED=1")
        print("   5. Run the application")
    else:
        print("\n✓ Databases exist but appear intact")
        print("  Try setting cache disable environment variables")
else:
    print("\n✓ No cache databases found - this is good!")
    print("  The issue may be with package installation")

if 'yfinance' not in installed_packages:
    print("\n⚠️  YFINANCE NOT INSTALLED!")
    print("   Install with: pip install yfinance")

print("\n📝 QUICK FIX BATCH FILE:")
print("   Create a file called FIX_DATABASE.bat with:")
print("   ---")
print("   @echo off")
print("   SET YFINANCE_CACHE_DISABLE=1")
print("   SET REQUESTS_CACHE_DISABLED=1")
if userprofile:
    print(f"   RMDIR /S /Q \"{userprofile}\\.cache\" 2>nul")
print("   python app_finbert_api_v5_TRULY_FIXED.py")
print("   ---")

print("\n" + "=" * 80)
print("END OF DIAGNOSTIC")
print("=" * 80)