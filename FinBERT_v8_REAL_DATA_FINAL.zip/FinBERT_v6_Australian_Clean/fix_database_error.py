#!/usr/bin/env python3
"""
Fix database corruption issues in FinBERT system
"""

import os
import sys
import shutil
from pathlib import Path

def fix_database_corruption():
    """Clear all corrupted database files"""
    
    print("=" * 60)
    print("FIXING DATABASE CORRUPTION")
    print("=" * 60)
    
    fixed_count = 0
    
    # 1. Clear yfinance cache
    print("\n1. Clearing yfinance cache...")
    yfinance_cache_dirs = [
        Path.home() / ".cache" / "py-yfinance",
        Path.home() / ".cache" / "yfinance",
        Path("~/.cache/py-yfinance").expanduser(),
        Path("~/.cache/yfinance").expanduser()
    ]
    
    for cache_dir in yfinance_cache_dirs:
        if cache_dir.exists():
            try:
                shutil.rmtree(cache_dir)
                print(f"   ✅ Cleared: {cache_dir}")
                fixed_count += 1
            except Exception as e:
                print(f"   ⚠️ Could not clear {cache_dir}: {e}")
    
    # 2. Clear local database files
    print("\n2. Clearing local database files...")
    db_patterns = ["*.db", "*.sqlite", "*.db-journal", "*.db-wal", "*.db-shm"]
    
    for pattern in db_patterns:
        for db_file in Path(".").glob(pattern):
            try:
                # Backup before deleting
                backup_dir = Path("db_backup")
                backup_dir.mkdir(exist_ok=True)
                backup_file = backup_dir / db_file.name
                
                shutil.move(str(db_file), str(backup_file))
                print(f"   ✅ Moved {db_file} to backup")
                fixed_count += 1
            except Exception as e:
                print(f"   ⚠️ Could not move {db_file}: {e}")
    
    # 3. Clear cache directory
    print("\n3. Clearing cache directory...")
    if Path("cache").exists():
        for cache_file in Path("cache").glob("*.db"):
            try:
                cache_file.unlink()
                print(f"   ✅ Deleted: {cache_file}")
                fixed_count += 1
            except Exception as e:
                print(f"   ⚠️ Could not delete {cache_file}: {e}")
    
    # 4. Clear Python cache
    print("\n4. Clearing Python cache...")
    cache_dirs = ["__pycache__", ".pytest_cache", ".mypy_cache"]
    
    for cache_dir in cache_dirs:
        if Path(cache_dir).exists():
            try:
                shutil.rmtree(cache_dir)
                print(f"   ✅ Cleared: {cache_dir}")
                fixed_count += 1
            except Exception as e:
                print(f"   ⚠️ Could not clear {cache_dir}: {e}")
    
    # 5. Set environment variable to disable SQLite caching
    print("\n5. Setting environment variables...")
    os.environ['YFINANCE_CACHE_DISABLE'] = '1'
    print("   ✅ Disabled yfinance caching for this session")
    
    print("\n" + "=" * 60)
    print(f"FIX COMPLETE - {fixed_count} items cleaned")
    print("=" * 60)
    
    if fixed_count > 0:
        print("\n✅ Database corruption issues have been fixed!")
        print("\nThe system will create fresh databases on next run.")
        print("\nNext steps:")
        print("  1. Restart the API server (START.bat)")
        print("  2. Test with a simple stock like AAPL")
        return True
    else:
        print("\n⚠️ No corrupted databases found.")
        print("The issue might be something else.")
        return False

def test_yfinance_direct():
    """Test if yfinance works directly"""
    print("\n" + "=" * 60)
    print("TESTING YFINANCE DIRECTLY")
    print("=" * 60)
    
    try:
        import yfinance as yf
        
        # Disable cache for this test
        yf.set_tz_cache_location(None)
        
        print("\nTesting AAPL...")
        ticker = yf.Ticker("AAPL")
        
        # Try to get info without caching
        info = ticker.info
        if info:
            print(f"✅ AAPL current price: ${info.get('currentPrice', 'N/A')}")
        
        # Try history
        history = ticker.history(period="1d")
        if not history.empty:
            print(f"✅ AAPL closing price: ${history['Close'].iloc[-1]:.2f}")
        
        print("\nTesting CBA.AX...")
        ticker_au = yf.Ticker("CBA.AX")
        history_au = ticker_au.history(period="1d")
        if not history_au.empty:
            print(f"✅ CBA.AX closing price: ${history_au['Close'].iloc[-1]:.2f}")
        
        print("\n✅ YFinance is working correctly!")
        return True
        
    except Exception as e:
        print(f"\n❌ YFinance test failed: {e}")
        print("\nTry updating yfinance:")
        print("  pip install --upgrade yfinance")
        return False

if __name__ == "__main__":
    print("FinBERT Database Fix Utility\n")
    
    # First fix corruption
    corruption_fixed = fix_database_corruption()
    
    # Then test if it works
    yfinance_works = test_yfinance_direct()
    
    if corruption_fixed and yfinance_works:
        print("\n" + "🎉" * 20)
        print("EVERYTHING IS FIXED!")
        print("🎉" * 20)
        print("\nYou can now restart the server and it should work.")
        sys.exit(0)
    else:
        print("\n⚠️ Some issues remain. Check the messages above.")
        sys.exit(1)