#!/usr/bin/env python3
"""
FinBERT Ultimate v6 System Test
Tests all components including Australian indicators
"""

import sys
import time
import json

def test_imports():
    """Test if all required packages can be imported"""
    print("Testing package imports...")
    
    packages = {
        'flask': 'Flask web framework',
        'yfinance': 'Yahoo Finance data',
        'pandas': 'Data analysis',
        'numpy': 'Numerical computing',
        'sklearn': 'Machine learning',
        'ta': 'Technical analysis',
        'feedparser': 'RSS news feeds',
    }
    
    failed = []
    for package, description in packages.items():
        try:
            __import__(package)
            print(f"  ✅ {package} ({description})")
        except ImportError:
            print(f"  ❌ {package} ({description}) - NOT INSTALLED")
            failed.append(package)
    
    # Test transformers separately as it's optional
    try:
        import transformers
        print(f"  ✅ transformers (FinBERT sentiment) - AVAILABLE")
    except ImportError:
        print(f"  ⚠️  transformers (FinBERT sentiment) - Using fallback")
    
    return len(failed) == 0

def test_api_modules():
    """Test if API modules can be imported"""
    print("\nTesting API modules...")
    
    try:
        # Test main app
        from app_finbert_ultimate import TradingModel, DataFetcher, FINBERT_AVAILABLE
        print(f"  ✅ app_finbert_ultimate loaded")
        print(f"     FinBERT status: {'ENABLED' if FINBERT_AVAILABLE else 'FALLBACK MODE'}")
        
        # Test Australian indicators
        try:
            from australian_market_indicators import AustralianMarketIndicators
            print(f"  ✅ australian_market_indicators loaded")
            aus = AustralianMarketIndicators()
            indicators = aus.get_all_indicators()
            print(f"     Found {len(indicators)} indicator categories")
        except ImportError:
            print(f"  ⚠️  australian_market_indicators - Not found (will use defaults)")
        except Exception as e:
            print(f"  ⚠️  australian_market_indicators - Error: {e}")
        
        return True
    except Exception as e:
        print(f"  ❌ Error loading modules: {e}")
        return False

def test_sample_data():
    """Test fetching sample data"""
    print("\nTesting data fetching...")
    
    try:
        import yfinance as yf
        
        # Test US stock
        ticker = yf.Ticker("AAPL")
        info = ticker.info
        if info.get('currentPrice'):
            print(f"  ✅ US stock data (AAPL): ${info['currentPrice']}")
        else:
            print(f"  ⚠️  US stock data: Limited info available")
        
        # Test Australian stock
        ticker_au = yf.Ticker("CBA.AX")
        info_au = ticker_au.info
        if info_au.get('currentPrice'):
            print(f"  ✅ ASX stock data (CBA.AX): ${info_au['currentPrice']}")
        else:
            print(f"  ⚠️  ASX stock data: Limited info available")
        
        return True
    except Exception as e:
        print(f"  ❌ Error fetching data: {e}")
        return False

def main():
    print("=" * 60)
    print("FinBERT Ultimate v6 - System Test")
    print("Australian Enhanced Edition")
    print("=" * 60)
    
    # Run tests
    imports_ok = test_imports()
    modules_ok = test_api_modules()
    data_ok = test_sample_data()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    if imports_ok and modules_ok and data_ok:
        print("✅ ALL TESTS PASSED - System is ready!")
        print("\nNext steps:")
        print("  1. Run START.bat to launch the server")
        print("  2. Open the web interface")
        print("  3. Try an ASX stock like CBA.AX")
        return 0
    else:
        print("⚠️ Some tests failed")
        print("\nRecommendations:")
        if not imports_ok:
            print("  • Run INSTALL.bat to install missing packages")
        if not modules_ok:
            print("  • Check that all .py files are present")
        if not data_ok:
            print("  • Check internet connection")
        return 1

if __name__ == "__main__":
    try:
        exit_code = main()
        print("\nPress Enter to close...")
        input()
        sys.exit(exit_code)
    except Exception as e:
        print(f"\nERROR: {e}")
        print("\nPress Enter to close...")
        input()
        sys.exit(1)