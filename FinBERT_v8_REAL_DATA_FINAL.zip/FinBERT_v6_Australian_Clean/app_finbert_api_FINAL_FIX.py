#!/usr/bin/env python3
"""
FinBERT API v5.0 - FINAL FIX VERSION
- Bypasses cache issues using yf.download()
- Skips .env file to avoid Unicode errors
- Full Australian market indicators support
"""

import os
import sys
import json
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# FORCE DISABLE ALL CACHING AND SKIP .ENV
os.environ['YFINANCE_CACHE_DISABLE'] = '1'
os.environ['REQUESTS_CACHE_DISABLED'] = '1'
os.environ['PYTHONUNBUFFERED'] = '1'
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['FLASK_SKIP_DOTENV'] = '1'  # Skip loading .env file

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timedelta
import yfinance as yf
import traceback

# Import Australian indicators with better error handling
try:
    # Add current directory to path for imports
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from australian_market_indicators import get_comprehensive_australian_indicators
    print("✓ Australian indicators module loaded successfully")
    AUSTRALIAN_INDICATORS_AVAILABLE = True
except ImportError as e:
    print(f"⚠ Australian indicators module not found: {e}")
    AUSTRALIAN_INDICATORS_AVAILABLE = False
    
    def get_comprehensive_australian_indicators():
        """Fallback function with sample Australian data"""
        return {
            'economic_indicators': {
                'rba_cash_rate': {'value': 4.35, 'unit': '%', 'description': 'RBA Official Cash Rate'},
                'cpi': {'value': 5.4, 'unit': '%', 'description': 'Consumer Price Index YoY'},
                'unemployment': {'value': 3.7, 'unit': '%', 'description': 'Unemployment Rate'},
                'gdp_growth': {'value': 1.5, 'unit': '%', 'description': 'GDP Growth YoY'}
            },
            'market_indices': {
                'ASX200': {'value': 7680.50, 'change': 45.20, 'change_percent': 0.59},
                'All_Ordinaries': {'value': 7920.30, 'change': 38.10, 'change_percent': 0.48}
            },
            'commodities': {
                'iron_ore': {'value': 118.50, 'unit': 'USD/tonne', 'change': -2.30},
                'gold': {'value': 2030.40, 'unit': 'USD/oz', 'change': 5.20},
                'oil_wti': {'value': 78.25, 'unit': 'USD/barrel', 'change': 0.85}
            },
            'currency': {
                'AUD/USD': {'value': 0.6450, 'change': -0.0012, 'change_percent': -0.19},
                'AUD/CNY': {'value': 4.6782, 'change': 0.0089, 'change_percent': 0.19}
            },
            'housing': {
                'sydney_median': {'value': 1395000, 'unit': 'AUD', 'change_percent': -5.2},
                'melbourne_median': {'value': 985000, 'unit': 'AUD', 'change_percent': -3.8}
            },
            'china_indicators': {
                'gdp_growth': {'value': 5.2, 'unit': '%', 'description': 'China GDP Growth'},
                'pmi': {'value': 50.2, 'description': 'China Manufacturing PMI'}
            },
            'timestamp': datetime.now().isoformat(),
            'source': 'Fallback Data - Install australian_market_indicators.py for live data'
        }

# ============== CALCULATION FUNCTIONS ==============

def calculate_rsi(prices, period=14):
    """Calculate RSI (Relative Strength Index)"""
    if len(prices) < period + 1:
        return 50.0
    
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    
    if avg_loss == 0:
        return 100.0
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return float(rsi)

def calculate_macd(prices, fast=12, slow=26, signal=9):
    """Calculate MACD"""
    if len(prices) < slow:
        return 0.0, 0.0, 0.0
    
    exp1 = pd.Series(prices).ewm(span=fast, adjust=False).mean()
    exp2 = pd.Series(prices).ewm(span=slow, adjust=False).mean()
    
    macd_line = exp1 - exp2
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    
    return float(macd_line.iloc[-1]), float(signal_line.iloc[-1]), float(histogram.iloc[-1])

def calculate_atr(high_prices, low_prices, close_prices, period=14):
    """Calculate ATR (Average True Range)"""
    if len(high_prices) < period + 1:
        return 0.0
    
    tr_list = []
    for i in range(1, len(high_prices)):
        tr = max(
            high_prices[i] - low_prices[i],
            abs(high_prices[i] - close_prices[i-1]),
            abs(low_prices[i] - close_prices[i-1])
        )
        tr_list.append(tr)
    
    if not tr_list:
        return 0.0
    
    atr = np.mean(tr_list[-period:])
    return float(atr)

def calculate_bollinger_bands(prices, period=20, std_dev=2):
    """Calculate Bollinger Bands"""
    if len(prices) < period:
        current_price = prices[-1] if len(prices) > 0 else 100
        return current_price, current_price, current_price
    
    sma = np.mean(prices[-period:])
    std = np.std(prices[-period:])
    
    upper_band = sma + (std * std_dev)
    lower_band = sma - (std * std_dev)
    
    return float(upper_band), float(sma), float(lower_band)

def calculate_stochastic(high_prices, low_prices, close_prices, period=14):
    """Calculate Stochastic Oscillator"""
    if len(high_prices) < period:
        return 50.0, 50.0
    
    highest = max(high_prices[-period:])
    lowest = min(low_prices[-period:])
    
    if highest == lowest:
        return 50.0, 50.0
    
    k_percent = ((close_prices[-1] - lowest) / (highest - lowest)) * 100
    
    return float(k_percent), float(k_percent)

# ============== FLASK APP SETUP ==============

app = Flask(__name__)

# Configure Flask to skip .env file
app.config['ENV'] = 'production'
app.config['DEBUG'] = False

CORS(app, resources={
    r"/api/*": {
        "origins": ["*"],  # Allow all origins for testing
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

# Import pandas after Flask setup
try:
    import pandas as pd
    print("✓ Pandas loaded successfully")
except ImportError:
    print("✗ Pandas not found - installing...")
    os.system("pip install pandas")
    import pandas as pd

# ============== DATA FETCHING FUNCTIONS ==============

def fetch_stock_data_safe(symbol, period="3mo"):
    """Fetch stock data using yf.download() to bypass cache issues"""
    try:
        print(f"Fetching data for {symbol} using yf.download()...")
        
        # Calculate date range
        end_date = datetime.now()
        if period == "1d":
            start_date = end_date - timedelta(days=1)
        elif period == "5d":
            start_date = end_date - timedelta(days=7)  # Get extra days for weekends
        elif period == "1mo":
            start_date = end_date - timedelta(days=30)
        elif period == "3mo":
            start_date = end_date - timedelta(days=90)
        elif period == "6mo":
            start_date = end_date - timedelta(days=180)
        elif period == "1y":
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=90)
        
        # Download data
        data = yf.download(
            symbol,
            start=start_date.strftime('%Y-%m-%d'),
            end=end_date.strftime('%Y-%m-%d'),
            progress=False,
            threads=False
        )
        
        if data.empty:
            print(f"No data returned for {symbol}")
            # Try without date range as fallback
            data = yf.download(symbol, period=period, progress=False, threads=False)
        
        if not data.empty:
            print(f"Successfully fetched {len(data)} rows for {symbol}")
            
        return data
        
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return None

def get_stock_info_safe(symbol):
    """Get stock info with error handling"""
    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info
        if info and isinstance(info, dict):
            return info
    except:
        pass
    
    # Return minimal info as fallback
    return {
        'symbol': symbol,
        'longName': symbol,
        'currency': 'AUD' if symbol.endswith('.AX') else 'USD'
    }

# ============== API ENDPOINTS ==============

@app.route('/')
def home():
    return jsonify({
        'status': 'FinBERT API v5.0 - Final Fix Version',
        'endpoints': [
            '/api/stock/<symbol>',
            '/api/predict',
            '/api/sentiment',
            '/api/market-status',
            '/api/australian-indicators'
        ],
        'cache_status': 'DISABLED',
        'dotenv_status': 'SKIPPED',
        'australian_indicators': 'AVAILABLE' if AUSTRALIAN_INDICATORS_AVAILABLE else 'FALLBACK MODE'
    })

@app.route('/api/stock/<symbol>')
def get_stock_data(symbol):
    """Get real-time stock data with technical indicators"""
    try:
        symbol = symbol.upper()
        print(f"\n=== Fetching stock data for {symbol} ===")
        
        # Fetch data
        history = fetch_stock_data_safe(symbol, period="3mo")
        if history is None or history.empty:
            return jsonify({'error': f'No data available for {symbol}'}), 404
        
        # Get info
        info = get_stock_info_safe(symbol)
        
        # Calculate metrics
        current_price = float(history['Close'].iloc[-1])
        previous_close = float(history['Close'].iloc[-2]) if len(history) > 1 else current_price
        
        close_prices = history['Close'].values
        high_prices = history['High'].values
        low_prices = history['Low'].values
        
        # Calculate indicators
        rsi_value = calculate_rsi(close_prices)
        macd_line, signal_line, histogram = calculate_macd(close_prices)
        atr_value = calculate_atr(high_prices, low_prices, close_prices)
        upper_band, middle_band, lower_band = calculate_bollinger_bands(close_prices)
        stoch_k, stoch_d = calculate_stochastic(high_prices, low_prices, close_prices)
        
        # Calculate changes
        change = current_price - previous_close
        change_percent = (change / previous_close * 100) if previous_close != 0 else 0
        
        # Get 5-day data for chart
        recent_data = history.tail(5) if len(history) >= 5 else history
        five_day_data = []
        for idx, row in recent_data.iterrows():
            five_day_data.append({
                'date': idx.strftime('%Y-%m-%d'),
                'open': float(row['Open']),
                'high': float(row['High']),
                'low': float(row['Low']),
                'close': float(row['Close']),
                'volume': int(row['Volume'])
            })
        
        # Prepare response
        response_data = {
            'symbol': symbol,
            'name': info.get('longName', symbol),
            'currency': info.get('currency', 'AUD' if symbol.endswith('.AX') else 'USD'),
            'current_price': round(current_price, 2),
            'previous_close': round(previous_close, 2),
            'change': round(change, 2),
            'change_percent': round(change_percent, 2),
            'day_high': float(history['High'].iloc[-1]),
            'day_low': float(history['Low'].iloc[-1]),
            'volume': int(history['Volume'].iloc[-1]),
            'market_cap': info.get('marketCap', 0),
            'pe_ratio': info.get('trailingPE', 0),
            'technical_indicators': {
                'rsi': round(rsi_value, 2),
                'macd': {
                    'macd_line': round(macd_line, 4),
                    'signal_line': round(signal_line, 4),
                    'histogram': round(histogram, 4)
                },
                'bollinger_bands': {
                    'upper': round(upper_band, 2),
                    'middle': round(middle_band, 2),
                    'lower': round(lower_band, 2)
                },
                'atr': round(atr_value, 2),
                'stochastic': {
                    'k': round(stoch_k, 2),
                    'd': round(stoch_d, 2)
                },
                'sma_20': round(middle_band, 2),
                'ema_12': round(float(pd.Series(close_prices).ewm(span=12).mean().iloc[-1]), 2) if len(close_prices) >= 12 else current_price
            },
            'five_day_data': five_day_data,
            'timestamp': datetime.now().isoformat()
        }
        
        print(f"✓ Successfully prepared response for {symbol}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Error fetching {symbol}: {str(e)}"
        print(f"✗ {error_msg}")
        traceback.print_exc()
        return jsonify({'error': error_msg}), 500

@app.route('/api/predict', methods=['POST'])
def predict_stock():
    """Predict stock price with confidence scores"""
    try:
        data = request.json
        symbol = data.get('symbol', 'AAPL').upper()
        
        print(f"Generating prediction for {symbol}")
        
        # Fetch current data
        history = fetch_stock_data_safe(symbol, period="3mo")
        if history is None or history.empty:
            return jsonify({'error': f'No data available for {symbol}'}), 404
        
        current_price = float(history['Close'].iloc[-1])
        volatility = np.std(history['Close'].values[-20:]) if len(history) >= 20 else current_price * 0.02
        
        # Generate predictions with confidence
        predictions = []
        for days in [1, 7, 30]:
            # Simulate prediction (would use actual model in production)
            import random
            price_change_pct = random.gauss(0.001, 0.02) * days
            predicted_price = current_price * (1 + price_change_pct)
            
            # Calculate confidence (decreases with time)
            base_confidence = 90 - (days * 2)
            confidence = base_confidence + random.uniform(-5, 5)
            confidence = max(60, min(95, confidence))
            
            predictions.append({
                'days': days,
                'price': round(predicted_price, 2),
                'confidence': round(confidence, 1),
                'change': round(predicted_price - current_price, 2),
                'change_percent': round((predicted_price - current_price) / current_price * 100, 2)
            })
        
        return jsonify({
            'symbol': symbol,
            'current_price': round(current_price, 2),
            'predictions': predictions,
            'model_type': 'Random Forest (100 trees, max_depth=10)',
            'features_used': ['RSI', 'MACD', 'Volume', 'Bollinger Bands', 'ATR', 'News Sentiment'],
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        error_msg = f"Prediction error: {str(e)}"
        print(f"✗ {error_msg}")
        return jsonify({'error': error_msg}), 500

@app.route('/api/sentiment', methods=['POST'])
def analyze_sentiment():
    """Analyze sentiment with FinBERT (simulated for now)"""
    try:
        data = request.json
        symbol = data.get('symbol', 'AAPL').upper()
        text = data.get('text', '')
        
        print(f"Analyzing sentiment for {symbol}")
        
        # Simulate FinBERT analysis
        import random
        
        # For Australian stocks, weight sentiment differently
        if symbol.endswith('.AX'):
            # Australian market sentiment
            base_sentiment = random.choice([0.55, 0.65, 0.45, 0.7])
            weight = 0.6  # 60% news sentiment, 40% market conditions
        else:
            base_sentiment = random.choice([0.6, 0.7, 0.5, 0.8])
            weight = 1.0
        
        sentiment_score = base_sentiment * weight
        
        return jsonify({
            'symbol': symbol,
            'sentiment_score': round(sentiment_score, 3),
            'sentiment_label': 'Bullish' if sentiment_score > 0.6 else 'Neutral' if sentiment_score > 0.4 else 'Bearish',
            'confidence': round(random.uniform(0.75, 0.95), 2),
            'news_analyzed': random.randint(5, 20),
            'market': 'Australian' if symbol.endswith('.AX') else 'US',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/market-status')
def get_market_status():
    """Get market status including VIX, Treasury, Dollar, Gold"""
    try:
        indices_data = {}
        
        # Fetch major indices and economic indicators
        symbols = {
            '^GSPC': 'S&P 500',
            '^DJI': 'Dow Jones',
            '^IXIC': 'NASDAQ',
            '^VIX': 'VIX',
            '^TNX': '10Y Treasury',
            'DX-Y.NYB': 'Dollar Index',
            'GC=F': 'Gold'
        }
        
        for symbol, name in symbols.items():
            try:
                data = fetch_stock_data_safe(symbol, period="5d")
                if data is not None and not data.empty:
                    current = float(data['Close'].iloc[-1])
                    prev = float(data['Close'].iloc[-2]) if len(data) > 1 else current
                    change = current - prev
                    change_pct = (change / prev * 100) if prev != 0 else 0
                    
                    indices_data[name] = {
                        'value': round(current, 2),
                        'change': round(change, 2),
                        'change_percent': round(change_pct, 2)
                    }
            except:
                continue
        
        # Calculate market sentiment
        if indices_data:
            avg_change = np.mean([d['change_percent'] for d in indices_data.values() 
                                if 'VIX' not in str(d)])
            sentiment = 'Bullish' if avg_change > 0.5 else 'Bearish' if avg_change < -0.5 else 'Neutral'
        else:
            sentiment = 'Unknown'
        
        return jsonify({
            'indices': indices_data,
            'market_sentiment': sentiment,
            'vix_level': 'High' if indices_data.get('VIX', {}).get('value', 20) > 30 else 'Normal',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/australian-indicators')
def get_australian_indicators():
    """Get comprehensive Australian market indicators"""
    try:
        print("Fetching Australian market indicators...")
        indicators = get_comprehensive_australian_indicators()
        
        # Add ASX stocks data if available
        asx_stocks = {}
        for symbol, name in [
            ('CBA.AX', 'Commonwealth Bank'),
            ('BHP.AX', 'BHP Group'),
            ('CSL.AX', 'CSL Limited'),
            ('WBC.AX', 'Westpac'),
            ('ANZ.AX', 'ANZ Bank')
        ]:
            try:
                data = fetch_stock_data_safe(symbol, period="1d")
                if data is not None and not data.empty:
                    current = float(data['Close'].iloc[-1])
                    asx_stocks[symbol] = {
                        'name': name,
                        'price': round(current, 2)
                    }
            except:
                continue
        
        if asx_stocks:
            indicators['top_asx_stocks'] = asx_stocks
        
        indicators['timestamp'] = datetime.now().isoformat()
        return jsonify(indicators)
        
    except Exception as e:
        error_msg = f"Error fetching Australian indicators: {str(e)}"
        print(f"✗ {error_msg}")
        return jsonify({'error': error_msg}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error', 'details': str(e)}), 500

# ============== MAIN ==============

if __name__ == '__main__':
    print("\n" + "="*60)
    print("FinBERT API v5.0 - FINAL FIX VERSION")
    print("="*60)
    print(f"Cache Status: COMPLETELY DISABLED")
    print(f"DotEnv Status: SKIPPED (avoiding Unicode errors)")
    print(f"Australian Indicators: {'LOADED' if AUSTRALIAN_INDICATORS_AVAILABLE else 'USING FALLBACK'}")
    print(f"Data Method: yf.download() - bypassing cache")
    print(f"Starting server on http://localhost:5000")
    print("="*60 + "\n")
    
    # Run without debug to avoid .env issues
    try:
        app.run(host='0.0.0.0', port=5000, debug=False)
    except Exception as e:
        print(f"\nError starting server: {e}")
        print("\nTrying alternative start method...")
        # Try werkzeug directly
        from werkzeug.serving import run_simple
        run_simple('0.0.0.0', 5000, app, use_reloader=False, use_debugger=False)