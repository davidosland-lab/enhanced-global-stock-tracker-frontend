#!/usr/bin/env python3
"""
Test if packages can be imported
"""

import sys
import os
import site

print("=" * 60)
print("TESTING PACKAGE IMPORTS")
print("=" * 60)

# Show Python version
print(f"\nPython version: {sys.version}")
print(f"Python executable: {sys.executable}")

# Show user site-packages
user_site = site.getusersitepackages()
print(f"\nUser site-packages: {user_site}")
print(f"Exists: {os.path.exists(user_site)}")

# Add user site to path if not there
if user_site not in sys.path:
    sys.path.insert(0, user_site)
    print("Added user site-packages to path")

# Also add the specific path where packages are installed
user_path = r"C:\Users\david\AppData\Roaming\Python\Python312\site-packages"
if os.path.exists(user_path) and user_path not in sys.path:
    sys.path.insert(0, user_path)
    print(f"Added specific user path: {user_path}")

print("\nPython path (first 5):")
for i, p in enumerate(sys.path[:5]):
    print(f"  {i}: {p}")

print("\n" + "-" * 40)
print("Testing imports...")
print("-" * 40)

packages = [
    ('sklearn', 'scikit-learn'),
    ('ta', 'ta'),
    ('flask', 'Flask'),
    ('yfinance', 'yfinance'),
    ('pandas', 'pandas'),
    ('numpy', 'numpy'),
    ('feedparser', 'feedparser'),
    ('joblib', 'joblib'),
]

all_good = True
for module_name, display_name in packages:
    try:
        module = __import__(module_name)
        version = getattr(module, '__version__', 'unknown')
        print(f"✅ {display_name:15} - version {version}")
    except ImportError as e:
        print(f"❌ {display_name:15} - IMPORT FAILED: {e}")
        all_good = False

print("\n" + "=" * 60)
if all_good:
    print("✅ ALL PACKAGES IMPORTED SUCCESSFULLY!")
    print("\nYou can now run the API server.")
else:
    print("❌ SOME PACKAGES FAILED TO IMPORT")
    print("\nTrying to fix...")
    print("\nOption 1: Run Python with user flag:")
    print("  python -m site --user-site")
    print("  python -m pip install --user scikit-learn ta")
    print("\nOption 2: Set PYTHONPATH:")
    print(f"  set PYTHONPATH={user_site}")
    print("  python app_finbert_api_v5_TRULY_FIXED.py")

print("\nPress Enter to exit...")
input()