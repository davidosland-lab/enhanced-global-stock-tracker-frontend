#!/usr/bin/env python3
"""
Run FinBERT with cache completely disabled
"""

import os
import sys

# Disable all caching
os.environ['YFINANCE_CACHE_DISABLE'] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['SQLITE_TMPDIR'] = os.environ.get('TEMP', '/tmp')

# Add user packages to path
import site
user_site = site.getusersitepackages()
if user_site not in sys.path:
    sys.path.insert(0, user_site)

# Also add the specific Windows user path
user_path = r"C:\Users\david\AppData\Roaming\Python\Python312\site-packages"
if os.path.exists(user_path) and user_path not in sys.path:
    sys.path.insert(0, user_path)

print("=" * 60)
print("STARTING FINBERT WITH NO CACHE")
print("=" * 60)
print("Cache disabled for this session")
print()

# Import yfinance and disable its cache
try:
    import yfinance as yf
    # Disable yfinance cache
    yf.set_tz_cache_location(None)
    print("✅ YFinance cache disabled")
except Exception as e:
    print(f"Warning: Could not disable yfinance cache: {e}")

# Test if yfinance works
print("\nTesting yfinance...")
try:
    ticker = yf.Ticker("AAPL", session=None)
    hist = ticker.history(period="1d", prepost=False, repair=False)
    if not hist.empty:
        print(f"✅ YFinance working: AAPL = ${hist['Close'].iloc[-1]:.2f}")
    else:
        print("⚠️ YFinance returned no data")
except Exception as e:
    print(f"❌ YFinance error: {e}")

print("\nStarting API server...")
print("-" * 60)

# Run the API
try:
    if os.path.exists("app_finbert_api_v5_TRULY_FIXED.py"):
        exec(open("app_finbert_api_v5_TRULY_FIXED.py").read())
    elif os.path.exists("app_finbert_api_v5_fixed.py"):
        exec(open("app_finbert_api_v5_fixed.py").read())
    else:
        print("ERROR: No API file found!")
        sys.exit(1)
except Exception as e:
    print(f"Error starting API: {e}")
    import traceback
    traceback.print_exc()
    input("\nPress Enter to exit...")
    sys.exit(1)