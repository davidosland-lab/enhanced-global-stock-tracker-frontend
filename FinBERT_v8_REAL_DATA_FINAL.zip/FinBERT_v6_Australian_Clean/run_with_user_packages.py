#!/usr/bin/env python3
"""
Run FinBERT API with user-installed packages
"""

import sys
import os
import site

# Add user site-packages to path
user_site = site.getusersitepackages()
if user_site not in sys.path:
    sys.path.insert(0, user_site)

# Also add common user locations
user_paths = [
    os.path.expanduser("~/AppData/Roaming/Python/Python312/site-packages"),
    os.path.expanduser("~/.local/lib/python3.12/site-packages"),
    r"C:\Users\david\AppData\Roaming\Python\Python312\site-packages",
]

for path in user_paths:
    if os.path.exists(path) and path not in sys.path:
        sys.path.insert(0, path)
        print(f"Added to path: {path}")

print("Python paths:")
for p in sys.path[:5]:
    print(f"  {p}")

# Now test imports
print("\nTesting package imports...")

try:
    import sklearn
    print(f"✅ scikit-learn {sklearn.__version__} imported successfully")
except ImportError as e:
    print(f"❌ scikit-learn import failed: {e}")
    sys.exit(1)

try:
    import ta
    print("✅ ta imported successfully")
except ImportError as e:
    print(f"❌ ta import failed: {e}")
    sys.exit(1)

try:
    import flask
    print(f"✅ flask imported successfully")
except ImportError as e:
    print(f"❌ flask import failed: {e}")
    sys.exit(1)

try:
    import yfinance as yf
    print("✅ yfinance imported successfully")
except ImportError as e:
    print(f"❌ yfinance import failed: {e}")
    sys.exit(1)

print("\n✅ All packages imported successfully!")
print("\nStarting FinBERT API server...")

# Now run the API
try:
    if os.path.exists("app_finbert_api_v5_TRULY_FIXED.py"):
        print("Using TRULY FIXED API...")
        exec(open("app_finbert_api_v5_TRULY_FIXED.py").read())
    elif os.path.exists("app_finbert_api_v5_fixed.py"):
        print("Using v5 API...")
        exec(open("app_finbert_api_v5_fixed.py").read())
    else:
        print("ERROR: No API file found!")
        sys.exit(1)
except Exception as e:
    print(f"Error starting API: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)