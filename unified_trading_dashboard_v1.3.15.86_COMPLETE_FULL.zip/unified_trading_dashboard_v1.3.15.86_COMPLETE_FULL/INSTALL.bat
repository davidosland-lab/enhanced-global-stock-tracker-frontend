@echo off
cls
echo ===============================================================
echo   Unified Trading Dashboard v1.3.15.86 COMPLETE Installation
echo   FULL ML Components Included
echo ===============================================================
echo.

echo [Step 1] Checking Python installation...
python --version
if errorlevel 1 (
    echo ERROR: Python not found! Please install Python 3.10 or higher.
    pause
    exit /b 1
)
echo SUCCESS: Python found
echo.

echo [Step 2] Installing ALL dependencies (including ML components)...
echo This may take a few minutes...
pip install -q -r requirements.txt
if errorlevel 1 (
    echo WARNING: Some dependencies failed. Continuing anyway...
)
echo SUCCESS: Dependencies installed
echo.

echo [Step 3] Creating directory structure...
if not exist "logs" mkdir logs
if not exist "state" mkdir state
if not exist "reports\screening" mkdir reports\screening
if not exist "tax_records" mkdir tax_records
echo SUCCESS: Directories created
echo.

echo [Step 4] Copying core files...
copy /Y core\*.py . > nul
if errorlevel 1 (
    echo ERROR: Failed to copy core files
    pause
    exit /b 1
)
echo SUCCESS: Core files copied
echo.

echo [Step 5] Copying ML pipeline...
xcopy /Y /I ml_pipeline ml_pipeline > nul
if errorlevel 1 (
    echo WARNING: ML pipeline copy had issues
) else (
    echo SUCCESS: ML pipeline copied
)
echo.

echo ===============================================================
echo         COMPLETE Installation Finished!
echo ===============================================================
echo.
echo ALL COMPONENTS INSTALLED:
echo   - Core dashboard
echo   - ML pipeline
echo   - Market calendar
echo   - Tax audit trail
echo   - Signal generators
echo.
echo To start:
echo   1. Run: START.bat
echo   2. Open: http://localhost:8050
echo.
echo To generate morning reports:
echo   cd scripts
echo   python run_au_pipeline_v1.3.13.py
echo.
pause
