@echo off
cls
echo ===============================================================
echo   Unified Trading Dashboard v1.3.15.86 COMPLETE
echo   Full ML Components Active
echo ===============================================================
echo.
echo Starting dashboard on http://localhost:8050
echo.

REM Set UTF-8 encoding
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
set KERAS_BACKEND=torch

REM Start dashboard
python unified_trading_dashboard.py --symbols BHP.AX,CBA.AX,RIO.AX --capital 100000

if errorlevel 1 (
    echo.
    echo ERROR: Dashboard failed to start!
    echo Check logs\unified_trading.log
) else (
    echo.
    echo Dashboard stopped cleanly
)

echo.
pause
