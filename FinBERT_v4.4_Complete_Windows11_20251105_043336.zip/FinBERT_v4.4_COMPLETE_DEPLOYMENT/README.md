# FinBERT v4.4 - Complete Trading System

**Version:** 4.4.0  
**Release Date:** 2024-11-05  
**Platform:** Windows 11  
**Status:** Production Ready - All 5 Phases Complete

---

## 🎯 Overview

FinBERT v4.4 is a complete stock prediction and trading system featuring:
- **Ensemble AI Prediction** using 4 different models
- **Multi-timezone Support** for US, Australian, and UK markets
- **Paper Trading** with virtual account management
- **Advanced Backtesting** for strategy validation
- **Parameter Optimization** for performance tuning
- **Prediction Validation** with automated accuracy tracking

---

## ✨ Key Features

### 1. 📊 Ensemble Prediction System
- **LSTM Neural Network** (45% weight) - Deep learning time series prediction
- **Trend Following** (25% weight) - Moving average and momentum analysis
- **Technical Analysis** (15% weight) - RSI, MACD, Bollinger Bands
- **FinBERT Sentiment** (15% weight) - NLP financial news analysis

### 2. 💰 Paper Trading System
- Virtual $10,000 starting account
- Real-time position tracking
- Buy/Sell order execution
- P&L calculation
- Complete trade history
- Position management

### 3. 🔙 Backtest Strategy (Single Stock)
- Walk-forward validation methodology
- Trade log with entry/exit prices
- Equity curve visualization
- Performance metrics (Win Rate, Sharpe Ratio, Max Drawdown)
- Detailed trade analysis

### 4. 📈 Portfolio Backtest (Multiple Stocks)
- Multi-stock portfolio testing
- Stock correlation matrix
- Per-stock performance breakdown
- Portfolio-level metrics
- Risk-adjusted returns
- Diversification analysis

### 5. ⚙️ Parameter Optimization
- Grid search optimization
- Random search support
- Train-test split validation
- Performance comparison
- Best parameter identification
- Configurable search space

### 6. 📜 Prediction History & Validation
- **Multi-timezone support** (US/AU/UK markets)
- **90-minute prediction lock** before market open
- **Automated validation** at market close
- **SQLite database** for persistence
- **Prediction vs actual** comparison
- **APScheduler** for automatic validation

---

## 🗃️ Database Schema

**Trading Database:** `data/trading.db`

### Table 1: `predictions` (27 columns)
Stores all predictions with model breakdowns and metadata:
- **id** - Primary key
- **symbol** - Stock ticker
- **prediction_date** - Date of prediction
- **prediction** - Final ensemble prediction
- **confidence** - Prediction confidence score
- **lstm_prediction, lstm_confidence** - LSTM model results
- **trend_prediction, trend_confidence** - Trend model results
- **technical_prediction, technical_confidence** - Technical model results
- **finbert_prediction, finbert_confidence** - Sentiment model results
- **market** - Market identifier (US/AU/UK)
- **timezone** - Market timezone
- **locked** - Whether prediction is locked (BOOLEAN)
- **lock_time** - When prediction was locked
- **validation_status** - Validation state
- **validation_time** - When validated
- **actual_direction** - Actual market movement
- **prediction_correct** - Whether prediction was correct
- **actual_return** - Actual percentage return
- **prediction_error** - Prediction error metric
- **notes** - Additional metadata
- **created_at** - Record creation timestamp
- **updated_at** - Last update timestamp

### Table 2: `validation_results` (15 columns)
Stores daily validation results:
- **id** - Primary key
- **validation_date** - Date validated
- **market** - Market identifier
- **total_predictions** - Number of predictions
- **correct_predictions** - Number correct
- **accuracy** - Accuracy percentage
- **avg_confidence** - Average confidence
- **avg_prediction_error** - Average error
- **best_performing_model** - Top model
- **validation_time** - Validation timestamp
- **notes** - Validation notes
- **total_return** - Portfolio return
- **avg_return** - Average return
- **created_at** - Record creation
- **updated_at** - Last update

---

## 🕐 Multi-Timezone System

### US Market (Eastern Time)
- **Open:** 9:30 AM EST
- **Close:** 4:00 PM EST
- **Prediction Lock:** 8:00 AM EST (90 minutes before open)
- **Validation:** 4:15 PM EST (15 minutes after close)

### Australian Market (Sydney Time)
- **Open:** 10:00 AM AEDT
- **Close:** 4:00 PM AEDT
- **Prediction Lock:** 8:30 AM AEDT (90 minutes before open)
- **Validation:** 4:15 PM AEDT (15 minutes after close)

### UK Market (London Time)
- **Open:** 8:00 AM GMT
- **Close:** 4:30 PM GMT
- **Prediction Lock:** 6:30 AM GMT (90 minutes before open)
- **Validation:** 4:45 PM GMT (15 minutes after close)

**Key Behavior:**
- Predictions can only be generated **before market opens**
- Once market opens, predictions are **locked** until next day
- Validation happens **automatically** 15 minutes after market close
- System handles **daylight saving time** automatically

---

## 🚀 Quick Start

### Installation (5 minutes)

1. **Extract ZIP file**
   ```
   Extract to: C:\FinBERT (or your preferred location)
   ```

2. **Run INSTALL.bat**
   - Creates Python virtual environment
   - Installs all dependencies from requirements.txt
   - Verifies installation
   - Creates necessary directories

3. **Run START_FINBERT.bat**
   - Starts the Flask server
   - Opens on http://localhost:5002

4. **Open browser**
   ```
   http://localhost:5002
   ```

### First Prediction (30 seconds)

1. Enter stock symbol (e.g., **AAPL**)
2. Select date
3. Click **"Get Prediction"**
4. View results with confidence scores

---

## 📚 Usage Guide

### Making Predictions

1. **Enter Symbol:** Type stock ticker (e.g., AAPL, TSLA, MSFT)
2. **Select Date:** Choose prediction date
3. **Get Prediction:** Click button to generate
4. **View Results:**
   - Overall prediction (UP/DOWN/NEUTRAL)
   - Confidence score
   - Individual model predictions
   - Market timezone information

### Paper Trading

1. **Open Trading Modal:** Click "Paper Trading" button
2. **View Account:** See cash balance and equity
3. **Place Order:**
   - Select Buy or Sell
   - Enter symbol and quantity
   - Submit order
4. **Manage Positions:**
   - View active positions
   - See P&L per position
   - Close positions as needed

### Running Backtests

**Single Stock:**
1. Click "Backtest Strategy"
2. Enter symbol (e.g., AAPL)
3. Select date range
4. Configure strategy parameters
5. Click "Run Backtest"
6. Analyze equity curve and trade log

**Portfolio:**
1. Click "Portfolio Backtest"
2. Enter multiple symbols (comma-separated)
3. Select date range and weights
4. Click "Run Portfolio Backtest"
5. View correlation matrix and performance

### Optimizing Parameters

1. Click "Optimize Parameters"
2. Enter symbol and date range
3. Configure parameter ranges
4. Select optimization method (grid/random)
5. Click "Run Optimization"
6. Compare configurations and select best

### Viewing Prediction History

1. Click "Prediction History"
2. Enter symbol
3. Select date range
4. Click "Load History"
5. View predictions vs actuals
6. Analyze accuracy metrics

---

## 🏗️ Architecture

### Backend Components

```
app_finbert_v4_dev.py          Main Flask application
config_dev.py                   Configuration settings

models/
├── backtesting/
│   ├── backtest_engine.py      Single stock backtesting
│   ├── portfolio_backtester.py Multi-stock portfolio testing
│   ├── trading_simulator.py    Order execution simulation
│   ├── parameter_optimizer.py  Parameter optimization
│   ├── prediction_engine.py    Walk-forward prediction
│   └── data_loader.py          Historical data fetching
│
├── trading/
│   ├── paper_trading_engine.py Core trading logic
│   ├── order_manager.py        Order placement
│   ├── position_manager.py     Position tracking
│   ├── trade_database.py       Trade persistence
│   └── prediction_database.py  Prediction storage
│
├── market_timezones.py         Multi-timezone support
├── prediction_manager.py       Prediction lifecycle
└── prediction_scheduler.py     Automated validation
```

### Frontend Components

```
templates/
└── finbert_v4_enhanced_ui.html Main UI with 5 modals

static/
└── echarts.min.js              Charting library
```

### Data Storage

```
data/
├── trading.db                  SQLite database
├── cache/                      Data cache
└── logs/                       Application logs
```

---

## 🔧 Configuration

### Port Configuration
Edit `config_dev.py`:
```python
FLASK_PORT = 5002  # Change to your preferred port
```

### Database Location
Edit `config_dev.py`:
```python
DATABASE_PATH = 'data/trading.db'
```

### Model Weights
Edit `app_finbert_v4_dev.py`:
```python
ENSEMBLE_WEIGHTS = {
    'lstm': 0.45,       # LSTM Neural Network
    'trend': 0.25,      # Trend Following
    'technical': 0.15,  # Technical Analysis
    'finbert': 0.15     # Sentiment Analysis
}
```

---

## 🐛 Troubleshooting

### Common Issues

**Problem:** `ModuleNotFoundError: No module named 'flask_cors'`  
**Solution:** Run `FIX_FLASK_CORS.bat` or manually: `pip install flask-cors>=4.0.0`  
**Details:** See `TROUBLESHOOTING_FLASK_CORS.md`

**Problem:** Server won't start  
**Solution:** Run `VERIFY_INSTALL.bat` to check installation  
**Check:** Look for error messages in command prompt

**Problem:** No predictions appear  
**Solution:** Check internet connection (needs Yahoo Finance access)  
**Alternative:** Try a different stock symbol

**Problem:** Predictions locked during market hours  
**Solution:** This is normal behavior - wait until next day or use `force_refresh=true` (API only)  
**Details:** See `PREDICTION_HOLD_SYSTEM_COMPLETE.md`

### Diagnostic Tools

- **VERIFY_INSTALL.bat** - Check all packages installed
- **FIX_FLASK_CORS.bat** - Fix flask-cors import error
- **diagnose_environment.py** - Detailed environment check

---

## 📖 Documentation Files

| File | Description |
|------|-------------|
| `README.md` | This file - complete overview |
| `INSTALL.txt` | Step-by-step installation guide |
| `QUICK_START.txt` | Quick start guide for beginners |
| `VERSION.txt` | Version information and changelog |
| `ALL_PHASES_COMPLETE.md` | Detailed feature documentation (15KB) |
| `PREDICTION_HOLD_SYSTEM_COMPLETE.md` | Multi-timezone system details (17KB) |
| `TROUBLESHOOTING_FLASK_CORS.md` | Common issue fixes (4.3KB) |
| `ROOT_CAUSE_ANALYSIS.md` | Historical bug analysis (6.5KB) |

---

## 🔐 Security Notes

- **Local Only:** Server runs on localhost (not exposed to internet)
- **No External Auth:** No authentication required (local use)
- **API Access:** Only Yahoo Finance API accessed externally
- **Data Privacy:** All data stored locally in SQLite database
- **Virtual Environment:** Uses isolated Python environment

---

## 🔄 System Requirements

### Minimum Requirements
- **OS:** Windows 10/11
- **Python:** 3.8 or higher
- **RAM:** 4GB
- **Disk:** 2GB free space
- **Internet:** Required for data fetching

### Recommended Requirements
- **OS:** Windows 11
- **Python:** 3.10 or higher
- **RAM:** 8GB
- **Disk:** 5GB free space
- **Internet:** Stable broadband connection

---

## 📊 Performance Metrics

### Prediction System
- **Average Latency:** < 2 seconds per prediction
- **Model Ensemble:** 4 models with weighted voting
- **Confidence Threshold:** Configurable (default: 0.6)

### Backtesting
- **Processing Speed:** ~1000 trades/second
- **Data Points:** Supports years of historical data
- **Walk-Forward:** Prevents look-ahead bias

### Database
- **Storage:** SQLite (lightweight, no server needed)
- **Capacity:** Millions of predictions
- **Backup:** Simple file copy

---

## 🎓 How It Works

### Prediction Process

1. **Data Fetching**
   - Historical price data from Yahoo Finance
   - News sentiment data (if available)
   - Technical indicators calculated

2. **Model Prediction**
   - LSTM analyzes time series patterns
   - Trend model checks moving averages
   - Technical model calculates indicators
   - FinBERT analyzes sentiment

3. **Ensemble Combination**
   - Weighted voting based on model weights
   - Confidence score calculated
   - Final prediction generated

4. **Storage & Locking**
   - Prediction stored in database
   - Locked 90 minutes before market open
   - Cannot be changed once locked

5. **Validation**
   - Automatic validation at market close
   - Actual vs predicted comparison
   - Accuracy metrics calculated
   - Results stored for analysis

---

## 🚦 API Endpoints

### Prediction APIs
```
GET  /api/predictions/<symbol>           Get prediction
GET  /api/predictions/<symbol>/history   Get history
POST /api/predictions/validate           Validate predictions
```

### Paper Trading APIs
```
GET  /api/trading/account                Get account info
POST /api/trading/orders                 Place order
GET  /api/trading/positions              Get positions
POST /api/trading/positions/close        Close position
GET  /api/trading/orders                 Get order history
```

### Backtesting APIs
```
POST /api/backtest/run                   Run single backtest
POST /api/backtest/portfolio             Run portfolio backtest
POST /api/backtest/optimize              Run optimization
```

---

## 💡 Best Practices

### Making Predictions
- Generate predictions **before market open**
- Use appropriate confidence thresholds
- Consider multiple stocks for diversification
- Review historical accuracy before trading

### Backtesting
- Use sufficient historical data (6+ months)
- Test on out-of-sample data
- Consider transaction costs
- Validate on multiple stocks

### Parameter Optimization
- Start with grid search for initial exploration
- Use random search for fine-tuning
- Avoid overfitting with proper train-test split
- Validate results on different time periods

### Paper Trading
- Start small to test strategies
- Monitor position sizes
- Use stop losses
- Track performance over time

---

## 🔮 Future Enhancements

Potential areas for expansion:
- Real broker integration
- More prediction models
- Advanced technical indicators
- Real-time streaming data
- Mobile interface
- Multi-user support
- Cloud deployment

---

## 📝 Version History

### v4.4.0 (2024-11-05)
- ✅ All 5 phases complete and functional
- ✅ Multi-timezone support (US/AU/UK)
- ✅ Prediction locking system
- ✅ Automated validation scheduling
- ✅ Fixed INSTALL.bat flask-cors issue
- ✅ Complete documentation package

### v4.3.0
- Added prediction history modal
- Database persistence
- Validation system

### v4.2.0
- Parameter optimization
- Portfolio backtesting

### v4.1.0
- Paper trading system
- Single stock backtesting

### v4.0.0
- Initial ensemble prediction system
- LSTM, Trend, Technical, FinBERT models

---

## 🤝 Support

For issues or questions:
1. Check `TROUBLESHOOTING_FLASK_CORS.md`
2. Review `ALL_PHASES_COMPLETE.md`
3. Run `VERIFY_INSTALL.bat` for diagnostics
4. Check `PREDICTION_HOLD_SYSTEM_COMPLETE.md` for timezone issues

---

## 📜 License

This software is provided as-is for educational and personal use.

---

## ⚠️ Disclaimer

**IMPORTANT:** This software is for educational purposes only. 

- NOT financial advice
- NOT guaranteed to be profitable
- Past performance does NOT indicate future results
- Use at your own risk
- Always do your own research
- Consider consulting a financial advisor

Trading stocks involves risk of loss. Only trade with money you can afford to lose.

---

## 🎉 Getting Started

Ready to begin? Follow these steps:

1. ✅ Run `INSTALL.bat`
2. ✅ Run `START_FINBERT.bat`
3. ✅ Open http://localhost:5002
4. ✅ Read `QUICK_START.txt`
5. ✅ Make your first prediction
6. ✅ Explore the features

**Enjoy using FinBERT v4.4!** 🚀

---

*For detailed feature documentation, see `ALL_PHASES_COMPLETE.md`*  
*For timezone system details, see `PREDICTION_HOLD_SYSTEM_COMPLETE.md`*  
*For troubleshooting, see `TROUBLESHOOTING_FLASK_CORS.md`*
