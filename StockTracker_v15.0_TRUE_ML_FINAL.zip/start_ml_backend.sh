#!/bin/bash
# Start ML Backend on port 8003

cd /home/user/webapp/clean_install_windows11
echo "Starting ML Backend on port 8003..."
python backend_ml_enhanced.py